﻿-- quản lý nhà hàng
CREATE DATABASE QuanLyBanHang2;
GO
USE QuanLyBanHang2;
GO
CREATE TABLE NhaCungCap (
    MaNhaCungCap INT PRIMARY KEY,
    TenNhaCungCap VARCHAR(100),
    DiaChi TEXT,
    SDT VARCHAR(20)
);
CREATE TABLE KhachHang (
    MaKhachHang INT PRIMARY KEY ,
    TenKhachHang VARCHAR(100),
    SDT VARCHAR(20),
    DiaChi TEXT
);
CREATE TABLE NhanVien (
    MaNhanVien INT PRIMARY KEY ,
    TenNhanVien VARCHAR(100),
    ChucVu VARCHAR(50),
    SDT VARCHAR(20),
    Email VARCHAR(100),
    DiaChi TEXT
);
CREATE TABLE TaiKhoan (
    TenDangNhap VARCHAR(50) PRIMARY KEY,
    MatKhau VARCHAR(100),
    MaNhanVien INT,
    VaiTro VARCHAR(50),
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVien(MaNhanVien)
);
CREATE TABLE SanPham (
    MaSanPham INT PRIMARY KEY ,
    TenSanPham VARCHAR(100),
    GiaBan FLOAT,
    MoTa TEXT
);
CREATE TABLE NguyenLieu (
    MaNguyenLieu INT PRIMARY KEY ,
    TenNguyenLieu VARCHAR(100),
    DonViTinh VARCHAR(20),
    SoLuongTon FLOAT,
    GiaNhap FLOAT,
    MaNhaCungCap INT,
    FOREIGN KEY (MaNhaCungCap) REFERENCES NhaCungCap(MaNhaCungCap)
);
CREATE TABLE CongThucCheBien (
    MaSanPham INT,
    MaNguyenLieu INT,
    SoLuongCan FLOAT,
    PRIMARY KEY (MaSanPham, MaNguyenLieu),
    FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSanPham),
    FOREIGN KEY (MaNguyenLieu) REFERENCES NguyenLieu(MaNguyenLieu)
);
CREATE TABLE DonHang (
    MaDonHang INT PRIMARY KEY ,
    NgayDat DATE,
    TrangThai VARCHAR(50),
    MaKhachHang INT,
    FOREIGN KEY (MaKhachHang) REFERENCES KhachHang(MaKhachHang)
);
CREATE TABLE ChiTietDonHang (
    MaDonHang INT,
    MaSanPham INT,
    SoLuong INT,
    DonGia FLOAT,
    PRIMARY KEY (MaDonHang, MaSanPham),
    FOREIGN KEY (MaDonHang) REFERENCES DonHang(MaDonHang),
    FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSanPham)
);
CREATE TABLE HoaDon (
    MaHoaDon INT PRIMARY KEY ,
    NgayLap DATE,
    TongTien FLOAT,
    MaDonHang INT,
    MaNhanVien INT,
    FOREIGN KEY (MaDonHang) REFERENCES DonHang(MaDonHang),
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVien(MaNhanVien)
);
