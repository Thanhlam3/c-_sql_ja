﻿create database QLSV;
use QLSV;
create table KHOA
(MaKhoa varchar(10) not null primary key,
TenKhoa nvarchar(50) not null,
SL_CBGD smallint not null);
create table GIAOVIEN
(MaGV varchar(5) not  null primary key,
TenGV nvarchar(50) not null,
MaKhoa varchar(10) foreign key references KHOA(MaKhoa));
create table MONHOC
(MaMH varchar(5) not null primary key,
TenMH nvarchar(5) not null,
SoTC smallint not null);
create table SINHVIEN
(MSSV varchar(5) not null primary key,
Ten nvarchar(50) not null,
GioiTinh varchar(5) not null,
DiaChi nvarchar(100) not null,
DienThoai varchar(20),
MaKhoa varchar(10) foreign key references KHOA(MaKhoa));
create table GIANGDAY 
(MaKhoaHoc varchar(5) not null primary key,
MaGV varchar(5) foreign key references GIAOVIEN(MaGV),
MaMH varchar(5) foreign key references MONHOC(MaMH),
HocKy smallint not null,
Nam int not null);
create table KETQUA
(MaSV varchar(5) not null foreign key references SINHVIEN(MSSV),
MaKhoaHoc varchar(5) not null  foreign key references GIANGDAY(MaKhoaHoc),
Diem decimal(3,1) not null,
constraint pk_ketqua primary key  (MaSV,MaKhoaHoc));
--truy vấn sql
--bài 1: câu 28: Cho biết mã, tên, địa chỉ và điểm trung bình của từng sinh viên.

select sv.MSSV, sv.Ten, sv.Diachi,
	sum(mh.SoTC * kq.Diem) / sum(mh.SoTC) as dtb
from 
	 SINHVIEN sv inner join KETQUA kq  on sv.MSSV = kq.MaSV
	 inner join GIANGDAY gd on kq.MaKhoaHoc = gd.MaKhoaHoc
	 inner join MONHOC mh on gd.MaMH = mh.MaMH
group by sv.MSSV, sv.Ten, sv.Diachi;
 /* SELECT sv.MSSV, sv.Ten, sv.DiaChi,
       ROUND(SUM(mh.SoTC * kq.Diem) / SUM(mh.SoTC), 2) AS DiemTrungBinh
FROM SINHVIEN sv
JOIN KETQUA kq ON sv.MSSV = kq.MaSV
JOIN GIANGDAY gd ON kq.MaKhoaHoc = gd.MaKhoaHoc
JOIN MONHOC mh ON gd.MaMH = mh.MaMH
GROUP BY sv.MSSV, sv.Ten, sv.DiaChi; */
