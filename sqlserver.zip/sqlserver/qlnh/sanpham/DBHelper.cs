﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using System;
using System.Data.SqlClient;


namespace sanpham
{
    class DBHelper
    {
        private static string connectionString = "Server=localhost;Database=QuanLyNhaHang;Trusted_Connection=True;";

        // Cho phép set lại từ FormLogin
        public static void SetConnectionString(string connStr)
        {
            connectionString = connStr;
        }
        public static SqlConnection GetConnection()
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                return conn;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi kết nối: " + ex.Message);
                return null;
            }
        }
    }
}
