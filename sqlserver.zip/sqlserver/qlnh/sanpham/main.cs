﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sanpham
{
    public partial class main: Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 frm = new Form5();
            frm.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form6 frm = new Form6();
            frm.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form7 frm = new Form7();
            frm.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form8 frm = new Form8();
            frm.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form9 frm = new Form9();
            frm.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form10 frm = new Form10();
            frm.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            truyvan frm = new truyvan();
            frm.ShowDialog();
        }

        private void main_Load(object sender, EventArgs e)
        {
            string role = login.role;

            switch (role)
            {
                case "admin":
                    // QL toàn quyền – để tất cả nút bình thường
                    break;

                case "phucvu":
                    btnSanPham.Enabled = true;
                    btnDonHang.Enabled = true;
                    btnBan.Enabled = true;

                    btnNhacungcap.Enabled = false;
                    btnCTDH.Enabled = false;
                    btnHoaDon.Enabled = false;
                    btnNV.Enabled = false;
                    btnKH.Enabled = false;
                    btnNguyenLieu.Enabled = false;
                    btnCongThuc.Enabled = false;
                    btnTruyVan.Enabled = false; 
                    break;

                case "bep":
                    btnSanPham.Enabled = false;
                    btnDonHang.Enabled = false;
                    btnBan.Enabled = false;
                    btnCongThuc.Enabled = false;
                    btnTruyVan.Enabled = false;
                    btnNhacungcap.Enabled = false;
                    btnCTDH.Enabled = false;
                    btnHoaDon.Enabled = false;
                    btnNV.Enabled = false;
                    btnKH.Enabled = false;

                    

                    btnNguyenLieu.Enabled = true;
                    btnCongThuc.Enabled = true;
                    break;

                default:
                    MessageBox.Show("Tài khoản không có quyền truy cập.");
                    this.Close();
                    break;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
