﻿namespace sanpham
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBan = new System.Windows.Forms.Button();
            this.btnNhacungcap = new System.Windows.Forms.Button();
            this.btnNguyenLieu = new System.Windows.Forms.Button();
            this.btnSanPham = new System.Windows.Forms.Button();
            this.btnCongThuc = new System.Windows.Forms.Button();
            this.btnNV = new System.Windows.Forms.Button();
            this.btnKH = new System.Windows.Forms.Button();
            this.btnDonHang = new System.Windows.Forms.Button();
            this.btnHoaDon = new System.Windows.Forms.Button();
            this.btnCTDH = new System.Windows.Forms.Button();
            this.btnTruyVan = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBan
            // 
            this.btnBan.Location = new System.Drawing.Point(29, 28);
            this.btnBan.Name = "btnBan";
            this.btnBan.Size = new System.Drawing.Size(146, 57);
            this.btnBan.TabIndex = 0;
            this.btnBan.Text = "bàn";
            this.btnBan.UseVisualStyleBackColor = true;
            this.btnBan.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnNhacungcap
            // 
            this.btnNhacungcap.Location = new System.Drawing.Point(238, 28);
            this.btnNhacungcap.Name = "btnNhacungcap";
            this.btnNhacungcap.Size = new System.Drawing.Size(146, 57);
            this.btnNhacungcap.TabIndex = 1;
            this.btnNhacungcap.Text = "nhà cung cấp";
            this.btnNhacungcap.UseVisualStyleBackColor = true;
            this.btnNhacungcap.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnNguyenLieu
            // 
            this.btnNguyenLieu.Location = new System.Drawing.Point(439, 28);
            this.btnNguyenLieu.Name = "btnNguyenLieu";
            this.btnNguyenLieu.Size = new System.Drawing.Size(146, 57);
            this.btnNguyenLieu.TabIndex = 2;
            this.btnNguyenLieu.Text = "nguyên liệu";
            this.btnNguyenLieu.UseVisualStyleBackColor = true;
            this.btnNguyenLieu.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnSanPham
            // 
            this.btnSanPham.Location = new System.Drawing.Point(642, 28);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(146, 57);
            this.btnSanPham.TabIndex = 3;
            this.btnSanPham.Text = "SanPham";
            this.btnSanPham.UseVisualStyleBackColor = true;
            this.btnSanPham.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnCongThuc
            // 
            this.btnCongThuc.Location = new System.Drawing.Point(827, 28);
            this.btnCongThuc.Name = "btnCongThuc";
            this.btnCongThuc.Size = new System.Drawing.Size(146, 57);
            this.btnCongThuc.TabIndex = 4;
            this.btnCongThuc.Text = "CongThucCheBien";
            this.btnCongThuc.UseVisualStyleBackColor = true;
            this.btnCongThuc.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnNV
            // 
            this.btnNV.Location = new System.Drawing.Point(29, 121);
            this.btnNV.Name = "btnNV";
            this.btnNV.Size = new System.Drawing.Size(146, 57);
            this.btnNV.TabIndex = 5;
            this.btnNV.Text = "NhanVien";
            this.btnNV.UseVisualStyleBackColor = true;
            this.btnNV.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnKH
            // 
            this.btnKH.Location = new System.Drawing.Point(238, 121);
            this.btnKH.Name = "btnKH";
            this.btnKH.Size = new System.Drawing.Size(146, 57);
            this.btnKH.TabIndex = 6;
            this.btnKH.Text = "KhachHang";
            this.btnKH.UseVisualStyleBackColor = true;
            this.btnKH.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnDonHang
            // 
            this.btnDonHang.Location = new System.Drawing.Point(439, 121);
            this.btnDonHang.Name = "btnDonHang";
            this.btnDonHang.Size = new System.Drawing.Size(146, 57);
            this.btnDonHang.TabIndex = 7;
            this.btnDonHang.Text = "DonHang";
            this.btnDonHang.UseVisualStyleBackColor = true;
            this.btnDonHang.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnHoaDon
            // 
            this.btnHoaDon.Location = new System.Drawing.Point(642, 121);
            this.btnHoaDon.Name = "btnHoaDon";
            this.btnHoaDon.Size = new System.Drawing.Size(146, 57);
            this.btnHoaDon.TabIndex = 8;
            this.btnHoaDon.Text = "HoaDon";
            this.btnHoaDon.UseVisualStyleBackColor = true;
            this.btnHoaDon.Click += new System.EventHandler(this.button9_Click);
            // 
            // btnCTDH
            // 
            this.btnCTDH.Location = new System.Drawing.Point(827, 121);
            this.btnCTDH.Name = "btnCTDH";
            this.btnCTDH.Size = new System.Drawing.Size(146, 57);
            this.btnCTDH.TabIndex = 9;
            this.btnCTDH.Text = "ChiTietDonHang";
            this.btnCTDH.UseVisualStyleBackColor = true;
            this.btnCTDH.Click += new System.EventHandler(this.button10_Click);
            // 
            // btnTruyVan
            // 
            this.btnTruyVan.Location = new System.Drawing.Point(29, 222);
            this.btnTruyVan.Name = "btnTruyVan";
            this.btnTruyVan.Size = new System.Drawing.Size(146, 57);
            this.btnTruyVan.TabIndex = 10;
            this.btnTruyVan.Text = "truy vấn";
            this.btnTruyVan.UseVisualStyleBackColor = true;
            this.btnTruyVan.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(238, 222);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(146, 57);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "thoát";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnTruyVan);
            this.Controls.Add(this.btnCTDH);
            this.Controls.Add(this.btnHoaDon);
            this.Controls.Add(this.btnDonHang);
            this.Controls.Add(this.btnKH);
            this.Controls.Add(this.btnNV);
            this.Controls.Add(this.btnCongThuc);
            this.Controls.Add(this.btnSanPham);
            this.Controls.Add(this.btnNguyenLieu);
            this.Controls.Add(this.btnNhacungcap);
            this.Controls.Add(this.btnBan);
            this.Name = "main";
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBan;
        private System.Windows.Forms.Button btnNhacungcap;
        private System.Windows.Forms.Button btnNguyenLieu;
        private System.Windows.Forms.Button btnSanPham;
        private System.Windows.Forms.Button btnCongThuc;
        private System.Windows.Forms.Button btnNV;
        private System.Windows.Forms.Button btnKH;
        private System.Windows.Forms.Button btnDonHang;
        private System.Windows.Forms.Button btnHoaDon;
        private System.Windows.Forms.Button btnCTDH;
        private System.Windows.Forms.Button btnTruyVan;
        private System.Windows.Forms.Button btnExit;
    }
}