﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sanpham
{
    public partial class truyvan: Form
    {
        public truyvan()
        {
            InitializeComponent();
            LoadComboBox();
            cboTruyVan.SelectedIndexChanged += cboTruyVan_SelectedIndexChanged;
        }
        private void LoadComboBox()
        {
            cboTruyVan.Items.Add("1. Danh sách nhà cung cấp");
            cboTruyVan.Items.Add("2. Danh sách sản phẩm");
            cboTruyVan.Items.Add("3. Nhân viên và chức vụ");
            cboTruyVan.Items.Add("4. Tổng số nguyên liệu tồn kho");
            cboTruyVan.Items.Add("5. Trung bình giá sản phẩm");
            cboTruyVan.Items.Add("6. Số lượng khách hàng");
            cboTruyVan.Items.Add("7. Sản phẩm giá cao nhất");
            cboTruyVan.Items.Add("8. Doanh thu theo nhân viên");
            cboTruyVan.Items.Add("9. Tổng tiền từng hóa đơn");
            cboTruyVan.Items.Add("10. Sản phẩm được bán nhiều lần");
        }

        private void cboTruyVan_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "";

            switch (cboTruyVan.SelectedIndex)
            {
                case 0:
                    query = "SELECT * FROM NhaCungCap";
                    break;
                case 1:
                    query = "SELECT TenSanPham, GiaBan FROM SanPham";
                    break;
                case 2:
                    query = "SELECT TenNhanVien, ChucVu FROM NhanVien";
                    break;
                case 3:
                    query = "SELECT SUM(SoLuongTon) AS TongTonKho FROM NguyenLieu";
                    break;
                case 4:
                    query = "SELECT AVG(GiaBan) AS TrungBinhGia FROM SanPham";
                    break;
                case 5:
                    query = "SELECT COUNT(*) AS SoLuongKhach FROM KhachHang";
                    break;
                case 6:
                    query = "SELECT * FROM SanPham WHERE GiaBan = (SELECT MAX(GiaBan) FROM SanPham)";
                    break;
                case 7:
                    query = @"SELECT MaNhanVien, SUM(TongTien) AS DoanhThu
                              FROM HoaDon
                              GROUP BY MaNhanVien";
                    break;
                case 8:
                    query = @"SELECT MaHoaDon, SUM(DonGia * SoLuong) AS ThanhTien
                              FROM ChiTietDonHang
                              GROUP BY MaHoaDon";
                    break;
                case 9:
                    query = @"SELECT MaSanPham, COUNT(*) AS SoLanBan
                              FROM ChiTietDonHang
                              GROUP BY MaSanPham";
                    break;
                default:
                    MessageBox.Show("Vui lòng chọn truy vấn.");
                    return;
            }

            try
            {
                using (SqlConnection conn = DBHelper.GetConnection())
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvKetQua.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi truy vấn: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboTruyVan_SelectedIndexChanged(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
