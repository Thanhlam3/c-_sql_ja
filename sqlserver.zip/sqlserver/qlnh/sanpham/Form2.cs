﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sanpham
{
    public partial class Form2: Form
    {
        public Form2()
        {
            InitializeComponent();
            

            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Ban", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvBan.DataSource = dt;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "INSERT INTO Ban VALUES (@Ma, @Ten, @TrangThai)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaBan.Text));
                cmd.Parameters.AddWithValue("@Ten", txtTenBan.Text);
                cmd.Parameters.AddWithValue("@TrangThai", txtTrangThai.Text);
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "UPDATE Ban SET TenBan = @Ten, TrangThai = @TrangThai WHERE MaBan = @Ma";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaBan.Text));
                cmd.Parameters.AddWithValue("@Ten", txtTenBan.Text);
                cmd.Parameters.AddWithValue("@TrangThai", txtTrangThai.Text);
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "DELETE FROM Ban WHERE MaBan = @Ma";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaBan.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        

        private void dgvBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvBan.Rows[e.RowIndex];
                txtMaBan.Text = row.Cells["MaBan"].Value.ToString();
                txtTenBan.Text = row.Cells["TenBan"].Value.ToString();
                txtTrangThai.Text = row.Cells["TrangThai"].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

