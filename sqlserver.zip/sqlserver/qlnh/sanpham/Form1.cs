﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sanpham
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM SanPham", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvSanPham.DataSource = dt;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "INSERT INTO SanPham VALUES (@Ma, @Ten, @Gia, @MoTa)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaSanPham.Text));
                cmd.Parameters.AddWithValue("@Ten", txtTenSanPham.Text);
                cmd.Parameters.AddWithValue("@Gia", float.Parse(txtGiaBan.Text));
                cmd.Parameters.AddWithValue("@MoTa", txtMoTa.Text);
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "UPDATE SanPham SET TenSanPham = @Ten, GiaBan = @Gia, MoTa = @MoTa WHERE MaSanPham = @Ma";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaSanPham.Text));
                cmd.Parameters.AddWithValue("@Ten", txtMaSanPham.Text);
                cmd.Parameters.AddWithValue("@Gia", float.Parse(txtGiaBan.Text));
                cmd.Parameters.AddWithValue("@MoTa", txtMoTa.Text);
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "DELETE FROM SanPham WHERE MaSanPham = @Ma";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaSanPham.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        
        private void dgvBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvSanPham.Rows[e.RowIndex];
                txtMaSanPham.Text = row.Cells["MaSanPham"].Value.ToString();
                txtMaSanPham.Text = row.Cells["TenSanPham"].Value.ToString();
                txtGiaBan.Text = row.Cells["GiaBan"].Value.ToString();
                txtMoTa.Text = row.Cells["MoTa"].Value.ToString();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

