﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sanpham
{
    public partial class Form9: Form
    {
        public Form9()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM HoaDon", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvHoaDon.DataSource = dt;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = @"INSERT INTO HoaDon 
                    VALUES (@MaHD, @NgayLap, @TongTien, @MaDonHang, @MaSP, @MaBan, @MaNV)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", int.Parse(txtMaHD.Text));
                cmd.Parameters.AddWithValue("@NgayLap", DateTime.Parse(txtNgayLap.Text));
                cmd.Parameters.AddWithValue("@TongTien", float.Parse(txtTongTien.Text));
                cmd.Parameters.AddWithValue("@MaDonHang", int.Parse(txtMaDonHang.Text));
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSanPham.Text));
                cmd.Parameters.AddWithValue("@MaBan", int.Parse(txtMaBan.Text));
                cmd.Parameters.AddWithValue("@MaNV", int.Parse(txtMaNhanVien.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = @"UPDATE HoaDon 
                    SET NgayLap = @NgayLap, TongTien = @TongTien, MaDonHang = @MaDonHang,
                        MaSanPham = @MaSP, MaBan = @MaBan, MaNhanVien = @MaNV 
                    WHERE MaHoaDon = @MaHD";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", int.Parse(txtMaHD.Text));
                cmd.Parameters.AddWithValue("@NgayLap", DateTime.Parse(txtNgayLap.Text));
                cmd.Parameters.AddWithValue("@TongTien", float.Parse(txtTongTien.Text));
                cmd.Parameters.AddWithValue("@MaDonHang", int.Parse(txtMaDonHang.Text));
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSanPham.Text));
                cmd.Parameters.AddWithValue("@MaBan", int.Parse(txtMaBan.Text));
                cmd.Parameters.AddWithValue("@MaNV", int.Parse(txtMaNhanVien.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "DELETE FROM HoaDon WHERE MaHoaDon = @MaHD";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", int.Parse(txtMaHD.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void dgvHoaDon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvHoaDon.Rows[e.RowIndex];
                txtMaHD.Text = row.Cells["MaHoaDon"].Value.ToString();
                txtNgayLap.Text = row.Cells["NgayLap"].Value.ToString();
                txtTongTien.Text = row.Cells["TongTien"].Value.ToString();
                txtMaDonHang.Text = row.Cells["MaDonHang"].Value.ToString();
                txtMaSanPham.Text = row.Cells["MaSanPham"].Value.ToString();
                txtMaBan.Text = row.Cells["MaBan"].Value.ToString();
                txtMaNhanVien.Text = row.Cells["MaNhanVien"].Value.ToString();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
