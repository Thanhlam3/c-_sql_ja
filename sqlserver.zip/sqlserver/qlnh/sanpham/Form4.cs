﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sanpham
{
    public partial class Form4: Form
    {
        public Form4()
        {
            InitializeComponent();
            if (login.role == "bep")
            {
                btnThem.Enabled = false;
                btnSua.Enabled = false;
                btnXoa.Enabled = false;
            }

            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM NguyenLieu", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvNguyenLieu.DataSource = dt;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "INSERT INTO NguyenLieu VALUES (@Ma, @Ten, @DonVi, @SoLuong, @GiaNhap, @MaNCC)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaNL.Text));
                cmd.Parameters.AddWithValue("@Ten", txtTenNL.Text);
                cmd.Parameters.AddWithValue("@DonVi", txtDonViTinh.Text);
                cmd.Parameters.AddWithValue("@SoLuong", float.Parse(txtSoLuong.Text));
                cmd.Parameters.AddWithValue("@GiaNhap", float.Parse(txtGiaNhap.Text));
                cmd.Parameters.AddWithValue("@MaNCC", int.Parse(txtMaNCC.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = @"UPDATE NguyenLieu 
                                 SET TenNguyenLieu = @Ten, DonViTinh = @DonVi, SoLuongTon = @SoLuong, GiaNhap = @GiaNhap, MaNhaCungCap = @MaNCC 
                                 WHERE MaNguyenLieu = @Ma";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaNL.Text));
                cmd.Parameters.AddWithValue("@Ten", txtTenNL.Text);
                cmd.Parameters.AddWithValue("@DonVi", txtDonViTinh.Text);
                cmd.Parameters.AddWithValue("@SoLuong", float.Parse(txtSoLuong.Text));
                cmd.Parameters.AddWithValue("@GiaNhap", float.Parse(txtGiaNhap.Text));
                cmd.Parameters.AddWithValue("@MaNCC", int.Parse(txtMaNCC.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "DELETE FROM NguyenLieu WHERE MaNguyenLieu = @Ma";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Ma", int.Parse(txtMaNL.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void dgvNguyenLieu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvNguyenLieu.Rows[e.RowIndex];
                txtMaNL.Text = row.Cells["MaNguyenLieu"].Value.ToString();
                txtTenNL.Text = row.Cells["TenNguyenLieu"].Value.ToString();
                txtDonViTinh.Text = row.Cells["DonViTinh"].Value.ToString();
                txtSoLuong.Text = row.Cells["SoLuongTon"].Value.ToString();
                txtGiaNhap.Text = row.Cells["GiaNhap"].Value.ToString();
                txtMaNCC.Text = row.Cells["MaNhaCungCap"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

