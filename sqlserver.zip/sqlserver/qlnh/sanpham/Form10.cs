﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sanpham
{
    public partial class Form10: Form
    {
        public Form10()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM ChiTietDonHang", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvChiTietDonHang.DataSource = dt;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = @"INSERT INTO ChiTietDonHang 
                                 VALUES (@MaHD, @MaSP, @SoLuong, @DonGia)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", int.Parse(txtMaHoaDon.Text));
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSanPham.Text));
                cmd.Parameters.AddWithValue("@SoLuong", int.Parse(txtSoLuong.Text));
                cmd.Parameters.AddWithValue("@DonGia", float.Parse(txtDonGia.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = @"UPDATE ChiTietDonHang 
                                 SET SoLuong = @SoLuong, DonGia = @DonGia 
                                 WHERE MaHoaDon = @MaHD AND MaSanPham = @MaSP";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", int.Parse(txtMaHoaDon.Text));
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSanPham.Text));
                cmd.Parameters.AddWithValue("@SoLuong", int.Parse(txtSoLuong.Text));
                cmd.Parameters.AddWithValue("@DonGia", float.Parse(txtDonGia.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = @"DELETE FROM ChiTietDonHang 
                                 WHERE MaHoaDon = @MaHD AND MaSanPham = @MaSP";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaHD", int.Parse(txtMaHoaDon.Text));
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSanPham.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void dgvChiTietDonHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvChiTietDonHang.Rows[e.RowIndex];
                txtMaHoaDon.Text = row.Cells["MaHoaDon"].Value.ToString();
                txtMaSanPham.Text = row.Cells["MaSanPham"].Value.ToString();
                txtSoLuong.Text = row.Cells["SoLuong"].Value.ToString();
                txtDonGia.Text = row.Cells["DonGia"].Value.ToString();
            }
        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
