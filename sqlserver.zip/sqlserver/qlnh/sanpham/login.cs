﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sanpham
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        public static string role = ""; // lưu vai trò toàn cục

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text;
            string pass = txtPassword.Text;

            string connStr = $"Server=localhost;Database=QuanLyNhaHang;User Id={user};Password={pass};";

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open(); // nếu thành công thì hợp lệ
                    MessageBox.Show("Đăng nhập thành công!");

                    // Xác định role
                    if (user == "QL_NhaHang")
                        role = "admin";
                    else if (user == "NV_PV")
                        role = "phucvu";
                    else if (user == "NV_Bep")
                        role = "bep";
                    else
                        role = "khac";

                    // Lưu chuỗi kết nối dùng cho các form khác
                    DBHelper.SetConnectionString(connStr);

                    // Mở form chính
                    this.Hide();
                    new main().Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đăng nhập thất bại: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
