﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sanpham
{
    public partial class Form5: Form
    {
        public Form5()
        {
            InitializeComponent();
            if (login.role == "bep")
            {
                btnThem.Enabled = false;
                btnSua.Enabled = false;
                btnXoa.Enabled = false;
            }
            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM CongThucCheBien", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCongThuc.DataSource = dt;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "INSERT INTO CongThucCheBien VALUES (@MaSP, @MaNL, @SoLuong)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSP_1.Text));
                cmd.Parameters.AddWithValue("@MaNL", int.Parse(txtMaNL.Text));
                cmd.Parameters.AddWithValue("@SoLuong", float.Parse(txtSoLuongCan.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "UPDATE CongThucCheBien SET SoLuongCan = @SoLuong WHERE MaSanPham = @MaSP AND MaNguyenLieu = @MaNL";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSP_1.Text));
                cmd.Parameters.AddWithValue("@MaNL", int.Parse(txtMaNL.Text));
                cmd.Parameters.AddWithValue("@SoLuong", float.Parse(txtSoLuongCan.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                string query = "DELETE FROM CongThucCheBien WHERE MaSanPham = @MaSP AND MaNguyenLieu = @MaNL";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MaSP", int.Parse(txtMaSP_1.Text));
                cmd.Parameters.AddWithValue("@MaNL", int.Parse(txtMaNL.Text));
                cmd.ExecuteNonQuery();
                LoadData();
            }
        }

        private void dgvCongThuc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvCongThuc.Rows[e.RowIndex];
                txtMaSP_1.Text = row.Cells["MaSanPham"].Value.ToString();
                txtMaNL.Text = row.Cells["MaNguyenLieu"].Value.ToString();
                txtSoLuongCan.Text = row.Cells["SoLuongCan"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
