﻿create database QLHH

use QLHH

create table LOAIHANG (
MALOAIHANG varchar(10) not null primary key,
TENLOAIHANG nvarchar(100) not null
)

create table NHACUNGCAP (
MACONGTY varchar(10) not null primary key,
TENCONGTY nvarchar(100) not null,
TENGIAODICH nvarchar(100) not null,
DIACHI nvarchar(100) not null,
DIENTHOAI varchar(20) not null,
FAX varchar(20) not null,
EMAIL varchar(20) not null
)

create table KHACHHANG (
MAKHACHHANG varchar(10) not null primary key,
TENCONGTY nvarchar(100) not null,
TENGIAODICH nvarchar(100) not null,
DIACHI nvarchar(100) not null,
EMAIL varchar(20) not null,
DIENTHOAI varchar(20) not null,
FAX varchar(20) not null
)

create table NHANVIEN (
MANHANVIEN varchar(10) not null primary key,
HO nvarchar(30) not null,
TEN nvarchar(10) not null,
NGAYSINH date not null,
NGAYLAMVIEC date not null,
DIACHI nvarchar(100) not null,
DIENTHOAI varchar(20) null,
LUONGCOBAN money not null,
PHUCAP money not null
)

create table MATHANG (
MAHANG varchar(10) not null primary key,
TENHANG nvarchar(100) not null,
MACONGTY varchar(10) not null foreign key  references  NHACUNGCAP(MACONGTY),
MALOAIHANG varchar(10) not null foreign key references LOAIHANG(MALOAIHANG),
SOLUONG decimal(10,2) not null,
DONVITINH nvarchar(20) not null,
GIAHANG money not null
)
create table DONDATHANG (
SOHOADON varchar(10) not null primary key,
MAKHACHHANG varchar(10) not null foreign key references KHACHHANG(MAKHACHHANG),
MANHANVIEN varchar(10) not null foreign key references NHANVIEN(MANHANVIEN) ,
NGAYDATHANG datetime null,
NGAYGIAOHANG datetime null,
NGAYCHUYENHANG datetime null,
NOIGIAOHANG nvarchar(100) null
)

create table CTDATHANG (
SOHOADON varchar(10) not null foreign key references DONDATHANG(SOHOADON),
MAHANG varchar(10) not null foreign key references MATHANG(MAHANG),
GIABAN money not null,
SOLUONG decimal(10,2) not null,
MUCGIAMGIA decimal(4,2) not null
constraint pk_ctdathang primary key (SOHOADON, MAHANG)
)
/*Câu 26 (QLHH). Hãy cho biết tổng số lượng hàng của mỗi mặt hàng mà công ty đã có (tổng số lượng hàng hiện có và đã bán).*/
select mh.MAHANG, mh.TENHANG, mh.SOLUONG as slhienco,
	   sum(ctdh.SOLUONG) as sldaban,
	   (mh.SOLUONG + sum(ctdh.SOLUONG)) as tongsl
from  MATHANG mh left join CTDATHANG ctdh on mh.MAHANG = ctdh.MAHANG
group by mh.MAHANG, mh.TENHANG, mh.SOLUONG;				
	