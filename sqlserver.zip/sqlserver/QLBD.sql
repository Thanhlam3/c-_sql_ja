﻿CREATE DATABASE QLBongDa;
use QLBongDa;

create table TINH(
MATINH varchar(5) primary key,
TENTINH nvarchar(100),
)

create table QUOCGIA(
MAQG varchar(5) primary key,
TENQG nvarchar(60),
)

create table SANVD(
MASAN varchar(5) primary key,
TENSAN nvarchar(100),
DIACHI nvarchar(200),
)

create table HUANLUYENVIEN(
MAHLV varchar(5) primary key,
TENHLV nvarchar(100),
NGAYSINH datetime,
DIACHI nvarchar(200),
DIENTHOAI nvarchar(20),
MAQG varchar(5) foreign key references QUOCGIA(MAQG),
)

create table CAULACBO(
MACLB varchar(5) primary key,
TENCLB nvarchar(100),
MASAN varchar(5) foreign key references SANVD(MASAN),
MATINH varchar(5) foreign key references TINH(MATINH),
)

create table HLV_CLB(
MAHLV varchar(5),
MACLB varchar(5),
VAITRO nvarchar(100),
primary key(MAHLV, MACLB),
foreign key (MAHLV) references HUANLUYENVIEN(MAHLV),
foreign key (MACLB) references CAULACBO(MACLB),
)

create table TRANDAU(
MATRAN numeric primary key,
NAM int,
VONG int,
NGAYTD datetime,
MACLB1 varchar(5) foreign key references CAULACBO(MACLB),
MACLB2 varchar(5) foreign key references CAULACBO(MACLB),
MASAN varchar(5)foreign key references SANVD(MASAN),
KETQUA varchar(5),
)

create table CAUTHU(
MACT numeric IDENTITY(1,1) primary key,
HOTEN nvarchar(100),
VITRI nvarchar(20),
NGAYSINH datetime,
DIACHI nvarchar(200),
MACLB varchar(5) foreign key references CAULACBO(MACLB),
MAQG varchar(5)foreign key references QUOCGIA(MAQG),
SO int,
)

create table BANGXH(
MACLB varchar(5),
NAM int,
VONG int,
SOTRAN int,
THANG int,
HOA int,
THUA int,
HIEUSO varchar(5),
DIEM int,
HANG int,
primary key(MACLB,NAM,VONG),
foreign key (MACLB) references CAULACBO(MACLB),
)
--TINH--
insert into TINH
values('BD',N'Bình Dương'),
('GL',N'Gia Lai'),
('DN',N'Đà Nẵng'),
('KH',N'Khánh Hoà'),
('PY',N'Phú Yên'),
('LA',N'Long An');
--QUOCGIA--
insert into QUOCGIA
values('VN',N'Việt Nam'),
('ANH',N'Anh Quốc'),
('TBN',N'Tây Ban Nha'),
('BDN',N'Bồ Đào Nha'),
('BRA',N'Bra-xin'),
('ITA',N'Ý'),
('THA',N'Thái Lan');
--SANVD--
insert into SANVD
values('GD',N'Gò Đậu',N'123 QL1, TX Thủ Dầu Một, Bình Dương'),
('PL',N'Pleiku',N'22 Hồ Tùng Mậu,Thống Nhất, Thị xã Pleiku, Gia Lai'),
('CL',N'Chi Lăng',N'127 Võ Văn Tần, Đà Nẵng'),
('NT',N'Nha Trang',N'128 Phan Chu Trinh, Nha Trang, Khánh Hoà'),
('TH',N'Tuy Hoà',N'57 Trường Chinh, Tuy Hoà, Phú Yên'),
('LA',N'Long An',N'102 Hùng Vương, Tp Tân An, Long An');
--HUANLUYENVIEN--
insert into HUANLUYENVIEN
values('HLV01',N'Vital','1975/10/15',N'NULL',N'0918011075','BDN'),
('HLV02',N'Lê Huỳnh Đức','1972/05/20',N'NULL',N'01223456789','VN'),
('HLV03',N'Kiatisuk','1970/12/11',N'NULL',N'01990123456','THA'),
('HLV04',N'Hoàng Anh Tuấn','1970/06/10',N'NULL',N'0989112233','VN'),
('HLV05',N'Trần Công Minh','1973/07/07',N'NULL',N'0909099990','VN'),
('HLV06',N'Trần Văn Phúc','1975/03/02',N'NULL',N'01650101234','VN');
--CAULACBO--
insert into CAULACBO
values('BBD',N'BECAMEX BÌNH DƯƠNG','GD','BD'),
('HAGL',N'HOÀNG ANH GIA LAI','PL','GL'),
('SDN',N'SHB ĐÀ NẴNG','CL','DN'),
('KKH',N'KHATOCO KHÁNH HOÀ','NT','KH'),
('TPY',N'THÉP PHÚ YÊN','TH','PY'),
('GDT',N'GẠCH ĐỒNG TÂM LONG','LA','LA');
--HLV_CLB--
insert into HLV_CLB
values('HLV01','BBD',N'HLV Chính'),
('HLV02','SDN',N'HLV Chính'),
('HLV03','HAGL',N'HLV Chính'),
('HLV04','KKH',N'HLV Chính'),
('HLV05','GDT',N'HLV Chính'),
('HLV06','BBD',N'HLV thủmôn');
--TRANDAU--
insert into TRANDAU(MATRAN,NAM,VONG,NGAYTD,MACLB1,MACLB2,MASAN,KETQUA) values
(1,2023,1,'2023/02/07','BBD','SDN','GD','3-0'),
(2,2023,1,'2023/03/07','KKH','GDT','NT','1-1'),
(3,2023,2,'2023/02/16','SDN','KKH','CL','2-2'),
(4,2023,2,'2023/02/16','TPY','BBD','TH','5-0'),
(5,2023,3,'2023/03/01','TPY','GDT','TH','0-2'),
(6,2023,3,'2023/03/01','KKH','BBD','NT','0-1'),
(7,2023,4,'2023/03/07','KKH','TPY','NT','1-0'),
(8,2023,4,'2023/03/07','BBD','GDT','GD','2-2');
--CAUTHU--
alter table CAUTHU add SO int;
insert into CAUTHU(HOTEN,VITRI,NGAYSINH,DIACHI,MACLB,MAQG,SO) values
(N'Nguyễn Vũ Phong',N'Tiền vệ','1990/02/20',N'NULL','BBD','VN',17),
(N'Nguyễn Công Vinh',N'Tiền đạo','1992/03/10',N'NULL','HAGL','VN',9),
(N'Trần Tấn Tài',N'Tiền vệ','1999/11/12',N'NULL','BBD','VN',8),
(N'Phan Hồng Sơn',N'Thủ môn','1991/06/10',N'NULL','HAGL','VN',1),
(N'Ronaldo',N'Tiền vệ','1989/10/12',N'NULL','SDN','BRA',7),
(N'Robinho',N'Tiền vệ','1989/10/12',N'NULL','SDN','BRA',8),
(N'Vidic',N'Hậu vệ','1987',N'NULL','HAGL','ANH',3),
(N'Trần Văn Santos',N'Thủ môn','1990/10/21',N'NULL','BBD','BRA',1),
(N'Nguyễn Trường Sơn',N'Hậu vệ','1993/08/26',N'NULL','BBD','VN',4);
--BANGXH--
insert into BANGXH
values('BBD',2023,1,1,1,0,0,'3-0',3,1),
('KKH',2023,1,1,0,1,0,'1-1',1,2),
('GDT',2023,1,1,0,1,0,'1-1',1,3),
('TPY',2023,1,0,0,0,0,'0-0',0,4),
('SDN',2023,1,1,0,0,1,'0-3',0,5),
('TPY',2023,2,1,1,0,0,'5-0',3,1),
('BBD',2023,2,2,1,0,1,'3-5',3,2),
('KKH',2023,2,2,0,2,0,'3-3',2,3),
('GDT',2023,2,1,0,1,0,'1-1',1,4),
('SDN',2023,2,2,1,1,0,'2-5',1,5),
('BBD',2023,3,3,2,0,1,'4-5',6,1),
('GDT',2023,3,2,1,1,0,'3-1',4,2),
('TPY',2023,3,2,1,0,1,'5-2',3,3),
('KKH',2023,3,3,0,2,1,'3-4',2,4),
('SDN',2023,3,2,1,1,0,'2-5',1,5),
('BBD',2023,4,4,2,1,1,'6-7',7,1),
('GDT',2023,4,3,1,2,0,'5-1',5,2),
('KKH',2023,4,4,1,2,1,'4-4',5,3),
('TPY',2023,4,3,1,0,2,'5-3',3,4),
('SDN',2023,4,2,1,1,0,'2-5',1,5);

select * FROM TINH
select * FROM QUOCGIA
select * FROM SANVD
select * FROM HUANLUYENVIEN
select * FROM CAULACBO
select * FROM HLV_CLB
select * FROM TRANDAU
select * FROM CAUTHU
select * FROM BANGXH