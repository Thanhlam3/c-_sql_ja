﻿

-- TẠO CƠ SỞ DỮ LIỆU
CREATE DATABASE QuanLyNhaHang;
GO
USE QuanLyNhaHang;
GO
 
-- BẢNG BAN (bàn ăn)
CREATE TABLE Ban (
    MaBan INT PRIMARY KEY,
    TenBan NVARCHAR(50),
    TrangThai NVARCHAR(50) -- VD: "Trống", "Đang dùng"
);
 
-- BẢNG NHÀ CUNG CẤP
CREATE TABLE NhaCungCap (
    MaNhaCungCap INT PRIMARY KEY,
    TenNhaCungCap NVARCHAR(100),
    DiaChi NVARCHAR(255),
    SDT VARCHAR(20)
);
 
-- BẢNG NGUYÊN LIỆU
CREATE TABLE NguyenLieu (
    MaNguyenLieu INT PRIMARY KEY,
    TenNguyenLieu NVARCHAR(100),
    DonViTinh NVARCHAR(20),
    SoLuongTon FLOAT,
    GiaNhap FLOAT,
    MaNhaCungCap INT,
    FOREIGN KEY (MaNhaCungCap) REFERENCES NhaCungCap(MaNhaCungCap)
);
 
-- BẢNG SẢN PHẨM
CREATE TABLE SanPham (
    MaSanPham INT PRIMARY KEY,
    TenSanPham NVARCHAR(100),
    GiaBan FLOAT,
    MoTa NVARCHAR(MAX)
);
 
-- CÔNG THỨC CHẾ BIẾN
CREATE TABLE CongThucCheBien (
    MaSanPham INT,
    MaNguyenLieu INT,
    SoLuongCan FLOAT,
    PRIMARY KEY (MaSanPham, MaNguyenLieu),
    FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSanPham),
    FOREIGN KEY (MaNguyenLieu) REFERENCES NguyenLieu(MaNguyenLieu)
);
 
-- NHÂN VIÊN
CREATE TABLE NhanVien (
    MaNhanVien INT PRIMARY KEY,
    TenNhanVien NVARCHAR(100),
    ChucVu NVARCHAR(50),
    SDT VARCHAR(20),
    Email VARCHAR(100),
    DiaChi NVARCHAR(255),
    MaBan INT,
    FOREIGN KEY (MaBan) REFERENCES Ban(MaBan)
);
 
-- KHÁCH HÀNG
CREATE TABLE KhachHang (
    MaKhachHang INT PRIMARY KEY,
    TenKhachHang NVARCHAR(100),
    SDT VARCHAR(20),
    DiaChi NVARCHAR(255),
    MaBan INT,
    FOREIGN KEY (MaBan) REFERENCES Ban(MaBan)
);
-- ĐƠN HÀNG 
 CREATE TABLE DonHang (
    MaDonHang INT PRIMARY KEY,
    MaKhachHang INT,
    FOREIGN KEY (MaKhachHang) REFERENCES KhachHang(MaKhachHang)
);
-- HÓA ĐƠN (liên kết với MaBan, MaSanPham)
CREATE TABLE HoaDon (
    MaHoaDon INT PRIMARY KEY,
	NgayLap DATE,
    TongTien FLOAT,
	MaDonHang INT,
	MaSanPham INT,
    MaBan INT,
	MaNhanVien INT,
    FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSanPham),
    FOREIGN KEY (MaBan) REFERENCES Ban(MaBan),
	FOREIGN KEY (MaDonHang) REFERENCES DonHang(MaDonHang),
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVien(MaNhanVien)
);
 
-- CHI TIẾT ĐƠN HÀNG (liên kết với HoaDon qua MaSanPham)
CREATE TABLE ChiTietDonHang (
    MaHoaDon INT,
    MaSanPham INT,
    SoLuong INT,
    DonGia FLOAT,
    PRIMARY KEY (MaHoaDon, MaSanPham),
    FOREIGN KEY (MaHoaDon) REFERENCES HoaDon(MaHoaDon),
    FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSanPham)
);
-- nhập dữ liệu
INSERT INTO Ban VALUES
(1, N'Bàn 1', N'Trống'),
(2, N'Bàn 2', N'Đang dùng'),
(3, N'Bàn 3', N'Đang dùng');
INSERT INTO KhachHang VALUES
(1, N'Lê Văn C', '0933333333', N'Đà Nẵng', 1),
(2, N'Phạm Thị D', '0944444444', N'Huế', 2),
(3, N'Hoàng Văn E', '0955555555', N'Cần Thơ', 3),
(4, N'Nguyễn Văn W', '0960000000', N'Hội An', 1);
INSERT INTO NhaCungCap VALUES
(1, N'Công ty ABC', N'123 Nguyễn Trãi', '0966666666'),
(2, N'Công ty XYZ', N'456 Lý Thường Kiệt', '0977777777');
INSERT INTO NguyenLieu VALUES
(1, N'Thịt bò', N'kg', 20, 100000, 1),
(2, N'Hành lá', N'kg', 5, 20000, 1),
(3, N'Tỏi', N'kg', 10, 30000, 2),
(4, N'Tiêu', N'gói', 3, 15000, 2);
INSERT INTO SanPham VALUES
(1, N'Bò lúc lắc', 150000, N'Món bò xào thơm ngon'),
(2, N'Canh chua', 80000, N'Món canh vị chua dịu'),
(3, N'Cơm rang', 60000, N'Cơm chiên trứng và rau củ');
INSERT INTO CongThucCheBien VALUES
(1, 1, 0.5), 
(1, 2, 0.1),
(2, 3, 0.2),
(1, 3, 0.2),
(1, 4, 0.2),
(3, 4, 0.05);
INSERT INTO DonHang VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 1), -- để có > 2 đơn
(5, 1);
INSERT INTO HoaDon VALUES
(1, '2024-05-01', 300000, 1, 1, 1, 1),
(2, '2024-05-02', 500000, 2, 2, 2, 2),
(3, '2024-05-03', 800000, 3, 3, 3, 1),
(4, '2024-05-04', 600000, 2, 1, 1, 1),
(5, '2024-05-05', 700000, 3, 2, 2, 2);
INSERT INTO ChiTietDonHang VALUES
(1, 1, 2, 150000), 
(2, 2, 3, 80000),  
(3, 1, 1, 150000),
(3, 2, 2, 80000),
(3, 3, 2, 60000),  
(4, 1, 2, 150000),
(4, 2, 2, 80000),
(5, 3, 3, 60000);
INSERT INTO NhanVien VALUES
(1, N'Nguyễn Văn A', N'Phục vụ', '0911111111', 'a@email.com', N'Hà Nội', 1),
(2, N'Trần Thị B', N'Thu ngân', '0922222222', 'b@email.com', N'Hồ Chí Minh', 2),
(3, N'Lê Văn C', N'Quản lý', '0933333333', 'c@email.com', N'Đà Nẵng', 3);



-- 1. Liệt kê toàn bộ nhà cung cấp
SELECT * FROM NhaCungCap;

-- 2. Lấy tên và giá bán các sản phẩm
SELECT TenSanPham, GiaBan FROM SanPham;

-- 3. Lấy tên và chức vụ nhân viên
SELECT TenNhanVien, ChucVu FROM NhanVien;

-- 4. Tính tổng số lượng tồn kho của nguyên liệu
SELECT SUM(SoLuongTon) AS TongTonKho FROM NguyenLieu;

-- 5. Tính giá trung bình của các sản phẩm
SELECT AVG(GiaBan) AS TrungBinhGia FROM SanPham;

-- 6. Đếm số lượng khách hàng
SELECT COUNT(*) AS SoLuongKhach FROM KhachHang;

-- 7. Tìm giá bán cao nhất trong các sản phẩm
SELECT MAX(GiaBan) AS GiaCaoNhat FROM SanPham;

-- 8. Tính tổng doanh thu của từng nhân viên
SELECT MaNhanVien, SUM(TongTien) AS DoanhThu
FROM HoaDon
GROUP BY MaNhanVien;

-- 9. Tính thành tiền của từng hóa đơn
SELECT MaHoaDon, SUM(DonGia * SoLuong) AS ThanhTien
FROM ChiTietDonHang
GROUP BY MaHoaDon;

-- 10. Đếm số lần bán của từng sản phẩm
SELECT MaSanPham, COUNT(*) AS SoLanBan
FROM ChiTietDonHang
GROUP BY MaSanPham;

-- 11. Tìm hóa đơn có tổng tiền > 100000
SELECT MaHoaDon, SUM(DonGia * SoLuong) AS TongTien
FROM ChiTietDonHang
GROUP BY MaHoaDon
HAVING SUM(DonGia * SoLuong) > 100000;

-- 12. Tính tổng doanh thu > 50000 theo nhân viên
SELECT MaNhanVien, SUM(TongTien) AS TongDoanhThu
FROM HoaDon
GROUP BY MaNhanVien
HAVING SUM(TongTien) > 50000;

-- 13. Tìm sản phẩm được bán > 2 lần
SELECT MaSanPham, COUNT(*) AS SoLan
FROM ChiTietDonHang
GROUP BY MaSanPham
HAVING COUNT(*) > 2;

-- 14. Tìm khách hàng có hơn 1 đơn hàng
SELECT MaKhachHang, COUNT(*) AS SoDon
FROM HoaDon JOIN DonHang ON HoaDon.MaDonHang = DonHang.MaDonHang
GROUP BY MaKhachHang
HAVING COUNT(*) > 1;

-- 15. Tìm nhà cung cấp có cung cấp > 1 nguyên liệu
SELECT MaNhaCungCap, COUNT(*) AS SoNguyenLieu
FROM NguyenLieu
GROUP BY MaNhaCungCap
HAVING COUNT(*) > 1;

-- 16. Tìm sản phẩm có giá thấp nhất
SELECT * FROM SanPham
WHERE GiaBan = (SELECT MIN(GiaBan) FROM SanPham);

-- 17. Tìm nhân viên lập nhiều hóa đơn nhất
SELECT TOP 1 MaNhanVien, COUNT(*) AS SoHoaDon
FROM HoaDon
GROUP BY MaNhanVien
ORDER BY SoHoaDon DESC;

-- 18. Tìm khách hàng chi nhiều tiền nhất
SELECT TOP 1 MaKhachHang, SUM(TongTien) AS Tong
FROM HoaDon JOIN DonHang ON HoaDon.MaDonHang = DonHang.MaDonHang
GROUP BY MaKhachHang
ORDER BY Tong DESC;

-- 19. Tìm khách hàng chưa từng mua hàng
SELECT * 
FROM KhachHang
WHERE MaKhachHang NOT IN (SELECT MaKhachHang FROM DonHang);

-- 20. Tìm sản phẩm chưa từng bán
SELECT * FROM SanPham
WHERE MaSanPham NOT IN (SELECT MaSanPham FROM ChiTietDonHang);

-- 21. Hiển thị tất cả nhân viên và mã hóa đơn nếu có
SELECT nv.TenNhanVien, hd.MaHoaDon
FROM HoaDon hd
RIGHT JOIN NhanVien nv ON hd.MaNhanVien = nv.MaNhanVien;

-- 22. Liệt kê hóa đơn kèm tên khách hàng và tổng tiền
SELECT hd.MaHoaDon, kh.TenKhachHang, hd.TongTien
FROM HoaDon hd
JOIN DonHang dh ON hd.MaDonHang = dh.MaDonHang
JOIN KhachHang kh ON dh.MaKhachHang = kh.MaKhachHang;

-- 23. Thống kê số lần bán của mỗi sản phẩm (kể cả chưa được bán)
SELECT sp.TenSanPham, COUNT(ctdh.MaSanPham) AS SoLanBan
FROM SanPham sp
LEFT JOIN ChiTietDonHang ctdh ON sp.MaSanPham = ctdh.MaSanPham
GROUP BY sp.TenSanPham;

-- 24. Danh sách tên nguyên liệu và tên sản phẩm (loại bỏ trùng)
SELECT TenNguyenLieu AS Ten FROM NguyenLieu
UNION
SELECT TenSanPham FROM SanPham;

-- 25. Tìm các sản phẩm vừa có trong ChiTietDonHang vừa có trong công thức
SELECT MaSanPham FROM ChiTietDonHang
INTERSECT
SELECT MaSanPham FROM CongThucCheBien;

-- 26. Tìm sản phẩm có trong công thức nhưng chưa từng bán
SELECT MaSanPham FROM CongThucCheBien
EXCEPT
SELECT MaSanPham FROM ChiTietDonHang;

-- 27. Tăng giá sản phẩm lên 10%
UPDATE SanPham 
SET GiaBan = GiaBan * 1.1;

-- 28. Giảm giá nhập nguyên liệu 5%
UPDATE NguyenLieu 
SET GiaNhap = GiaNhap * 0.95;

-- 29. Cập nhật tên nhà cung cấp có mã 1
UPDATE NhaCungCap 
SET TenNhaCungCap = 'Công ty ABC' 
WHERE MaNhaCungCap = 1;

-- 30. Đổi trạng thái bàn số 3 thành 'Đang dùng'
UPDATE Ban 
SET TrangThai = 'Đang dùng' 
WHERE MaBan = 3;

-- 31. Xóa khách chưa từng mua hàng
DELETE FROM KhachHang
WHERE MaKhachHang NOT IN (SELECT MaKhachHang FROM DonHang);

-- 32. Xóa sản phẩm chưa từng bán
DELETE FROM SanPham
WHERE MaSanPham NOT IN (SELECT MaSanPham FROM ChiTietDonHang);

-- 33. Xóa nguyên liệu chưa dùng trong công thức
DELETE FROM NguyenLieu
WHERE MaNguyenLieu NOT IN (SELECT MaNguyenLieu FROM CongThucCheBien);

-- 34. Tìm sản phẩm dùng tất cả các nguyên liệu trong công thức
SELECT sp.MaSanPham, sp.TenSanPham
FROM SanPham sp
WHERE NOT EXISTS (
    SELECT nl.MaNguyenLieu
    FROM NguyenLieu nl
    EXCEPT
    SELECT ct.MaNguyenLieu
    FROM CongThucCheBien ct
    WHERE ct.MaSanPham = sp.MaSanPham
);

-- 35. Tìm khách hàng đã mua tất cả sản phẩm
SELECT kh.MaKhachHang, kh.TenKhachHang
FROM KhachHang kh
WHERE NOT EXISTS (
    SELECT sp.MaSanPham
    FROM SanPham sp
    EXCEPT
    SELECT ctdh.MaSanPham
    FROM DonHang dh
    JOIN HoaDon hd ON dh.MaDonHang = hd.MaDonHang
    JOIN ChiTietDonHang ctdh ON hd.MaHoaDon = ctdh.MaHoaDon
    WHERE dh.MaKhachHang = kh.MaKhachHang
);


-- Thêm nguyên liệu mới
CREATE PROCEDURE ThemNguyenLieu
    @Ten NVARCHAR(100),
    @DonViTinh NVARCHAR(20),
    @SoLuong FLOAT,
    @GiaNhap FLOAT,
    @MaNCC INT
AS
BEGIN
    INSERT INTO NguyenLieu (TenNguyenLieu, DonViTinh, SoLuongTon, GiaNhap, MaNhaCungCap)
    VALUES (@Ten, @DonViTinh, @SoLuong, @GiaNhap, @MaNCC);
END;
-- gọi
EXEC ThemNguyenLieu 
    @Ten = N'Gừng',
    @DonViTinh = N'kg',
    @SoLuong = 10,
    @GiaNhap = 25000,
    @MaNCC = 2;

-- Liệt kê sản phẩm kèm nguyên liệu và số lượng cần
CREATE PROCEDURE LietKeSanPhamVaNguyenLieu
AS
BEGIN
    SELECT sp.TenSanPham, nl.TenNguyenLieu, ct.SoLuongCan
    FROM CongThucCheBien ct
    JOIN SanPham sp ON ct.MaSanPham = sp.MaSanPham
    JOIN NguyenLieu nl ON ct.MaNguyenLieu = nl.MaNguyenLieu
    ORDER BY sp.TenSanPham;
END;
--gọi
EXEC LietKeSanPhamVaNguyenLieu;

-- Cập nhật trạng thái bàn
CREATE PROCEDURE CapNhatTrangThaiBan
    @MaBan INT,
    @TrangThai NVARCHAR(50)
AS
BEGIN
    UPDATE Ban SET TrangThai = @TrangThai WHERE MaBan = @MaBan;
END;
--gọi
EXEC CapNhatTrangThaiBan @MaBan = 1, @TrangThai = N'Đang dùng';

-- Tính tổng tiền của một hóa đơn
CREATE FUNCTION TinhTongTienHoaDon(@MaHoaDon INT)
RETURNS FLOAT
AS
BEGIN
    DECLARE @Tong FLOAT;
    SELECT @Tong = SUM(SoLuong * DonGia)
    FROM ChiTietDonHang
    WHERE MaHoaDon = @MaHoaDon;
    RETURN @Tong;
END;
--gọi
SELECT dbo.TinhTongTienHoaDon(2) AS TongTienHoaDon;


-- Đếm số đơn hàng của một khách hàng
CREATE FUNCTION DemSoDonCuaKhach(@MaKhachHang INT)
RETURNS INT
AS
BEGIN
    DECLARE @SoDon INT;
    SELECT @SoDon = COUNT(*)
    FROM DonHang
    WHERE MaKhachHang = @MaKhachHang;
    RETURN @SoDon;
END;
--gọi 
SELECT dbo.DemSoDonCuaKhach(1) AS SoDonCuaKhachHang;



-- Cập nhật số lượng tồn kho khi có đơn hàng mới
CREATE TRIGGER trg_CapNhatTonKho
ON ChiTietDonHang
AFTER INSERT
AS
BEGIN
    UPDATE nl
    SET nl.SoLuongTon = nl.SoLuongTon - ct.SoLuongCan * i.SoLuong
    FROM NguyenLieu nl
    JOIN CongThucCheBien ct ON nl.MaNguyenLieu = ct.MaNguyenLieu
    JOIN inserted i ON ct.MaSanPham = i.MaSanPham;
END;
-- Chèn chi tiết đơn hàng mới vào bảng ChiTietDonHang
INSERT INTO ChiTietDonHang (MaHoaDon, MaSanPham, SoLuong, DonGia)
VALUES (1, 3, 1, 60000);
--
select *
from NguyenLieu

-- Kiểm tra không cho số lượng nguyên liệu bị âm
CREATE TRIGGER trg_KiemTraSoLuongNguyenLieu
ON NguyenLieu
AFTER INSERT, UPDATE
AS
BEGIN
    IF EXISTS (SELECT * FROM inserted WHERE SoLuongTon < 0)
    BEGIN
        RAISERROR('Số lượng nguyên liệu không được âm!', 16, 1);
        ROLLBACK;
    END
END;
--thêm
INSERT INTO NguyenLieu (MaNguyenLieu, TenNguyenLieu, DonViTinh, SoLuongTon, GiaNhap, MaNhaCungCap)
VALUES (10, N'Muối', N'kg', -2, 10000, 1);
-- Tự động tính tổng tiền hóa đơn khi thay đổi chi tiết đơn hàng
CREATE TRIGGER trg_TinhTongHoaDon
ON ChiTietDonHang
AFTER INSERT, DELETE, UPDATE
AS
BEGIN
    UPDATE hd
    SET TongTien = (
        SELECT SUM(SoLuong * DonGia)
        FROM ChiTietDonHang
        WHERE MaHoaDon = hd.MaHoaDon
    )
    FROM HoaDon hd
    WHERE hd.MaHoaDon IN (
        SELECT MaHoaDon FROM inserted
        UNION
        SELECT MaHoaDon FROM deleted
    );
END;
--
SELECT TongTien FROM HoaDon WHERE MaHoaDon = 3;


-- Tạo login cho người dùng
CREATE LOGIN QL_NhaHang WITH PASSWORD = 'MatKhauQL123';
CREATE LOGIN NV_PV WITH PASSWORD = 'MatKhauPV123';
CREATE LOGIN NV_Bep WITH PASSWORD = 'MatKhauBep123';
-- Tạo user tương ứng trong database (ví dụ database tên là QuanLyNhaHang)
USE QuanLyNhaHang;
CREATE USER QL_NhaHang FOR LOGIN QL_NhaHang;
CREATE USER NV_PV FOR LOGIN NV_PV;
CREATE USER NV_Bep FOR LOGIN NV_Bep;
-- Phân quyền
-- Người quản lý: toàn quyền
EXEC sp_addrolemember 'db_owner', 'QL_NhaHang';
-- Nhân viên phục vụ: chỉ xem và thêm đơn hàng
GRANT SELECT, INSERT ON DonHang TO NV_PV;
GRANT SELECT, INSERT ON SanPham TO NV_PV;
GRANT SELECT, INSERT ON Ban TO NV_PV;
-- Nhân viên bếp: chỉ xem nguyên liệu và công thức
GRANT SELECT ON NguyenLieu TO NV_Bep
GRANT SELECT ON CongThucCheBien TO NV_Bep;




 
 
 
 
 
 

