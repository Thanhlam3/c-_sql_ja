﻿create database QLKS;
go
use QLKS;

create table KhachSan (
	MaKS varchar(10) not null,
	TenKS nvarchar(70) not null,
	DiaChi nvarchar(30) not null
	constraint pk_KS primary key (MaKS)
)
create table Phong (
	MaPhong varchar(10) not null,
	MaKS varchar(10) not null,
	LoaiPhong varchar(10) not null,
	GiaPhong money not null
	constraint pk_Phong primary key (MaPhong),
	CONSTRAINT fk_Phong_KhachSan FOREIGN KEY (MaKS) REFERENCES KhachSan(MaKS)
)
create table KhachHang (
	MaKH varchar(10) not null ,
	HoTen nvarchar(20) not null,
	CMND varchar(20) not null,
	DiaChi nvarchar(20) not null
	constraint pk_KH primary key (MaKH)
)
create table DatPhong (
	MaDP varchar(10) not null,
	MaKH varchar(10) not null,
	MaPhong varchar(10) not null,
	NgayDen date not null,
	NgayDi date not null,
	SoNguoi varchar(10) not null
	constraint pk_DatPhong primary key (MaKH, MaPhong),
    CONSTRAINT fk_DatPhong_KhachHang FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    CONSTRAINT fk_DatPhong_Phong FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong)
)
/* them du lieu vao bang */
INSERT INTO KhachSan (MaKS, TenKS, DiaChi) VALUES
('KS001', N'Khách sạn A', N'Hà Nội'),
('KS002', N'Khách sạn B', N'Hồ Chí Minh'),
('KS003', N'Khách sạn C', N'Đà Nẵng'),
('KS004', N'Khách sạn D', N'Huế'),
('KS005', N'Khách sạn E', N'Hải Phòng');
INSERT INTO Phong (MaPhong, MaKS, LoaiPhong, GiaPhong) VALUES
('P101', 'KS001', N'Deluxe', 20000),
('P102', 'KS001', N'Standard', 15000),
('P201', 'KS002', N'VIP', 10000),
('P301', 'KS003', N'Family', 5000),
('P401', 'KS004', N'Single', 1000);
INSERT INTO KhachHang (MaKH, HoTen, CMND, DiaChi) VALUES
('KH001', N'Nguyễn Văn A', '123456789', N'Hà Nội'),
('KH002', N'Trần Thị B', '987654321', N'Hồ Chí Minh'),
('KH003', N'Lê Văn C', '456123789', N'Đà Nẵng'),
('KH004', N'Phạm Thị D', '789456123', N'Huế'),
('KH005', N'Hoàng Văn E', '321654987', N'Hải Phòng');
INSERT INTO DatPhong (MaDP, MaKH, MaPhong, NgayDen, NgayDi, SoNguoi) VALUES
('DP001', 'KH001', 'P101', '2024-04-01', '2024-04-05', 2),
('DP002', 'KH002', 'P102', '2024-05-03', '2024-05-06', 1),
('DP003', 'KH003', 'P201', '2024-06-10', '2024-06-15', 3),
('DP004', 'KH004', 'P301', '2024-06-12', '2024-06-14', 4),
('DP005', 'KH005', 'P401', '2024-07-20', '2024-07-25', 1);
 /* truy van */
 select kh.HoTen, kh.CMND, ks.TenKS, p.LoaiPhong
 From DatPhong dp
	 join KhachHang kh on dp.MaKH = kh.MaKH
	 join Phong p on dp.MaPhong = p.MaPhong
	 join KhachSan ks on p.MaKS = ks.MaKS
where MONTH(dp.NgayDen) = 6 AND YEAR(dp.NgayDen) = 2024;
/* */
SELECT 
    ks.TenKS,
    SUM(p.GiaPhong) AS TongDoanhThu
FROM DatPhong dp
	JOIN Phong p ON dp.MaPhong = p.MaPhong
	JOIN KhachSan ks ON p.MaKS = ks.MaKS
WHERE YEAR(dp.NgayDen) = 2024
GROUP BY ks.TenKS;
/* */
SELECT TOP 1 ks.TenKS, SUM(p.GiaPhong) AS TongDoanhThu
FROM DatPhong dp
	JOIN Phong p ON dp.MaPhong = p.MaPhong
	JOIN KhachSan ks ON p.MaKS = ks.MaKS
WHERE YEAR(dp.NgayDen) = 2024
GROUP BY ks.TenKS
ORDER BY TongDoanhThu DESC;
/* */
select kh.HoTen
from DatPhong dp
	JOIN Phong p ON dp.MaPhong = p.MaPhong
	JOIN KhachSan ks ON p.MaKS = ks.MaKS
	join KhachHang kh on dp.MaKH = kh.MaKH
GROUP BY kh.HoTen
HAVING COUNT(DISTINCT ks.MaKS) = (SELECT COUNT(*) FROM KhachSan);
/* */
CREATE PROCEDURE sp_ThemDatPhong
    @MaDP VARCHAR(10),
    @MaKH VARCHAR(10),
    @MaPhong VARCHAR(10),
    @NgayDen DATE,
    @NgayDi DATE,
    @SoNguoi INT
AS
BEGIN
    INSERT INTO DatPhong (MaDP, MaKH, MaPhong, NgayDen, NgayDi, SoNguoi)
    VALUES (@MaDP, @MaKH, @MaPhong, @NgayDen, @NgayDi, @SoNguoi);

    PRINT 'them dat phong thanh cong';
END;
EXEC sp_ThemDatPhong 
    @MaDP = 'DP001',
    @MaKH = 'KH01',
    @MaPhong = 'P101',
    @NgayDen = '2024-06-10',
    @NgayDi = '2024-06-15',
    @SoNguoi = 2;
/* */
CREATE FUNCTION fn_DanhSachDatPhongTheoCMND (@CMND VARCHAR(20))
RETURNS TABLE
AS
RETURN
(
    SELECT 
        KH.HoTen, 
        KH.CMND, 
        KS.TenKS, 
        P.LoaiPhong, 
        DP.NgayDen, 
        DP.NgayDi, 
        DP.SoNguoi
    FROM DatPhong DP
    JOIN KhachHang KH ON DP.MaKH = KH.MaKH
    JOIN Phong P ON DP.MaPhong = P.MaPhong
    JOIN KhachSan KS ON P.MaKS = KS.MaKS
    WHERE KH.CMND = @CMND
);

SELECT * FROM fn_DanhSachDatPhongTheoCMND('123456789');

