﻿/* de 1 */
create database tv;

use	tv;

create table DOC_GIA(
	MSDG varchar(10) not null,
	HoDG nvarchar(20) not null,
	TenDG nvarchar(30) not null,
	NgaySinh date,
	gioitinh char(10) not null ,
	diachi nvarchar(30) not null
	constraint pk_dg primary key (MSDG)
)
create table NhaXB(
	MaNXB varchar(20) not null,
	TenNXB nvarchar(255),
	diachi nvarchar(20)
	constraint pk_xb primary key (MaNXB),
)

create table SACH(
	MSS varchar(20) not null,
	Tensach nvarchar(100) not null,
	Sotraang int,
	namXB date,
	MaNXB varchar(20)
	constraint pk_s primary key (MSS),
	constraint fk_s_m FOREIGN KEY (MaNXB) REFERENCES NhaXB(MaNXB)
)
create table MUON(
	MSDG varchar(10) not null,
	MSS varchar(20) not null,
	NgayMuon date,
	NgayTra date
	constraint pk_m primary key (MSDG, MSS),
	constraint fk_m_dg FOREIGN KEY (MSDG) REFERENCES DOC_GIA(MSDG),
	constraint fk_m_s FOREIGN KEY (MSS) REFERENCES SACH(MSS)
)
/* nhap du lieu */

insert into DOC_GIA (MSDG, HoDG, TenDG, NgaySinh, GioiTinh, DiaChi) 
values 
('DG01', 'Nguyen', 'An', '1999-04-12', 'Nam', 'Hà Nội'),
('DG02', 'Tran', 'Binh', '2000-07-20', 'Nam', 'TP. HCM'),
('DG03', 'Le', 'Cuc', '1998-09-15', 'Nu', 'Đà Nẵng'),
('DG04', 'Pham', 'Dung', '2001-02-28', 'Nam', 'Hải Phòng'),
('DG05', 'Hoang', 'Lan', '2002-11-05', 'Nu', 'Cần Thơ');
insert into NhaXB (MaNXB, TenNXB, DiaChi)
values 
('NXB01', N'Kim Đồng', N'Hà Nội'),
('NXB02', N'Nhà xuất bản Giáo dục', N'Hồ Chí Minh'),
('NXB03', N'Lao Động', N'Đà Nẵng'),
('NXB04', N'Tuổi Trẻ', N'Cần Thơ'),
('NXB05', N'Văn Học', N'Hải Phòng');
insert into SACH (MSS, TenSach, Sotraang, NamXB, MaNXB)
values 
('S01', N'Dế Mèn Phiêu Lưu Ký', '200', '2010-01-01', 'NXB01'),
('S02', N'Lão Hạc', '150', '2005-01-01', 'NXB02'),
('S03', N'Chí Phèo', '180', '2015-01-01', 'NXB03'),
('S04', N'Tắt Đèn', '220', '2018-01-01', 'NXB04'),
('S05', N'Vợ Nhặt', '190', '2020-01-01', 'NXB05');
insert into MUON (MSDG, MSS, NgayMuon, NgayTra)
values 
('DG01', 'S01', '2024-03-01', '2024-03-15'),
('DG02', 'S02', '2024-02-20', '2024-03-10'),
('DG03', 'S03', '2024-01-15', '2024-02-01'),
('DG04', 'S04', '2024-03-05', '2024-03-20'),
('DG05', 'S05', '2024-02-28', '2024-03-14');
/* truy vân */
/* a */

SELECT s.Tensach, n.TenNXB, s.SoTraang
FROM SACH s
JOIN NhaXB n ON s.MaNXB = n.MaNXB
WHERE s.Sotraang <= 200 AND n.TenNXB = 'Nhà xuất bản Giáo dục';
/* b */
SELECT d.HoDG, s.Tensach, n.TenNXB, m.NgayMuon, m.NgayTra
FROM MUON m
JOIN DOC_GIA d ON m.MSDG = d.MSDG
JOIN SACH s ON m.MSS = s.MSS
JOIN NhaXB n ON s.MaNXB = n.MaNXB
WHERE YEAR(m.NgayMuon) = 2024 AND MONTH(m.NgayTra) <= 3 ;
/* c */
SELECT s.Tensach, COUNT(m.MSS) AS SoLanMuon
FROM MUON m
JOIN SACH s ON m.MSS = s.MSS
WHERE YEAR(m.Ngaymuon) = 2024
GROUP BY s.Tensach;
/* d */
DELETE FROM SACH 
WHERE MSS NOT IN (
    SELECT DISTINCT MSS FROM MUON 
    WHERE YEAR(Ngaymuon) BETWEEN 2014 AND 2024
);
/* e */
SELECT dg.TenDG
FROM DOC_GIA dg
JOIN MUON m ON dg.MSDG = m.MSDG
GROUP BY dg.MSDG, dg.TenDG
HAVING COUNT(DISTINCT m.MSS) = (SELECT COUNT(*) FROM SACH);
/* thu tuc */

/* a */
CREATE PROCEDURE TongSoLuongMuonSach
    @MSS varchar(20)
AS
BEGIN
    SELECT s.Tensach, COUNT(m.MSS) AS SoLanMuon
    FROM MUON m
    JOIN SACH s ON m.MSS = s.MSS
    WHERE m.MSS = @MSS
    GROUP BY s.Tensach;
END;

EXEC TongSoLuongMuonSach 'S01';
/* b */
CREATE PROCEDURE SoLanMuon
    @Nam INT
AS
BEGIN
    SELECT s.Tensach, COUNT(m.MSS) AS SoLanMuon
    FROM MUON m
    JOIN SACH s ON m.MSS = s.MSS
    WHERE YEAR(m.Ngaymuon) = @Nam
    GROUP BY s.Tensach;
END;

EXEC SoLanMuon 2023;
