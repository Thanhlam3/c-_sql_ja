﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class PTB1
    {
        protected double b, c;
        // dung protected thi lop dan xuat moi thay dc cac gia tri b,c
        public PTB1(double b = 0, double c = 0)
        {
            this.b = b;
            this.c = c;
        }
        public void nhap()
        {
            Console.Write("nhap gia tri b: ");
            while(!double.TryParse(Console.ReadLine(),out b));
                Console.WriteLine("nhap lai gia tri b: ");

            Console.Write("nhap gia tri c: ");
            while (!double.TryParse(Console.ReadLine(), out c)) ;
                Console.WriteLine("nhap lai gia tri c: ");
        }
        public void xuat()
        {
            Console.WriteLine($"{b}x + {c} = 0 ");
        }
        public void giai()
        {
            if (b == 0)
                if (c == 0)
                    Console.WriteLine("pt vsn");
                else
                    Console.WriteLine("pt vn");
            else
                Console.WriteLine($"pt co nghiem la {-c / b} ");
        }    
    }
    // lop dan xuat
    class PTB2:PTB1
    {
        double a;
        public PTB2(double a = 0, double b = 0, double c = 0):base(b,c)
        {
            this.a = a;
        }
        public new void nhap()
        {
            
            Console.Write("nhap gia tri a: ");
            while (!double.TryParse(Console.ReadLine(), out a)) ;
                Console.Write("nhap lai gia tri a: ");
            base.nhap();
        }
        public new void xuat()
        {
            Console.WriteLine($"{a}x^2 + {b}x + {c} = 0");
            
        }
        public new void giai()
        {

            if (a == 0)
            {
                base.giai();
            }
            else
            {
                // tinh delta
                double delta = b * b - 4 * a * c;
                double x1, x2;

                // tinh nghiem
                if (delta > 0)
                {
                    // ham trong math luon tra ve kieu double.
                    x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                    x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                    Console.Write($"Phuong trinh co 2 nghiem la: x1 = {x1} va x2 = {x2}");
                }
                else if (delta == 0)
                {
                    x1 = (-b / (2 * a));
                    Console.Write($"Phuong trinh co nghiem kep: x1 = x2 = {x1}");
                }
                else
                {
                    Console.Write("Phuong trinh vo nghiem!");
                }
            }
        }
    }
}
