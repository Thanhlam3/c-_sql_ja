﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class Phone
    {
        protected string MaSo, NhanHieu;
        protected double giaNhap;
        protected int namSx;

        public double GiaNhap { get => giaNhap; set => giaNhap = value; }
        public int NamSx { get => namSx; set => namSx = value; }

        public Phone(string MaSo = " ", string NhanHieu = " ", double GiaNhap = 0, int NamSx = 2020)
        {
            this.MaSo = MaSo;
            this.NhanHieu = NhanHieu;
            this.GiaNhap = GiaNhap;
            this.NamSx = NamSx;
        }
        public void nhap()
        {
            Console.Write("nhap ma so: ");
            MaSo = Console.ReadLine();
            Console.Write("nhap nhan hieu: ");
            NhanHieu = Console.ReadLine();
            Console.Write("nhap gia nhap: ");
            GiaNhap = double.Parse(Console.ReadLine());
            Console.Write("nhap nam san xuat: ");
            NamSx = int.Parse(Console.ReadLine());
        }
        public void xuat()
        {
            Console.Write($"ma so: {MaSo}, nhan hieu: {NhanHieu}, gia nhap: {GiaNhap}, nam san xuat: {NamSx}");
        }
        public double TinhThue()
        {           
            if(NhanHieu.CompareTo("iphone") == 0)           
                return GiaNhap * 0.1;           
            else           
                return  GiaNhap * 0.05;           
        }
    }
    class SmartPhone : Phone
    {
        int Memory;
        
        public SmartPhone(int Memory = 4, string MaSo = " ", string NhanHieu = " ", double GiaNhap = 0, int NamSx = 2020) : base(MaSo, NhanHieu, GiaNhap, NamSx)
        {
            this.Memory = Memory;
        }
        public new void nhap()
        {
            base.nhap();
            Console.Write("nhap dung luong dien thoai (gb): ");
            while (!int.TryParse(Console.ReadLine(), out Memory) || Memory <= 0 )
                Console.Write("nhap lai dung luong dien thoai (gb): ");
           
        }
        public new void xuat()
        {
            base.xuat();
            Console.Write($"\tdung luong: {Memory}");
        }
        public double TinhGiaBan()
        {

            if (Memory >= 128)
                return GiaNhap + 0.2 * GiaNhap + TinhThue();
            else if(Memory > 16)
                return GiaNhap + 0.1 * GiaNhap + TinhThue();
            else
                return GiaNhap + 0.05 * GiaNhap + TinhThue();
        }
    }
    // lop thao tac tren ssanh sach
    class DS_SmartPhone
    {
        List<SmartPhone> ls;

        public void nhapds()
        {
            int n;
            Console.Write("nhap so luong ssmartphone: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 30)
                Console.Write("nhap lai so luong ssmartphone: ");

            ls = new List<SmartPhone>(n);

            for(int i=0; i<n; i++)
            {
                Console.WriteLine("nhap thong tin dt thu {0}", i+1);
                SmartPhone dt = new SmartPhone();
                dt.nhap();
                ls.Add(dt);
            }
        }
        public void sapxep()
        {
            for (int i = 0; i < ls.Count; i++)
                for (int j = 0; j < ls.Count; j++)
                    if (ls[i].GiaNhap < ls[j].GiaNhap)
                    {
                        SmartPhone dt = new SmartPhone();
                        dt = ls[i];
                        ls[i] = ls[j];
                        ls[j] = dt;
                    }
        }
        public void xuatds()
        {
            foreach (SmartPhone dt in ls)
                dt.xuat();
        }
        public int dem()
        {
            int x;
            Console.Write("nhap nam sx can dem: ");
            while (!int.TryParse(Console.ReadLine(), out x) || x <= 1980)
                Console.Write("nhap lai nam sx can dem: ");

            int c = 0;
            foreach (SmartPhone dt in ls)
                if (dt.NamSx == x)
                    c++;
            return c;
        }
    }
}
