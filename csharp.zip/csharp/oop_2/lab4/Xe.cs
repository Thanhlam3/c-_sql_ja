﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    abstract class Xe
    {
        protected string name, color;
        protected double price;
        public Xe(string name="toyota", string color="red", double price =1000)
        {
            this.name = name;
            this.color = color;
            this.price = price;
        }

        public virtual void nhap()
        {
            Console.Write("nhap ten xe: ");
            name = Console.ReadLine();
            Console.Write("nhap mau xe: ");
            color = Console.ReadLine();
            Console.Write("nhap gia xe: ");
            price = double.Parse(Console.ReadLine());
        }
        public abstract double phi_trc_ba();
        
        public void xuat()
        {
            Console.WriteLine($"ten xe: {name}, mau sac: {color}, gia: {price}");
        }
    }
    class XeMay : Xe
    {
        bool register_data;
        public XeMay(bool register_data= true, string name = "toyota", string color = "red", double price = 1000):base(name,color,price)        
        {
            this.register_data = register_data;
        }
        public override void nhap()
        {
            base.nhap();
            Console.Write("nhap du lieu dk lan dau: ");
            register_data = bool.Parse(Console.ReadLine());
        }
        public override double phi_trc_ba()
        {
            if (register_data == true)
                return price * 0.05;
            else
                return price * 0.01;
        }
    }
    class XeHoi : Xe
    {
        int loaixe;
        public XeHoi(int loaixe=1, string name = "toyota", string color = "red", double price = 1000) : base(name, color, price)
        {
            this.loaixe = loaixe;
        }
        public override void nhap()
        {
            Console.WriteLine("nhap loai xe (1,2,...): ");
            loaixe = int.Parse(Console.ReadLine());
            base.nhap();
        }
        public override double phi_trc_ba()
        {
            if (loaixe == 1)
                return price * 0.1;
            else if (loaixe == 2)
                return price * 0;
            else
                return price * 0.02;
        }
    }
    class DS_xe
    {
        List<Xe> ls;
        public void nhapds()
        {
            int n;
            Console.Write("nhap so luong xe: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 20)
                Console.Write("nhap lai so luong xe: ");

            ls = new List<Xe>(n);
            bool choice;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("xe thu {0} la xe may (true/false): ", i + 1);
                while (!bool.TryParse(Console.ReadLine(), out choice))
                    Console.WriteLine("xe thu {0} la xe may (true/false): ", i + 1);
                Xe x;
                if (choice)
                    // co the them console de nhap cac gia tri a,b,c, ten hinh
                    x = new XeMay();
                else
                    x = new XeHoi();
                x.nhap();
                ls.Add(x);
            }
        }
        public void xuatLS()
        {
            foreach (var xe in ls)
                xe.xuat();
        }
        public int dem()
        {          
            int c = 0;
            for (int i = 0; i < ls.Count; i++)
            {
                if (ls[i].GetType() == typeof(XeMay))         
                    c++;               
            }
            return c;
        }
        public double avg_phitrcba()
        {
            double s = 0;
            int c = 0;
            for (int i = 0; i < ls.Count; i++)
            {
                if (ls[i].GetType() == typeof(XeHoi))
                {
                    s += ls[i].phi_trc_ba();
                    c++;

                }

            }
            return s / c;
        }
    }
}
