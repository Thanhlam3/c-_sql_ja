﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class Program
    {
        static void bai4_1()
        {
            PTB1 p1 = new PTB1(3, 4);
            p1.nhap();
            p1.xuat();
            p1.giai();
            Console.WriteLine("pt bac 2:");
            PTB2 p2 = new PTB2();
            p2.nhap();
            p2.xuat();
            p2.giai();
        }
        static void bai4_2()
        {
            DS_SmartPhone ds = new DS_SmartPhone();
            ds.nhapds();
            ds.sapxep();
            ds.xuatds();
           
            ds.dem();
            Console.WriteLine($"so luong smartphone co nam la x: {ds.dem()}");
        }
        static void bai4_3()
        {
            DS_Shape ls = new DS_Shape();
            ls.nhapds();
            ls.xuatLS();
            Console.WriteLine("dien tich tb cua hcn {0}", ls.avg_hcn());
        }
        static void bai4_4()
        {
            Pixel p1 = new Pixel();
            Colored_Pixel p2 = new Colored_Pixel();
            p1.ktu_o();
            p2.ktu_o();
        }
        static void bai4_5()
        {
            DS_xe dsXe = new DS_xe();
            dsXe.nhapds();
            dsXe.xuatLS();

            Console.WriteLine($"\nso luong xe may: {dsXe.dem()}");
            Console.WriteLine($"tb phi trc ba: {dsXe.avg_phitrcba()}");

        }
        static void Main(string[] args)
        {
            bai4_5();
            Console.ReadKey();
        }
    }
}
