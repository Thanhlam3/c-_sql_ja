﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class Shape
    {
        string tenHinh;
        public Shape(string tenHinh = " ")
        {
            this.tenHinh = tenHinh;
        }

        public virtual double ChuVi()
        {
            return 0;
        }
        public virtual double DienTich()
        {
            return 0;
        }

        public void xuat()
        {
            Console.WriteLine($"ten hinh: {tenHinh}, chu vi: {ChuVi()}, dien tich: {DienTich()}");
        }
    }
    class TamGiac : Shape
    {
        double a, b, c;
        public TamGiac(double a = 1, double b = 1, double c = 1, string tenHinh = " ") : base(tenHinh)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        public override double ChuVi()
        {
            return a + b + c;
        }
        public override double DienTich()
        {
            double p = ChuVi() / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
        }
    }
    class HCN : Shape
    {
        double a, b;
        public HCN(double a = 1, double b = 1, string tenHinh = " ") : base(tenHinh)
        {
            this.a = a;
            this.b = b;
        }
        public override double ChuVi()
        {
            return (a + b) * 2;
        }
        public override double DienTich()
        {
            return a * b;
        }
    }
    class DS_Shape
    {
        List<Shape> ls;

        public void nhapds()
        {
            int n;
            Console.Write("nhap so luong hinh: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 20)
                Console.Write("nhap lai so luong hinh: ");

            ls = new List<Shape>(n);
            bool choice;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("hinh thu {0} la hcn (true/false): ", i + 1);
                while(!bool.TryParse(Console.ReadLine(), out choice))
                    Console.WriteLine("hinh thu {0} la hcn (true/false): ", i + 1);
                Shape sha;
                if (choice)
                    // co the them console de nhap cac gia tri a,b,c, ten hinh
                     sha = new HCN();
                else
                    sha = new TamGiac();
                ls.Add(sha);
            }
        }
        public void xuatLS()
        {
            foreach (var shape in ls)
                shape.xuat();
        }
        public double avg_hcn()
        {
            double s = 0;
            int c = 0;
            for(int i=0; i<ls.Count; i++)
            {
                if (ls[i].GetType() == typeof(HCN))
                {
                    s += ls[i].ChuVi();
                    c++;
                    
                }           
                
            }
            return s / c;
        }
    }
}
