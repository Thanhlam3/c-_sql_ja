﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    class Pixel
    {
        protected int x, y;
        public Pixel(int x = 9, int y = 3)
        {
            this.x = x;
            this.y = y;
        }
        public void ktu_o()
        {
            Console.SetCursorPosition(x, y);
            Console.Write("o");
        }
    }
    class Colored_Pixel : Pixel 
    {
        ConsoleColor c;
        public Colored_Pixel(ConsoleColor c = ConsoleColor.Blue, int x = 9, int y = 5) : base(x, y)
        {
            this.c = c;
        }
        public new void ktu_o()
        {
            Console.ForegroundColor = c;
            base.ktu_o();
        }
    }

}
