﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtTenLogin.Text == "123abc" && txtMK.Text == "abc")
            {
                MessageBox.Show("dang nhap thanh cong", "thong bao");
                this.Close();
            }
            else
                if (MessageBox.Show("dang nhap that bai \n ban co muon nhap lai khong",
                    "thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                txtTenLogin.Text = "";
                txtMK.Clear();
            }
            else
                Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
