﻿namespace lab5
{
    partial class form_bai5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.heThongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btCacDkCoBanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bai52ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btCacDkNangCaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bai53ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.heThongToolStripMenuItem,
            this.btCacDkCoBanToolStripMenuItem,
            this.btCacDkNangCaoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // heThongToolStripMenuItem
            // 
            this.heThongToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.thoatToolStripMenuItem});
            this.heThongToolStripMenuItem.Name = "heThongToolStripMenuItem";
            this.heThongToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.heThongToolStripMenuItem.Text = "he thong";
            this.heThongToolStripMenuItem.Click += new System.EventHandler(this.heThongToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.loginToolStripMenuItem.Text = "login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // btCacDkCoBanToolStripMenuItem
            // 
            this.btCacDkCoBanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bai52ToolStripMenuItem});
            this.btCacDkCoBanToolStripMenuItem.Name = "btCacDkCoBanToolStripMenuItem";
            this.btCacDkCoBanToolStripMenuItem.Size = new System.Drawing.Size(132, 24);
            this.btCacDkCoBanToolStripMenuItem.Text = "bt cac dk co ban";
            // 
            // bai52ToolStripMenuItem
            // 
            this.bai52ToolStripMenuItem.Name = "bai52ToolStripMenuItem";
            this.bai52ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.bai52ToolStripMenuItem.Text = "bai 5-2";
            // 
            // btCacDkNangCaoToolStripMenuItem
            // 
            this.btCacDkNangCaoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bai53ToolStripMenuItem});
            this.btCacDkNangCaoToolStripMenuItem.Name = "btCacDkNangCaoToolStripMenuItem";
            this.btCacDkNangCaoToolStripMenuItem.Size = new System.Drawing.Size(148, 24);
            this.btCacDkNangCaoToolStripMenuItem.Text = "bt cac dk nang cao";
            // 
            // bai53ToolStripMenuItem
            // 
            this.bai53ToolStripMenuItem.Name = "bai53ToolStripMenuItem";
            this.bai53ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.bai53ToolStripMenuItem.Text = "bai 5-3";
            // 
            // thoatToolStripMenuItem
            // 
            this.thoatToolStripMenuItem.Name = "thoatToolStripMenuItem";
            this.thoatToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.thoatToolStripMenuItem.Text = "thoat";
            this.thoatToolStripMenuItem.Click += new System.EventHandler(this.thoatToolStripMenuItem_Click);
            // 
            // form_bai5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "form_bai5";
            this.Text = "form_bai5";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem heThongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btCacDkCoBanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bai52ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btCacDkNangCaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bai53ToolStripMenuItem;
    }
}