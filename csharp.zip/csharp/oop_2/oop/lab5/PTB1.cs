﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5
{
    class PTB1
    {
        protected double b, c;
        public PTB1() { }
        public PTB1(double b, double c)
        {
            this.b = b;
            this.c = c;
        }
        // giai
        public string giai()
        {
            if (b == 0)
                if (c == 0)
                    return "pt vn";
                else
                    return "pt vsn";
            else
                return "pt co no x = " + (-c / b).ToString();
        }
    }
    class PTB2 : PTB1
    {
        double a;
        public PTB2() : base() { }
        public PTB2 (double a , double b, double c) : base(b,c)
        {
            this.a = a;
        }
        public new string giai()
        {
            if (a == 0)
                return base.giai();
            else
            {
                double del = b * b - (4 * a * c);
                if (del < 0)
                    return "pt vn";
                else if(del == 0)
                {
                    double x = -b / (2 * a);
                    return " pt co nghiem x1 = x2 = " + x.ToString();
                }
                else
                {
                    double x1 = (-b - Math.Sqrt(del)) / (2 * a);
                    double x2 = (-b + Math.Sqrt(del)) / (2 * a);
                    return "pt co 2 no x1 = " + x1.ToString() + "," + x2.ToString();
                }
            }
        }
    }
}
