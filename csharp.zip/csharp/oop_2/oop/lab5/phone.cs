﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5
{
    class phone : IComparable<phone>
    {
        public string maSo { get; set; }
        public string nhanHieu { get; set; }
        public double giaNhap { get; set; }
        public string hinhAnh { get; set; }
        public phone() { }
        public phone(string ma, string hieu, double gia, string anh)
        {
            maSo = ma;
            nhanHieu = hieu;
            giaNhap = gia;
            hinhAnh = anh;
        }
        public double TinhGB()
        {
            if (nhanHieu.CompareTo("iphone") == 0)
                return giaNhap * 1.5f;
            else
                return giaNhap * 1.3f;
        }
        // dk so sanh trog  phuong thuc sort cua list
        public int CompareTo(phone other)
        {
            if (giaNhap < other.giaNhap) return 1;
            else if (giaNhap == other.giaNhap) return 0;
            else return -1;
        }
    }
}
