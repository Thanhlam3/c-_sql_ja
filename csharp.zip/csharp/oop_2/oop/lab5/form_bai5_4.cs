﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class form_bai5_4 : Form
    {
        string inputCode = "";
        Dictionary<string, List<string>> accessCodes = new Dictionary<string, List<string>>()
        {
            { "Technician", new List<string> { "2643" } },
            { "Scientist", new List<string> { "6372" } },
            { "Employee", new List<string> { "9652", "9843" } },
            { "Boss", new List<string> { "1947" } }
        };

        public form_bai5_4()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "1";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "2";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "3";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "4";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "5";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "6";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "7";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "8";
                txtSecurityCode.Text += "*";
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (inputCode.Length < 4)
            {
                inputCode += "9";
                txtSecurityCode.Text += "*";
            }
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            inputCode = "";
            txtSecurityCode.Text = "";
        }

        private void btnThang_Click(object sender, EventArgs e)
        {
            string role = accessCodes.FirstOrDefault(pair => pair.Value.Contains(inputCode)).Key;

            if (role != null)
            {
                listBoxAccess.Items.Add($"{DateTime.Now}: {role}");
            }
            else
            {
                MessageBox.Show("Access Denied!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // dat lai input
            inputCode = "";
            txtSecurityCode.Text = "";
        }
    }
}
