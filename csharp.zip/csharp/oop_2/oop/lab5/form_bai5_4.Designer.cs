﻿namespace lab5
{
    partial class form_bai5_4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSecurityCode = new System.Windows.Forms.TextBox();
            this.lbSecu = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btnThang = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxAccess = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtSecurityCode
            // 
            this.txtSecurityCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtSecurityCode.Location = new System.Drawing.Point(283, 34);
            this.txtSecurityCode.Name = "txtSecurityCode";
            this.txtSecurityCode.PasswordChar = '*';
            this.txtSecurityCode.Size = new System.Drawing.Size(282, 28);
            this.txtSecurityCode.TabIndex = 5;
            // 
            // lbSecu
            // 
            this.lbSecu.AutoSize = true;
            this.lbSecu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbSecu.ForeColor = System.Drawing.Color.Blue;
            this.lbSecu.Location = new System.Drawing.Point(136, 40);
            this.lbSecu.Name = "lbSecu";
            this.lbSecu.Size = new System.Drawing.Size(116, 22);
            this.lbSecu.TabIndex = 6;
            this.lbSecu.Text = "security code";
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(12, 87);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(107, 40);
            this.btn1.TabIndex = 7;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(145, 87);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(107, 40);
            this.btn2.TabIndex = 8;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(421, 229);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(107, 40);
            this.btn0.TabIndex = 9;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(145, 163);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(107, 40);
            this.btn5.TabIndex = 10;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(283, 87);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(107, 40);
            this.btn3.TabIndex = 11;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(12, 229);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(107, 40);
            this.btn7.TabIndex = 12;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btnThang
            // 
            this.btnThang.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnThang.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnThang.Location = new System.Drawing.Point(421, 163);
            this.btnThang.Name = "btnThang";
            this.btnThang.Size = new System.Drawing.Size(107, 40);
            this.btnThang.TabIndex = 13;
            this.btnThang.Text = "#";
            this.btnThang.UseVisualStyleBackColor = false;
            this.btnThang.Click += new System.EventHandler(this.btnThang_Click);
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnC.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnC.Location = new System.Drawing.Point(421, 87);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(107, 40);
            this.btnC.TabIndex = 14;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(145, 229);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(107, 40);
            this.btn8.TabIndex = 15;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(283, 163);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(107, 40);
            this.btn6.TabIndex = 16;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(283, 229);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(107, 40);
            this.btn9.TabIndex = 17;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(12, 163);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(107, 40);
            this.btn4.TabIndex = 18;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(543, 247);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 22);
            this.label1.TabIndex = 19;
            this.label1.Text = "access log";
            // 
            // listBoxAccess
            // 
            this.listBoxAccess.FormattingEnabled = true;
            this.listBoxAccess.ItemHeight = 16;
            this.listBoxAccess.Location = new System.Drawing.Point(21, 287);
            this.listBoxAccess.Name = "listBoxAccess";
            this.listBoxAccess.Size = new System.Drawing.Size(747, 132);
            this.listBoxAccess.TabIndex = 20;
            // 
            // form_bai5_4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBoxAccess);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnThang);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.lbSecu);
            this.Controls.Add(this.txtSecurityCode);
            this.Name = "form_bai5_4";
            this.Text = "form_bai5_4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSecurityCode;
        private System.Windows.Forms.Label lbSecu;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btnThang;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxAccess;
    }
}