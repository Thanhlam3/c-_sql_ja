﻿namespace lab5
{
    partial class form_bai5_3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMS = new System.Windows.Forms.TextBox();
            this.txtgia = new System.Windows.Forms.TextBox();
            this.txtgiaban = new System.Windows.Forms.TextBox();
            this.lblHeso_c = new System.Windows.Forms.Label();
            this.lblHeso_b = new System.Windows.Forms.Label();
            this.lblHeso_a = new System.Windows.Forms.Label();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.cmbNh = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.bntSapXep = new System.Windows.Forms.Button();
            this.bntXoa = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bntTinhGB = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dvgDanhSach = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dvgDanhSach)).BeginInit();
            this.SuspendLayout();
            // 
            // txtMS
            // 
            this.txtMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMS.Location = new System.Drawing.Point(136, 49);
            this.txtMS.Name = "txtMS";
            this.txtMS.Size = new System.Drawing.Size(173, 28);
            this.txtMS.TabIndex = 12;
            // 
            // txtgia
            // 
            this.txtgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtgia.Location = new System.Drawing.Point(136, 154);
            this.txtgia.Name = "txtgia";
            this.txtgia.Size = new System.Drawing.Size(173, 28);
            this.txtgia.TabIndex = 11;
            // 
            // txtgiaban
            // 
            this.txtgiaban.Enabled = false;
            this.txtgiaban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtgiaban.Location = new System.Drawing.Point(136, 204);
            this.txtgiaban.Name = "txtgiaban";
            this.txtgiaban.Size = new System.Drawing.Size(173, 28);
            this.txtgiaban.TabIndex = 10;
            // 
            // lblHeso_c
            // 
            this.lblHeso_c.AutoSize = true;
            this.lblHeso_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHeso_c.ForeColor = System.Drawing.Color.Blue;
            this.lblHeso_c.Location = new System.Drawing.Point(31, 154);
            this.lblHeso_c.Name = "lblHeso_c";
            this.lblHeso_c.Size = new System.Drawing.Size(79, 22);
            this.lblHeso_c.TabIndex = 9;
            this.lblHeso_c.Text = "gia nhap";
            // 
            // lblHeso_b
            // 
            this.lblHeso_b.AutoSize = true;
            this.lblHeso_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHeso_b.ForeColor = System.Drawing.Color.Blue;
            this.lblHeso_b.Location = new System.Drawing.Point(31, 103);
            this.lblHeso_b.Name = "lblHeso_b";
            this.lblHeso_b.Size = new System.Drawing.Size(89, 22);
            this.lblHeso_b.TabIndex = 8;
            this.lblHeso_b.Text = "nhan hieu";
            // 
            // lblHeso_a
            // 
            this.lblHeso_a.AutoSize = true;
            this.lblHeso_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHeso_a.ForeColor = System.Drawing.Color.Blue;
            this.lblHeso_a.Location = new System.Drawing.Point(31, 55);
            this.lblHeso_a.Name = "lblHeso_a";
            this.lblHeso_a.Size = new System.Drawing.Size(58, 22);
            this.lblHeso_a.TabIndex = 7;
            this.lblHeso_a.Text = "ma so";
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.Red;
            this.lblTieuDe.Location = new System.Drawing.Point(266, 9);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(276, 32);
            this.lblTieuDe.TabIndex = 13;
            this.lblTieuDe.Text = "thong tin dien thoai";
            // 
            // cmbNh
            // 
            this.cmbNh.FormattingEnabled = true;
            this.cmbNh.Items.AddRange(new object[] {
            "iphone",
            "samsung",
            "vivo",
            "xiaomi",
            "iqoo",
            "redmi"});
            this.cmbNh.Location = new System.Drawing.Point(136, 101);
            this.cmbNh.Name = "cmbNh";
            this.cmbNh.Size = new System.Drawing.Size(173, 24);
            this.cmbNh.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(31, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 22);
            this.label1.TabIndex = 15;
            this.label1.Text = "gia ban";
            // 
            // btnDong
            // 
            this.btnDong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnDong.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnDong.Location = new System.Drawing.Point(651, 267);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(138, 39);
            this.btnDong.TabIndex = 16;
            this.btnDong.Text = "dong";
            this.btnDong.UseVisualStyleBackColor = false;
            // 
            // bntSapXep
            // 
            this.bntSapXep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bntSapXep.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bntSapXep.ForeColor = System.Drawing.Color.Fuchsia;
            this.bntSapXep.Location = new System.Drawing.Point(493, 267);
            this.bntSapXep.Name = "bntSapXep";
            this.bntSapXep.Size = new System.Drawing.Size(138, 39);
            this.bntSapXep.TabIndex = 17;
            this.bntSapXep.Text = "sap xep";
            this.bntSapXep.UseVisualStyleBackColor = false;
            // 
            // bntXoa
            // 
            this.bntXoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bntXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bntXoa.ForeColor = System.Drawing.Color.Fuchsia;
            this.bntXoa.Location = new System.Drawing.Point(181, 267);
            this.bntXoa.Name = "bntXoa";
            this.bntXoa.Size = new System.Drawing.Size(138, 39);
            this.bntXoa.TabIndex = 18;
            this.bntXoa.Text = "xoa";
            this.bntXoa.UseVisualStyleBackColor = false;
            this.bntXoa.Click += new System.EventHandler(this.bntXoa_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button3.ForeColor = System.Drawing.Color.Fuchsia;
            this.button3.Location = new System.Drawing.Point(13, 267);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 39);
            this.button3.TabIndex = 19;
            this.button3.Text = "them";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button_them_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(561, 85);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(172, 177);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // bntTinhGB
            // 
            this.bntTinhGB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bntTinhGB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bntTinhGB.ForeColor = System.Drawing.Color.Fuchsia;
            this.bntTinhGB.Location = new System.Drawing.Point(335, 267);
            this.bntTinhGB.Name = "bntTinhGB";
            this.bntTinhGB.Size = new System.Drawing.Size(138, 39);
            this.bntTinhGB.TabIndex = 21;
            this.bntTinhGB.Text = "tinh gia ban";
            this.bntTinhGB.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button5.ForeColor = System.Drawing.Color.Fuchsia;
            this.button5.Location = new System.Drawing.Point(578, 27);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(138, 39);
            this.button5.TabIndex = 22;
            this.button5.Text = "hinh anh";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // dvgDanhSach
            // 
            this.dvgDanhSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgDanhSach.Location = new System.Drawing.Point(36, 312);
            this.dvgDanhSach.Name = "dvgDanhSach";
            this.dvgDanhSach.RowHeadersWidth = 51;
            this.dvgDanhSach.RowTemplate.Height = 24;
            this.dvgDanhSach.Size = new System.Drawing.Size(731, 123);
            this.dvgDanhSach.TabIndex = 23;
            // 
            // form_bai5_3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dvgDanhSach);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.bntTinhGB);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.bntXoa);
            this.Controls.Add(this.bntSapXep);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbNh);
            this.Controls.Add(this.lblTieuDe);
            this.Controls.Add(this.txtMS);
            this.Controls.Add(this.txtgia);
            this.Controls.Add(this.txtgiaban);
            this.Controls.Add(this.lblHeso_c);
            this.Controls.Add(this.lblHeso_b);
            this.Controls.Add(this.lblHeso_a);
            this.Name = "form_bai5_3";
            this.Text = "form_bai5_3";
            this.Load += new System.EventHandler(this.form_bai5_3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dvgDanhSach)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMS;
        private System.Windows.Forms.TextBox txtgia;
        private System.Windows.Forms.TextBox txtgiaban;
        private System.Windows.Forms.Label lblHeso_c;
        private System.Windows.Forms.Label lblHeso_b;
        private System.Windows.Forms.Label lblHeso_a;
        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.ComboBox cmbNh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.Button bntSapXep;
        private System.Windows.Forms.Button bntXoa;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bntTinhGB;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dvgDanhSach;
    }
}