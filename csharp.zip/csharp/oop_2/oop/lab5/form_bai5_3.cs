﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class form_bai5_3: Form
    {
        List<phone> ls;
        string path = ""; // duong dan den file anh
        public form_bai5_3()
        {
            InitializeComponent();
        }
        void doc_file()
        {
            ls = new List<phone>();
            FileStream f = new FileStream("F:\\ip11.txt", FileMode.Open);
            StreamReader sr = new StreamReader(f);
            string line; 
            while((line = sr.ReadLine()) != null)
            {
                string ma = line;
                string hieu = sr.ReadLine();
                double gia = double.Parse(sr.ReadLine());
                string duong = sr.ReadLine();
                phone dt = new phone(ma, hieu, gia, duong);
                ls.Add(dt);
            }
            f.Close();
        }
        private void form_bai5_3_Load(object sender, EventArgs e)
        {
            // doc file
            doc_file();
            
            dvgDanhSach.DataSource = ls;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Image file|*.jpg";
            if(dlg.ShowDialog() == DialogResult.OK)
            {
                path = dlg.FileName;
                pictureBox1.Image = Image.FromFile(path);
            }
        }

        
        private void bntXoa_Click(object sender, EventArgs e)
        {
            //tìm vị trí của đối tượng
            int p = ls.FindIndex(d => d.maSo == txtMS.Text);
            if (p >= 0)//tìm thấy
                ls.RemoveAt(p);
            else
                MessageBox.Show("Dien thoai nay khong co trong danh sach!", "Thông báo");
            //cập nhật lại datagrid
            dvgDanhSach.DataSource = null;
            dvgDanhSach.DataSource = ls;
            //xóa textbox
            txtMS.Clear();
        }

        private void bntTinhGB_Click(object sender, EventArgs e)
        {
            //tìm  đối tượng
            phone p = ls.Find(d => d.maSo == txtMS.Text);
            if (p != null)//tìm thấy
                txtgia.Text = p.TinhGB().ToString(); //hiển thị giá bán lên textbox
            else
                MessageBox.Show("Dien thoai nay khong co trong danh sach!", "Thông báo");
        }

        private void bntSapXep_Click(object sender, EventArgs e)
        {
            ls.Sort();//lấy điều kiện sắp xếp trong CompareTo() của Icompareable
            //cập nhật lại datagrid
            dvgDanhSach.DataSource = null;
            dvgDanhSach.DataSource = ls;
        }

        private void bntDong_Click(object sender, EventArgs e)
        {
            Close();
            //ghi dữ liệu vào file SV tự viết

        }

        private void button_them_Click(object sender, EventArgs e)
        {
            string ma = txtMS.Text;
            string hieu = cmbNh.Text;
            float gia = float.Parse(txtgia.Text);
            phone dt = new phone(ma, hieu, gia, path);
            ls.Add(dt);
            //cập nhật lại datagrid
            dvgDanhSach.DataSource = null;
            dvgDanhSach.DataSource = ls;
            //xóa textbox
            txtMS.Clear();
            txtgia.Text = "";
        }
    }
}
