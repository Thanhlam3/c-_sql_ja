﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class form_bai2: Form
    {
        public form_bai2()
        {
            InitializeComponent();
        }

        private void form_bai2_Load(object sender, EventArgs e)
        {
            rdbPtb1.Checked = true;
            txtHeso_c.Enabled = false;
        }

        private void rdbPtb1_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbPtb1.Checked)
            {
                txtHeso_c.Enabled = false;
                rdbPtb2.Checked = false;
            }
            else
            {
                txtHeso_c.Enabled = true;
                rdbPtb2.Checked = true;
            }
        }

        private void btnTH_Click(object sender, EventArgs e)
        {
            double a = double.Parse(txtHeso_a.Text);
            double b = double.Parse(txtHeso_b.Text);
            if (rdbPtb1.Checked)
            {
                PTB1 ptb1 = new PTB1(a, b);
                txtketqua.Text = ptb1.giai();
            }
            else
            {
                double c = double.Parse(txtHeso_c.Text);
                PTB2 ptb2 = new PTB2(a, b, c);
                txtketqua.Text = ptb2.giai();
            }
        }
    }
}
