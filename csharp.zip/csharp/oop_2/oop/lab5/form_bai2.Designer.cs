﻿namespace lab5
{
    partial class form_bai2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.lblHeso_a = new System.Windows.Forms.Label();
            this.lblHeso_b = new System.Windows.Forms.Label();
            this.lblHeso_c = new System.Windows.Forms.Label();
            this.txtHeso_b = new System.Windows.Forms.TextBox();
            this.txtHeso_c = new System.Windows.Forms.TextBox();
            this.txtHeso_a = new System.Windows.Forms.TextBox();
            this.lblketqua = new System.Windows.Forms.Label();
            this.txtketqua = new System.Windows.Forms.TextBox();
            this.btnTH = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbPtb1 = new System.Windows.Forms.RadioButton();
            this.rdbPtb2 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.Red;
            this.lblTieuDe.Location = new System.Drawing.Point(270, 48);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(243, 32);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "giai phuong trinh";
            // 
            // lblHeso_a
            // 
            this.lblHeso_a.AutoSize = true;
            this.lblHeso_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHeso_a.ForeColor = System.Drawing.Color.Blue;
            this.lblHeso_a.Location = new System.Drawing.Point(466, 127);
            this.lblHeso_a.Name = "lblHeso_a";
            this.lblHeso_a.Size = new System.Drawing.Size(69, 22);
            this.lblHeso_a.TabIndex = 1;
            this.lblHeso_a.Text = "he so a";
            // 
            // lblHeso_b
            // 
            this.lblHeso_b.AutoSize = true;
            this.lblHeso_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHeso_b.ForeColor = System.Drawing.Color.Blue;
            this.lblHeso_b.Location = new System.Drawing.Point(466, 175);
            this.lblHeso_b.Name = "lblHeso_b";
            this.lblHeso_b.Size = new System.Drawing.Size(69, 22);
            this.lblHeso_b.TabIndex = 2;
            this.lblHeso_b.Text = "he so b";
            // 
            // lblHeso_c
            // 
            this.lblHeso_c.AutoSize = true;
            this.lblHeso_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHeso_c.ForeColor = System.Drawing.Color.Blue;
            this.lblHeso_c.Location = new System.Drawing.Point(466, 226);
            this.lblHeso_c.Name = "lblHeso_c";
            this.lblHeso_c.Size = new System.Drawing.Size(68, 22);
            this.lblHeso_c.TabIndex = 3;
            this.lblHeso_c.Text = "he so c";
            // 
            // txtHeso_b
            // 
            this.txtHeso_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtHeso_b.Location = new System.Drawing.Point(571, 175);
            this.txtHeso_b.Name = "txtHeso_b";
            this.txtHeso_b.Size = new System.Drawing.Size(173, 28);
            this.txtHeso_b.TabIndex = 4;
            // 
            // txtHeso_c
            // 
            this.txtHeso_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtHeso_c.Location = new System.Drawing.Point(571, 226);
            this.txtHeso_c.Name = "txtHeso_c";
            this.txtHeso_c.Size = new System.Drawing.Size(173, 28);
            this.txtHeso_c.TabIndex = 5;
            // 
            // txtHeso_a
            // 
            this.txtHeso_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtHeso_a.Location = new System.Drawing.Point(571, 121);
            this.txtHeso_a.Name = "txtHeso_a";
            this.txtHeso_a.Size = new System.Drawing.Size(173, 28);
            this.txtHeso_a.TabIndex = 6;
            // 
            // lblketqua
            // 
            this.lblketqua.AutoSize = true;
            this.lblketqua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblketqua.ForeColor = System.Drawing.Color.Blue;
            this.lblketqua.Location = new System.Drawing.Point(107, 330);
            this.lblketqua.Name = "lblketqua";
            this.lblketqua.Size = new System.Drawing.Size(69, 22);
            this.lblketqua.TabIndex = 7;
            this.lblketqua.Text = "ket qua";
            // 
            // txtketqua
            // 
            this.txtketqua.Enabled = false;
            this.txtketqua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtketqua.Location = new System.Drawing.Point(226, 330);
            this.txtketqua.Name = "txtketqua";
            this.txtketqua.Size = new System.Drawing.Size(391, 28);
            this.txtketqua.TabIndex = 8;
            // 
            // btnTH
            // 
            this.btnTH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnTH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTH.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnTH.Location = new System.Drawing.Point(246, 383);
            this.btnTH.Name = "btnTH";
            this.btnTH.Size = new System.Drawing.Size(138, 39);
            this.btnTH.TabIndex = 9;
            this.btnTH.Text = "thuc hien";
            this.btnTH.UseVisualStyleBackColor = false;
            this.btnTH.Click += new System.EventHandler(this.btnTH_Click);
            // 
            // btnDong
            // 
            this.btnDong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnDong.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnDong.Location = new System.Drawing.Point(416, 383);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(138, 39);
            this.btnDong.TabIndex = 10;
            this.btnDong.Text = "dong";
            this.btnDong.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbPtb2);
            this.groupBox1.Controls.Add(this.rdbPtb1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.Location = new System.Drawing.Point(47, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(285, 180);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "chon phuong trinh";
            // 
            // rdbPtb1
            // 
            this.rdbPtb1.AutoSize = true;
            this.rdbPtb1.Location = new System.Drawing.Point(23, 51);
            this.rdbPtb1.Name = "rdbPtb1";
            this.rdbPtb1.Size = new System.Drawing.Size(112, 26);
            this.rdbPtb1.TabIndex = 0;
            this.rdbPtb1.TabStop = true;
            this.rdbPtb1.Text = "ax + b = 0";
            this.rdbPtb1.UseVisualStyleBackColor = true;
            this.rdbPtb1.CheckedChanged += new System.EventHandler(this.rdbPtb1_CheckedChanged);
            // 
            // rdbPtb2
            // 
            this.rdbPtb2.AutoSize = true;
            this.rdbPtb2.Location = new System.Drawing.Point(23, 102);
            this.rdbPtb2.Name = "rdbPtb2";
            this.rdbPtb2.Size = new System.Drawing.Size(169, 26);
            this.rdbPtb2.TabIndex = 1;
            this.rdbPtb2.TabStop = true;
            this.rdbPtb2.Text = "ax^2 + bx + c = 0";
            this.rdbPtb2.UseVisualStyleBackColor = true;
            // 
            // form_bai2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnTH);
            this.Controls.Add(this.txtketqua);
            this.Controls.Add(this.lblketqua);
            this.Controls.Add(this.txtHeso_a);
            this.Controls.Add(this.txtHeso_c);
            this.Controls.Add(this.txtHeso_b);
            this.Controls.Add(this.lblHeso_c);
            this.Controls.Add(this.lblHeso_b);
            this.Controls.Add(this.lblHeso_a);
            this.Controls.Add(this.lblTieuDe);
            this.Name = "form_bai2";
            this.Text = "form_bai2";
            this.Load += new System.EventHandler(this.form_bai2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblHeso_a;
        private System.Windows.Forms.Label lblHeso_b;
        private System.Windows.Forms.Label lblHeso_c;
        private System.Windows.Forms.TextBox txtHeso_b;
        private System.Windows.Forms.TextBox txtHeso_c;
        private System.Windows.Forms.TextBox txtHeso_a;
        private System.Windows.Forms.Label lblketqua;
        private System.Windows.Forms.TextBox txtketqua;
        private System.Windows.Forms.Button btnTH;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbPtb2;
        private System.Windows.Forms.RadioButton rdbPtb1;
    }
}