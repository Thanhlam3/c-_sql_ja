﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lap_onthi
{
    class ticket_bus
    {
        protected int tuyenXe;
        static int GiaSan = 5000;
        protected string DoiTuong;

        public int TuyenXe { get => tuyenXe; set => tuyenXe = value; }

        public void nhap()
        {
            Console.Write("Nhap tuyen xe: ");
            while (!int.TryParse(Console.ReadLine(), out tuyenXe) || tuyenXe <= 0)
                Console.Write("Nhap tuyen xe: ");
            Console.Write("Nhap doi tuong: ");
            DoiTuong = Console.ReadLine();
        }
        public void xuat()
        {
            Console.WriteLine($"Tuyen xe: {TuyenXe}, Gia san: {GiaSan}, Doi tuong: {DoiTuong}");
        }
        public double TinhGiaVe()
        {
            if (DoiTuong == "hoc sinh" || DoiTuong == "sinh vien")
            {
                return GiaSan;
            }
            else
                return GiaSan * 1.2;
        }
    }
    // giao dien
    interface IMuaVeThang
    {
        int SoThang { get; set; }
        double TinhTien_giam();
    }
    class Ticket_bus_Distric : ticket_bus, IMuaVeThang
    {
        int SoKm;
        int sothang;

        public int SoThang { get => sothang; set => sothang = value; }

        public new void nhap()
        {
            base.nhap();
            Console.Write("Nhap so km: ");
            while (!int.TryParse(Console.ReadLine(), out SoKm) || SoKm <= 0)
                Console.Write("Nhap so km: ");
            Console.Write("Nhap so thang: ");

        }
        public new void xuat()
        {
            base.xuat();
            Console.WriteLine($"So km: {SoKm}");
        }
        public double TinhTien_giam()
        {
            if(sothang > 3 && SoKm >= 20)
                return 0.15 * base.TinhGiaVe();
            else
                return 0.1 * base.TinhGiaVe();
        }
        public new double TinhGiaVe()
        {
            return base.TinhGiaVe() - TinhTien_giam();
        }
    }
    class DS_TicketBus
    {
        List<Ticket_bus_Distric> ls;
        public void nhap_ds()
        {
            int n;
            Console.Write("Nhap so luong ve: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
                Console.Write("Nhap so luong ve: ");
            ls = new List<Ticket_bus_Distric>(n);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Nhap thong tin ve thu {i + 1}:");
                Ticket_bus_Distric ve = new Ticket_bus_Distric();
                ve.nhap();
                ls.Add(ve);
            }
        }
        public void xuat_ds()
        {
            foreach (var ve in ls)
            {
                ve.xuat();
                Console.WriteLine($"Gia ve: {ve.TinhGiaVe()}");
            }
        }
        public void xoa()
        {
            ls.RemoveAll(ve => ve.TuyenXe == 1);
        }
    }
}
