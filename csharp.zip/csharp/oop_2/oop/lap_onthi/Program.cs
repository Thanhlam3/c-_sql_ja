﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lap_onthi
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
