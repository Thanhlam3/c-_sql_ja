﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace lap_onthi
{
    abstract class Motobike
    {
        protected string bienso;
        protected int namdk;
        public Motobike()
        {
            bienso = "82-A3.2363";
            namdk = 2015;
        }
        public Motobike(string bienso, int namdk)
        {
            this.bienso = bienso;
            this.namdk = namdk;
        }
        public virtual void nhap()
        {
            Console.Write("Nhap bien so xe: ");
            bienso = Console.ReadLine();
            Console.Write("Nhap nam dang ky xe: ");
            while (!int.TryParse(Console.ReadLine(), out namdk))
                Console.Write("Nhap nam dang ky xe: ");
        }
        // Phuong thuc truu tuong
        public abstract int TinhBH();
        public void xuat()
        {
            Console.WriteLine("Bien so xe: {0}, Nam dang ky: {1}, thoi han bao hanh: {2}", bienso, namdk, TinhBH());
        }


    }
    class Electric_Bike : Motobike
    {
        double pin;
        public Electric_Bike() : base()
        {
            pin = 12.7f;
        }
        public Electric_Bike(double pin, string bienso, int namdk) : base(bienso, namdk)
        {
            this.pin = pin;
        }
        public override void nhap()
        {
            base.nhap();
            Console.Write("Nhap dung luong pin: ");
            while (!double.TryParse(Console.ReadLine(), out pin))
                Console.Write("Nhap dung luong pin: ");
        }
        public override int TinhBH()
        {
            return namdk + 3;
        }
    }
    class Gasoline_Bike : Motobike
    {
        double dungTich;
        public Gasoline_Bike() : base()
        {
            dungTich = 125.0f;
        }
        public Gasoline_Bike(double dungTich, string bienso, int namdk) : base(bienso, namdk)
        {
            this.dungTich = dungTich;
        }
        public override void nhap()
        {
            base.nhap();
            Console.Write("Nhap dung tich: ");
            while (!double.TryParse(Console.ReadLine(), out dungTich))
                Console.Write("Nhap dung tich: ");
        }
        public override int TinhBH()
        {
            return namdk + 2;
        }
    }
    class DS_Moto
    {
        List<Motobike> ls;
        public void nhap_ds()
        {
            int n;
            Console.Write("Nhap so luong xe: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 1 || n <= 20)
                Console.Write("Nhap so luong xe: ");
            byte select; // 1 la xe dien, nguoc lai
            ls = new List<Motobike>();
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("xe thu {0} la xe xang or xe dien (1. xe dien): ", i + 1);
                while(!byte.TryParse(Console.ReadLine(), out select))
                    Console.WriteLine("xe thu {0} la xe xang or xe dien (1. xe dien): ", i + 1);
                Motobike mt;
                if (select == 1)
                    mt = new Electric_Bike();
                else
                    mt = new Gasoline_Bike();
                mt.nhap();
                ls.Add(mt);
            }
        }
        public void xuat_ds()
        {
            foreach(var moto in ls)
                moto.xuat();
        }
        public int dem()
        {
            int c=0;
            foreach( var mt in ls)
            {
                if (mt.TinhBH() < DateTime.Now.Year)
                    c++;
            }
            return c;
            //int d = ls.Count(mt => mt.TinhBH() <DateTime.Now.Year);
        }
    }
}

