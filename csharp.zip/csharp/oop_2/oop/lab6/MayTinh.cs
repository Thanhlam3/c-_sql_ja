﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    abstract class MayTinh
    {
        protected string NhanHieu;
        protected double Ram, BoNho, GiaNhap;
        public MayTinh()
        {
            NhanHieu = "rx7";
            Ram = 32.1;
            BoNho = 542.2;
            GiaNhap = 1000.3;
        }
        public MayTinh(string NhanHieu, double Ram , double BoNho , double GiaNhap)
        {
            this.NhanHieu = NhanHieu;
            this.Ram = Ram;
            this.BoNho = BoNho;
            this.GiaNhap = GiaNhap;
        }
        public virtual void nhap()
        {
            Console.WriteLine("nhap nhan hieu: ");
            NhanHieu = Console.ReadLine();
            Console.WriteLine("nhap ram: ");
            Ram = double.Parse (Console.ReadLine());
            Console.WriteLine("nhap bo nho: ");
            BoNho = double.Parse(Console.ReadLine());
            Console.WriteLine("nhap gia nhap: ");
            GiaNhap = double.Parse(Console.ReadLine());
        }
        public abstract double Tinh_GiaBan();
        public void xuat()
        {
            Console.WriteLine($"{NhanHieu},  {Ram},  {BoNho},  {Tinh_GiaBan()}");
        }
    }
    class Laptop : MayTinh
    {
        double TrongLuong;
        public Laptop():base()
        {
            TrongLuong = 1.9;
        }
        public Laptop(double TrongLuong, string NhanHieu, double Ram, double BoNho, double GiaNhap) : base(NhanHieu,Ram,BoNho,GiaNhap)
        {
            this.TrongLuong = TrongLuong;
        }

        public override void nhap()
        {
            base.nhap();
            Console.WriteLine("nhap trong luong: ");
            TrongLuong = double.Parse(Console.ReadLine());
        }
        public override double Tinh_GiaBan()
        {
            if (TrongLuong >= 2)
                return GiaNhap + GiaNhap * 0.15;
            else
                return GiaNhap + GiaNhap * 0.2;
        }
        
    }
    class MacBook : MayTinh
    {
        int Loai;
        public MacBook():base()
        {
            Loai = 1;
        }
        public MacBook(int Loai, string NhanHieu, double Ram, double BoNho, double GiaNhap) : base(NhanHieu, Ram, BoNho, GiaNhap)
        {
            this.Loai = Loai;
        }
        public override void nhap()
        {
            base.nhap();
            Console.WriteLine("nhap loai(1,2,3) (1.macbook air / 2.MacBook Pro 13 inch / 3.MacBook Pro 16 inch ): ");
            Loai = int.Parse( Console.ReadLine());
        }
        public override double Tinh_GiaBan()
        {
            if (Loai == 1)
                return GiaNhap + GiaNhap * 0.5;
            else if(Loai == 2)
                return GiaNhap + GiaNhap * 0.8;
            else 
                return GiaNhap * 2;
        }
    }
    class DS_MayTinh
    {
        List<MayTinh> ls;
        public void nhapDS()
        {
            int n;
            Console.Write("nhhap so luong may tinh ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 30)
                Console.Write("nhhap so luong may tinh ");
            byte chon; // 1 la laptop, nguoc lai
            ls = new List<MayTinh>(n);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("may tinh thu {0} la laptop or macbook (1. laptop): ", i + 1);
                while (!byte.TryParse(Console.ReadLine(), out chon))
                    Console.WriteLine("may tinh thu {0} la laptop or macbook (1. laptop): ", i + 1);
                MayTinh x;
                if (chon == 1)
                    x = new Laptop();
                else
                    x = new MacBook();
                x.nhap();
                ls.Add(x);
            }

        }
        public void xuatDS()
        {
            foreach (var x in ls)
                x.xuat();
        }
        public void dem()
        {
            // c1
            int lap=0, mac=0;
            foreach (var x in ls)
            {
                if (x is Laptop)
                    lap++;
                else if (x is MacBook)
                    mac++;
            }
            Console.WriteLine($"tong laptop : {lap}");
            Console.WriteLine($"tong macbook : {mac}");
        }
    }
}
