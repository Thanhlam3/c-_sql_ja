﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    abstract class xeMay
    {
        protected string bienso;
        protected int namdk;
        public xeMay() 
        {
            bienso = "82-A3.2363";
            namdk = 2015;
        }
        public xeMay(string bienso, int namdk)
        {
            this.bienso = bienso;
            this.namdk = namdk;
        }
        public virtual void nhap()
        {
            Console.Write("nhhap bien so xe ");
            bienso = Console.ReadLine();
            Console.Write("nhhap nam dang ky xe ");
            while(!int.TryParse(Console.ReadLine(), out namdk))
                Console.Write("nhhap nam dang ky xe ");
        }
        // phuong thuc truu tuong
        public abstract int TinhBH();
        public void xuat()
        {
            Console.WriteLine($"bien so xe: {bienso}, nam dang ky: {namdk}, thoi han bao hanh: {TinhBH()}");
        }
    }
    class xeDien:xeMay
    {
        double pin;
        public xeDien() : base()
        {
            pin = 12.7f;
        }
        public xeDien(double pin, string bienso, int namdk) : base(bienso, namdk)
        {
            this.pin = pin;
        }
        // nhap da hinh
        public override void nhap()
        {
            base.nhap();
            Console.Write("nhhap dung luong pin ");
            while (!double.TryParse(Console.ReadLine(), out pin))
                Console.Write("nhhap dung luong pin ");
        }
        // tinh bh
        public override int TinhBH()
        {
            return namdk + 3;
        }
    }
    class xeXang : xeMay
    {
        double dungTich;
        public xeXang() : base()
        {
            dungTich = 10.5f;
        }
        public xeXang(double dungTich, string bienso, int namdk) :base(bienso, namdk)
        {
            this.dungTich = dungTich;
        }
        public override void nhap()
        {
            base.nhap();
            Console.Write("nhhap dung tich xang ");
            while (!double.TryParse(Console.ReadLine(), out dungTich))
                Console.Write("nhhap dung tich xang ");
        }
        public override int TinhBH()
        {
            return namdk + 2;
        }
    }
    // danh sach n xe may
    class DS_xemay
    {
        List<xeMay> ls;
        public void nhapDS()
        {
            int n;
            Console.Write("nhhap so luong xe ");
            while (!int.TryParse(Console.ReadLine(), out n)|| n<=1 || n>=20)
                Console.Write("nhhap so luong xe ");
            byte chon; // 1 la xang, nguoc lai
            ls = new List<xeMay>(n);
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("xe thu {0} la xe xang or dien (1. xe xang): ", i + 1);
                while (!byte.TryParse(Console.ReadLine(), out chon))
                    Console.WriteLine("xe thu {0} la xe xang or dien (1. xe xang): ", i + 1);
                xeMay x;
                if (chon==1)
                    x = new xeXang();
                else
                    x = new xeDien();
                x.nhap();
                ls.Add(x);
            }
            
        }
        public void xuatDS()
        {
            foreach (var xe in ls)
                xe.xuat();
        }
        public int dem()
        {
            // c1
            int c = 0;
            foreach (var xe in ls)
            {
                if (xe.TinhBH() < DateTime.Now.Year)
                    c++;
            }
            // c2
            //int d = ls.Count(x => x.TinhBH() < DateTime.Now.Year);
            //return d;
            return c;
        }
    }
}
