﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    class Program
    {
        public static void bai6_1()
        {
            DS_xemay ds = new DS_xemay();
            ds.nhapDS();
            ds.xuatDS();
            Console.WriteLine($"so luong xe het bao hanh {ds.dem()}");
        }
        public static void bai6_2()
        {
            DS_VeXe ds = new DS_VeXe();
            ds.nhapDS();
            ds.xuatDS();
            Console.WriteLine($"so luong ve xe co so km trong khoang a,b la: {ds.dem()}");
            ds.xoa();
            Console.WriteLine("ds sau khi xoa la: ");
            ds.xuatDS();
            ds.ThemDT();
            Console.WriteLine("ds sau khi them la: ");
            ds.xuatDS();
        }
        public static void bai6_3()
        {
            DS_HCN ds = new DS_HCN();
            ds.nhapDS();
            Console.WriteLine("danh sach sau khi sap xep: ");
            ds.xuatDS();
            ds.xoa();
            Console.WriteLine("ds sau khi xoa la: ");
            ds.xuatDS();
            ds.themHCN();
            Console.WriteLine("ds sau khi them la: ");
            ds.xuatDS();
        }
        public static void bai6_4()
        {
            DS_MayTinh ds = new DS_MayTinh();
            ds.nhapDS();
            ds.xuatDS();
            ds.dem();
        }
        static void Main(string[] args)
        {
            bai6_4();
            Console.ReadKey();
        }
    }
}
