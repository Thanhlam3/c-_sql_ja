﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    class Shape
    {
        string name;
       
        public Shape(string name = "tam giac")
        {
            this.name = name;
        }
        public virtual double DienTich()
        {
            return 0;
        }
        public virtual void nhap()
        {
            Console.WriteLine("nhap ten hinh: ");
            name = Console.ReadLine();
        }
        public virtual void xuat()
        {
            Console.WriteLine($"ten hinh: {name}, dien tich: {DienTich()}");
        }
    }
    interface IPaint
    {
        double DonGia { get; set; }
        double TinhGia_theoDT();
    }
    class HCN : Shape, IPaint,IComparable<HCN>
    {
        double a, b;
        double dongia = 50.5;

        public double DonGia { get => dongia; set => dongia = value; }

        public HCN(double a = 1, double b = 1, string name = " ") : base(name)
        {
            this.a = a;
            this.b = b;
        }
        public override double DienTich()
        {
            return a * b;
        }
        public double TinhGia_theoDT()
        {
            return dongia * DienTich();
        }
        public override void nhap()
        {
            base.nhap();
            Console.Write("nhhap chieu dai hcn ");
            while (!double.TryParse(Console.ReadLine(), out a) || a <= 0)
                Console.Write("nhhap chieu dai hcn ");
            Console.Write("nhhap chieu rong hcn ");
            while (!double.TryParse(Console.ReadLine(), out b) || b <= 0)
                Console.Write("nhhap chieu rong hcn ");

        }
        public override void xuat()
        {
            base.xuat();
            Console.WriteLine($"chi phi ve theo dien tich la: {TinhGia_theoDT()}");
        }
        // Sắp xếp giảm dần theo chi phí vẽ
        public int CompareTo(HCN other)
        {
            return other.TinhGia_theoDT().CompareTo(this.TinhGia_theoDT());
        }
    }
    class DS_HCN
    {
        List<HCN> ls;
        public void nhapDS()
        {
            int n;
            Console.Write("nhap so luong hinh hcn: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 10)
                Console.Write("nhap lai so luong hinh hcn: ");

            ls = new List<HCN>(n);
            for (int i = 0; i < n; i++)
            {
                Console.Write("nhap thong tin hcn thu {0}", i + 1);
                HCN s = new HCN();
                s.nhap();
                ls.Add(s);
            }
        }
        public void sapXepGiam()
        {
            ls.Sort();
        }
        public void xuatDS()
        {
            sapXepGiam();
            foreach (var s in ls)
                s.xuat();
        }
        public void xoa()
        {
            int x;
            Console.WriteLine("nhap dien tich x: ");
            x = int.Parse(Console.ReadLine());
            ls.RemoveAll(s => s.DienTich() < x);
        }
        public void themHCN()
        {
            // tao dt can them
            Console.WriteLine("nhap thong tin cho ddoi tuuong caan theem");
            HCN s = new HCN();
            s.nhap();
            Console.WriteLine("nhap vi tri can them");
            int p;
            while (!int.TryParse(Console.ReadLine(), out p) || p < 0)
                Console.WriteLine("nhap vi tri can them");
            if (p < ls.Count)
                ls.Insert(p, s);
            else
                Console.WriteLine("vi tri ko phu hop");
        }
        public double TongCP()
        {
            double sum = 0;
            foreach (var s in ls)
                sum += s.TinhGia_theoDT();
            return sum;
        }
    }
}
