﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    class VeXe_Bus
    {
        protected byte tuyenXe;
        static int giaSan = 5000;
        protected string doiTuong;

        public byte TuyenXe { get => tuyenXe; set => tuyenXe = value; }

        public void nhap()
        {
            Console.Write("nhhap tuyen xe ");
            while (!byte.TryParse(Console.ReadLine(), out tuyenXe))
                Console.Write("nhhap tuyen xe ");
            Console.Write("nhap doi tuong: ");
            doiTuong = Console.ReadLine();
        }
        public double TinhGiaVe()
        {
            if (doiTuong == "hoc sinh" || doiTuong == "sinh vien")
            {
                return giaSan;
            }
            else
                return giaSan * 1.2;
        }
        public void xuat()
        {
            Console.WriteLine($"tuyen xe: {tuyenXe}, gia san: {giaSan}, doi tuong: {doiTuong}");
        }
  
    }
    // giao dien
    interface IMuaVeThang
    {
        byte SoThang { get; set; }
        double TinhTien_giam();
    }
    class VeBus_LienHuyen : VeXe_Bus, IMuaVeThang
    {
        int soKm;
        byte sothang;
        // dong goi thuoc tinh de khop vs khai bao tren interface
        public byte SoThang { get => sothang; set => sothang = value; }
        public int SoKm { get => soKm; set => soKm = value; }

        public new void nhap()
        {
            base.nhap();
            Console.Write("nhhap so km ");
            while (!int.TryParse(Console.ReadLine(), out soKm) || soKm <=0)
                Console.Write("nhhap so km ");
            Console.Write("nhhap so thang ");
            while (!byte.TryParse(Console.ReadLine(), out sothang))
                Console.Write("nhhap so thang ");
        }
        public new void xuat()
        {
            base.xuat();
            Console.WriteLine($"so km: {soKm}, so thang: {sothang},  gia ve: {TinhGiaVe()}");
        }
        public double TinhTien_giam()
        {
            if (sothang >= 3 && soKm >= 20)
                return 15 / 100 * base.TinhGiaVe();
            else
                return 10 / 100 * base.TinhGiaVe();
        }
        public new double TinhGiaVe()
        {
            return base.TinhGiaVe() - TinhTien_giam();                       
        }
    }

    class DS_VeXe
    {
        List<VeBus_LienHuyen> ls;
        // nhap ds
        public void nhapDS()
        {
            int n;
            Console.Write("nhhap so luong ve xe ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 3 || n >= 50)
                Console.Write("nhhap so luong ve xe ");
            ls = new List<VeBus_LienHuyen>();
            for (int i = 0; i < n; i++)
            {
                Console.Write("nhap thong tin ve xe thu {0}", i + 1);
                VeBus_LienHuyen vx = new VeBus_LienHuyen();
                vx.nhap();
                ls.Add(vx);
            }
        }
        public void xuatDS()
        {
            foreach (var vx in ls)
                vx.xuat();
        }
        public int dem()
        {   
            int c = 0;
            double a, b;
            Console.Write("nhap khoang [a;b]");
            Console.Write("nhhap chieu dai tuyen tu ");
            while (!double.TryParse(Console.ReadLine(), out a) || a <= 0)
                Console.Write("nhhap chieu dai tuyen tu ");
            Console.Write("nhhap chieu dai tuyen den ");
            while (!double.TryParse(Console.ReadLine(), out b) || b <= a)
                Console.Write("nhhap chieu dai tuyen den ");
            foreach (var vx in ls)
            {
                if (vx.SoKm >= a && vx.SoKm <= b)
                    c++;
            }          
            return c;
        }
        public void xoa()
        {
            //c1
            for(int i=0; i < ls.Count; i++)
            {
                if (ls[i].TuyenXe == 1)
                {
                    ls.RemoveAt(i);
                    i--;
                }
            }
            //c2
            ls.RemoveAll(vx => vx.TuyenXe == 1);
        }
        public void ThemDT()
        {
            // tao dt can them
            Console.WriteLine("nhap thong tin cho ddoi tuuong caan theem");
            VeBus_LienHuyen vx = new VeBus_LienHuyen();
            vx.nhap();
            Console.WriteLine("nhap vi tri can them");
            int p;
            while(!int.TryParse(Console.ReadLine(), out p)||p<0)
                Console.WriteLine("nhap vi tri can them");
            if (p < ls.Count)
                ls.Insert(p, vx);
            else
                Console.WriteLine("vi tri ko phu hop");
                //c2 them vao phan tu sau cung
                //ls.Add(vx);
        }
    }
}
