﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class Program
    {
        static void bai3_1()
        {
            PhanSo p1 = new PhanSo(2, 5);
            PhanSo p2 = new PhanSo(4, 3);
            PhanSo p3 = new PhanSo();
            //
            p3 = p1 + p2;

            p3.rutgon();
            Console.Write("kq cong 2 phan so p1 + p2: ");
            p3.xuat();
            //
            Console.Write("p1: "); p1.xuat();
            Console.Write("p2: "); p2.xuat();
            if (p1 > p2)
                Console.WriteLine("p1 > p2");
            else if (p1 == p2)
                Console.WriteLine("p1 = p2");
            else
                Console.WriteLine("p1 < p2");
        }
        static void bai3_2()
        {
            // viet theo cach 1

            Console.Write("nhap so luong duong tron ");
                int n;
           
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 30)
                Console.Write("nhap lai so duong tron: ");
            Circle[] ds = new Circle[n];
            for(int i = 0; i < n; i++)
            {
                float r;
                Console.Write("nhap ban kinh duong tron: ");
                while (!float.TryParse(Console.ReadLine(), out r) || n <= 0 )
                    Console.Write("nhap lai ban kinh duong tron: ");
                ds[i] = new Circle(r);
            }
            // in thong tin
            foreach (Circle c in ds)
                c.Info();
            // tinh tong dien tich
            double s = 0;
            foreach (Circle c in ds)
                s = s + c;    //s = s + c.Cal_Area();
            Console.WriteLine("tong dien tich {0} circle la {1}", n, s);
            // tim duong tron co chu vi lon nhat
            Circle max = new Circle();
            max = ds[0];
            for(int i = 1; i < ds.Length; i++)
            {
                if (max < ds[i])    //max.Cal_Perimeter() < ds[i].Cal_Perimeter()
                    max = ds[i];
            }
            Console.WriteLine("duong tron co  chu vi lon nhat: ");
            max.Info();


        }
        // bai 3_2 cach 2
        static void bai3_2_c2()
        {
            List_Circle ls = new List_Circle();
            ls.Input_List();
            Console.WriteLine("Tong dien tich la {0}", ls.Sum_Area());
            Console.WriteLine("duong tron co chu vi lon nhat la ");
            ls.Find_Max().Info();
        }
        static void bai3_3()
        {
            HocPhi hd = new HocPhi();
            hd.nhaphd();
            hd.xuat();
            Console.WriteLine("tong stc la {0} ", hd.tongtc());
        }
        static void bai3_4()
        {
            list_ks ks = new list_ks();
            ks.nhapks();
            ks.xuatks();
            ks.demPhieu();
            ks.tinhTrungBinh();
        }
        static void bai3_5()
        {
            list_adult ld = new list_adult();
            ld.NhapDanhSach();
            ld.XuatSucKhoeTot();
        }
        static void bai3_6()
        {
            list_hv hv = new list_hv();
            hv.nhaphv();
            hv.xuathv();
            
        }
        static void Main(string[] args)
        {
            bai3_6();
            Console.ReadKey();
        }
    }
}
