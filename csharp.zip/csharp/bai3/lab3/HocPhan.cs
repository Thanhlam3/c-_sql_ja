﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class HocPhan
    {
        string maHP, tenHP;
        byte soTC;
        bool daicuong; // hoc phan dai cuong : true

        public HocPhan(string ma="sot332", string ten="oop", byte tc=3, bool dc=false )
        {
            maHP = ma;
            tenHP = ten;
            soTC = tc;
            daicuong = dc;
        }

        public byte SoTC { get => soTC; set => soTC = value; }

        public void nhap()
        {
            Console.Write("\n");
            Console.Write("nhap ma hp: ");
            maHP = Console.ReadLine();
            Console.Write("nhap ten hp: ");
            tenHP = Console.ReadLine();

            Console.Write("nhap so tin chi: ");
            while(!byte.TryParse(Console.ReadLine(),out soTC) || soTC < 0 || soTC > 10)
                Console.Write("nhap lai so tin chi: ");

            Console.Write("hp la dai cuong (true/false): ");
            while (!bool.TryParse(Console.ReadLine(), out daicuong)) ;
                Console.Write("hp la dai cuong (true/false): ");
        }
        // tinh hoc phi
        public int TinhHP()
        {
            if (daicuong)
                return soTC * 310;
            else
                return soTC * 550;
        }
        // xuat
        public void Xuat()
        {
            Console.WriteLine($"{maHP}\t{tenHP}\t{soTC}\t{TinhHP()}\t");
        }
        // toan tu
        public static int operator + (int n, HocPhan hp)
        {
            return n + hp.TinhHP();
        }
        public static bool operator < (HocPhan hp1, HocPhan hp2)
        {
            return hp1.soTC < hp2.soTC;
        }
        public static bool operator > (HocPhan hp1, HocPhan hp2)
        {
            return hp1.soTC > hp2.soTC;
        }
    }
    class HocPhi
    {
        string maSV, hoten;
        int n;
        HocPhan[] ds;

        public HocPhi(string ma=" ", string ten=" ")
        {
            maSV = ma; hoten = ten;
            ds = new HocPhan[n];
        }
        public void nhaphd()
        {
            Console.Write("nhap ma sv: ");
            maSV = Console.ReadLine();
            Console.Write("nhap ten sv: ");
            hoten = Console.ReadLine();

            Console.Write("nhap so luong hp: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 9)
                Console.Write("nhap lai so luong hp: ");

            ds = new HocPhan[n];
            for(int i=0; i< n; i++)
            {
                ds[i] = new HocPhan();
                ds[i].nhap();
            }

        }
        // sx
        public void sapxep()
        {
            for(int i =0; i < ds.Length; i++) { 
                for(int j = i + 1; j < ds.Length; j++)
                {
                    if (ds[i] < ds[j])
                    {
                        HocPhan hp = new HocPhan();
                        hp = ds[i];
                        ds[i] = ds[j];
                        ds[j] = hp;
                    }
                }
            }
        }
        // xuat
        public void xuat()
        {
            Console.WriteLine($"{maSV}\t{hoten}\t");
            // sap xep
            sapxep();
            // xuat ds
            foreach (HocPhan hp in ds)
                hp.Xuat();
            // tong tien
            int s = 0;
            foreach (HocPhan hp in ds)
                s = s + hp;
            Console.WriteLine("tong hoc phi la: {0} ", s);
        }
        public int tongtc()
        {
            int s = 0;
            foreach (HocPhan hp in ds)
                s += hp.SoTC;
            return s;
        }



    }
}
