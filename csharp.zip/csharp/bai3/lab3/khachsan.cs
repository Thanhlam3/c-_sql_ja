﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class khachsan
    {
        int sophong;
        string hoten;
        DateTime ngayden, ngaydi;
        int loaiphong;
        int giasan = 300;

        public DateTime Ngayden { get => ngayden; set => ngayden = value; }

        public khachsan()
        {
            sophong = 1;
             hoten = " ";
           
            loaiphong = 1;
            giasan = 300;
        }
        public khachsan(int sophong, string hoten, DateTime ngayden, DateTime ngaydi, int loaiphong, int giasan)
        {
            this.sophong = sophong;
            this.hoten = hoten;
            this.ngayden = ngayden;
            this.ngaydi = ngaydi;
            this.loaiphong = loaiphong;
            this.giasan = giasan;
        }
        public void nhap()
        {
            Console.Write("nhap so phong: ");
            sophong = int.Parse(Console.ReadLine());
            Console.Write("nhap ho ten: ");
            hoten = Console.ReadLine();
            Console.Write("nhap ngay den: ");
            ngayden = DateTime.Parse(Console.ReadLine());
            Console.Write("nhap ngay di: ");
            ngaydi = DateTime.Parse(Console.ReadLine());
            Console.Write("nhap loai phong: ");
            loaiphong = int.Parse(Console.ReadLine());
        }
        
        public int tinhSoNgayO()
        {
            if (ngaydi < ngayden)
                return 0;

            if (ngaydi == ngayden)
                return 1;

            TimeSpan songayo = ngaydi - ngayden;
            return songayo.Days;
        }

      
        public double tinhtien()
        {
            int songayo2 = tinhSoNgayO();
            double giaphong = 0;
            double tongtien = 0;

            if (loaiphong == 1)
            {
                giaphong = 1.5 * giasan;
            }
            else if (loaiphong == 2)
            {
                giaphong = 1.3 * giasan;
            }
            else
            {
                giaphong = giasan;
            }

            tongtien = songayo2 * giaphong;
            return tongtien;
        }


        public void xuat()
        {
            Console.WriteLine($"so phong: {sophong}, ho ten: {hoten}, tien phong: {tinhtien()}");
        }
        public static bool operator  < (khachsan k1, khachsan k2)
        {
            return (k1.tinhSoNgayO() < k2.tinhSoNgayO());
        }
        public static bool operator >(khachsan k1, khachsan k2)
        {
            return (k1.tinhSoNgayO() > k2.tinhSoNgayO());
        }
        public static double operator +(double n, khachsan k1)
        {
            return n + k1.tinhtien();
        }
    }
    class list_ks
    {
        khachsan[] ds;
        int n;
        public void nhapks()
        {
            Console.Write("nhap so luong phieu luu tru: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 1 || n > 30)
                Console.Write("nhap lai so luong  phieu luu tru: ");
            ds = new khachsan[n];
            for (int i = 0; i < n; i++)
            {
                ds[i] = new khachsan();
                ds[i].nhap();
            }
        }
        public void sapxep()
        {
            for (int i = 0; i < ds.Length; i++)
            {
                for (int j = i + 1; j < ds.Length; j++)
                {
                    if (ds[i] < ds[j])
                    {
                        khachsan ks = new khachsan();
                        ks = ds[i];
                        ds[i] = ds[j];
                        ds[j] = ks;
                    }
                }
            }
        }
        public void xuatks()
        {
            sapxep();
            foreach (khachsan ks in ds)
                ks.xuat();
        }
        public void demPhieu()
        {
            int dem = 0;
            foreach (khachsan ks in ds)
            {
                if (ks.Ngayden.Year == 2024 && ks.Ngayden.Month >= 10 && ks.Ngayden.Month <= 12)               
                    dem++;           
            }
            Console.WriteLine($"So luong phieu luu tru trong quy 4 nam 2024: {dem}");
        }
        public void tinhTrungBinh()
        {
            double tong = 0;
            foreach (khachsan ks in ds)
            {
                tong = tong + ks;
            }

            double tb =  (tong / n);
            Console.WriteLine($"Tien phong trung binh: {tb}");
        }
    }
}

