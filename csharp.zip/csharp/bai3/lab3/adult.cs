﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class adult
    {
        string hoten;
        double canNang;
        double chieuCao;

        public adult()
        {
            hoten = "pham thanh lam";
            canNang = 50.0;
            chieuCao = 164.0;
        }

        public adult(string hoten1, double canNang1, double chieuCao1)
        {
            hoten = hoten1;
            canNang = canNang1;
            chieuCao = chieuCao1;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
        }

        public adult(adult ad)
        {
            hoten = ad.hoten;
            canNang = ad.canNang;
            chieuCao = ad.chieuCao;
        }

        public void Nhap()
        {
            Console.ResetColor();
            Console.Write("Nhap ho ten: ");
            hoten = Console.ReadLine();

            Console.Write("Nhap can nang (kg): ");
            while (!double.TryParse(Console.ReadLine(), out canNang) || canNang <= 0)
            {
                Console.Write("Gia tri khong hop le. Nhap lai can nang (>0): ");
            }

            Console.Write("Nhap chieu cao (cm): ");
            while (!double.TryParse(Console.ReadLine(), out chieuCao) || chieuCao <= 0)
            {
                Console.Write("Gia tri khong hop le. Nhap lai chieu cao (>0): ");
            }
        }

        public double Tinh_bmi()
        {
            double chieuCaoMet = chieuCao / 100; // đổi từ cm sang m
            double bmi = canNang / (chieuCaoMet * chieuCaoMet);

            if (bmi < 18.5)
            {
                Console.WriteLine("Ban thuoc nhom: Thieu can");
                double socandu = 18.5 * (chieuCaoMet * chieuCaoMet);
                double socancantang = socandu - canNang;
                Console.WriteLine($"De co suc khoe tot, ban can tang them: {socancantang:F2} kg");
            }
            else if (bmi < 25)
            {
                Console.WriteLine("Ban thuoc nhom: Binh thuong, suc khoe tot");
            }
            else if (bmi < 30)
            {
                Console.WriteLine("Ban thuoc nhom: Thua can");
                double socanbidu = 25 * (chieuCaoMet * chieuCaoMet);
                double socancangiam = canNang - socanbidu;
                Console.WriteLine($"De co suc khoe tot, ban can giam them: {socancangiam:F2} kg");
            }
            else
            {
                Console.WriteLine("Ban thuoc nhom: Beo phi");
                double socanbidu = 30 * (chieuCaoMet * chieuCaoMet);
                double socancangiam = canNang - socanbidu;
                Console.WriteLine($"De co suc khoe tot, ban can giam them: {socancangiam:F2} kg");
            }

            return bmi;
        }

        public void xuat()
        {
            Console.WriteLine($"Ho ten: {hoten}, Can nang: {canNang} kg, Chieu cao: {chieuCao / 100} m, Dua theo chi so BMI");
            Tinh_bmi();
        }
    }

    class list_adult
    {
        adult[] ds;

        public void NhapDanhSach()
        {
            int n;

            Console.Write("Nhap so luong thanh nien (2 < n < 100): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 100)
                Console.Write("Nhap lai so luong thanh nien (2 < n < 100): ");

            ds = new adult[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nNhap thong tin thanh nien thu {i + 1}:");
                ds[i] = new adult();
                ds[i].Nhap();
            }
        }

        public void XuatSucKhoeTot()
        {
            Console.WriteLine("\nDanh sach thanh nien du dieu kien suc khoe (BMI tu 18.5 den < 25):");
            foreach (adult ad in ds)
            {
                if (ad.Tinh_bmi() > 18.5 && ad.Tinh_bmi() < 25)
                {
                    ad.xuat();
                }
            }
        }
    }
}
