﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class PhanSo
    {
        int tuso, mauso;
        public PhanSo()
        {
            tuso = 0;
            mauso = 1;
        }
        public PhanSo(int ts, int ms)
        {
            tuso = ts;
            mauso = ms;
        }
        // toan tu cong
        public static PhanSo operator + (PhanSo p1, PhanSo p2)
        {
            PhanSo kq = new PhanSo();
            kq.tuso = p1.tuso * p2.mauso + p2.tuso * p1.mauso;
            kq.mauso = p1.mauso * p2.mauso;
            return kq;
        }
        public static PhanSo operator - (PhanSo p1, PhanSo p2)
        {
            PhanSo kq = new PhanSo();
            kq.tuso = p1.tuso * p2.mauso - p2.tuso * p1.mauso;
            kq.mauso = p1.mauso * p2.mauso;
            return kq;
        }
        public static PhanSo operator * (PhanSo p1, PhanSo p2)
        {
            PhanSo kq = new PhanSo();
            kq.tuso = p1.tuso* p2.tuso;
            kq.mauso = p1.mauso* p2.mauso;
            return kq;
        }
        // toan tu so sanh >,<
        // dinh nghia theo cap
        public static bool operator > (PhanSo p1, PhanSo p2)
        {
            return (p1.tuso * p2.mauso > p2.tuso * p1.mauso);
        }
        public static bool operator < (PhanSo p1, PhanSo p2)
        {
            return (p1.tuso * p2.mauso > p2.tuso * p1.mauso);
        }
        // toan tu so sanh ==, !=
        public static bool operator == (PhanSo p1, PhanSo p2)
        {
            return (p1.tuso * p2.mauso == p2.tuso * p1.mauso);
        }
        public static bool operator != (PhanSo p1, PhanSo p2)
        {
            return (p1.tuso * p2.mauso != p2.tuso * p1.mauso);
        }
        int ucln(int x, int y)
        {
            while (y != 0)
            {
                int temp = y;
                y = x % y;
                x = temp;
            }
            return x;
        }
        // cach 2
        //int ucln(int x, int y)
        //{
        //    while (x != y)
        //    {
        //        if(x > y)
        //        x -= y;
        //        else if(x < y)
        //            y -=x;
        //    }
        //    return x;
        //}

        public PhanSo rutgon()
        {
            PhanSo kq = new PhanSo();
            int t = ucln(tuso, mauso);

            tuso = tuso / t;
            mauso = mauso / t;
            return this;
        }
        public void xuat()
        {
            Console.WriteLine($"{tuso}/{mauso}");
        }
    }
}
