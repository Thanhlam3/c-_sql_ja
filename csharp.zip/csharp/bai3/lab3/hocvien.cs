﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class hocvien
    {
        string mahv, hoten, lophoc;
        int sotiet, hocphi1t = 100;

        public hocvien()
        {
            mahv = " ";
            hoten = " ";
            lophoc = " ";
            sotiet = 1;
        }
        public hocvien(string mahv, string hoten, string lophoc, int sotiet)
        {
            this.mahv = mahv;
            this.hoten = hoten;
            this.lophoc = lophoc;
            this.sotiet = sotiet;
        }
        public void nhap()
        {
            Console.WriteLine("nhap ma hoc vien: ");
            mahv = Console.ReadLine();
            Console.WriteLine("nhap ho ten: ");
            hoten = Console.ReadLine();
            Console.WriteLine("nhap lop hoc: ");
            lophoc = Console.ReadLine();
            Console.WriteLine("nhap so tiet: ");
            sotiet = int.Parse(Console.ReadLine());
        }
        public double tinhhp()
        {
            double tongtien = 0;
            double tiengiam = 0;
            if (sotiet > 50)
                tiengiam = 0.1 * sotiet * hocphi1t;
            if (sotiet <= 50 && sotiet > 30)
                tiengiam = 0.7 * sotiet * hocphi1t;
            else
                tiengiam = 0;

            tongtien = sotiet * hocphi1t - tiengiam;
            return tongtien;
        }
        public void xuat()
        {
            Console.WriteLine($"ho ten: {hoten}, lop hoc: {lophoc}, so tiet: {sotiet}, tien hp: {tinhhp()}");
        }
        public static bool operator >(hocvien h1, hocvien h2)
        {
            return (h1.sotiet > h2.sotiet);
        }
        public static bool operator <(hocvien h1, hocvien h2)
        {
            return (h1.sotiet < h2.sotiet);
        }
        public static double operator +(hocvien h1, double n)
        {
            return (h1.tinhhp() + n);
        }
    }

    class list_hv
    {
        hocvien[] ds;
        int n;
        public void nhaphv()
        {
            Console.WriteLine("nhap so luong hoc vien: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 30)
                Console.WriteLine("nhap so luong hoc vien: ");
            ds = new hocvien[n];
            for (int i = 0; i < n; i++)
            {
                ds[i] = new hocvien();
                ds[i].nhap();
            }
        }
        public void sapxep()
        {
            for (int i = 0; i < ds.Length; i++)
            {
                for (int j = i + 1; j < ds.Length; j++)
                {
                    if (ds[i] > ds[j])
                    {
                        hocvien hv = new hocvien();
                        hv = ds[i];
                        ds[i] = ds[j];
                        ds[j] = hv;
                    }
                }
            }
        }
        public void xuathv()
        {

            // sap xep
            sapxep();
            // xuat ds
            foreach (hocvien hv in ds)
                hv.xuat();
            // tong tien
            double s = 0;
            foreach (hocvien hv in ds)
                s = hv + s;
            Console.WriteLine("tong hoc phi la: {0} ", s);
        }
    }
}
