﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class Circle
    {
        float r;
        public Circle()
        {
            r = 1;
        }
        public Circle(float r)
        {
            this.r = r;
        }
        // tinh chu vi, dien tich
        public double Cal_Perimeter()
        {
            return 2 * Math.PI * r;
        }
        public double Cal_Area()
        {
            return Math.PI * r * r;
        }
        // hien thi
        public void Info()
        {
            Console.WriteLine($"ban kinh: {r}, chu vi: {Cal_Perimeter()}, dien tich: {Cal_Area()}");
        }
        // toan tu cong
        public static double operator +(double d, Circle c)
        {
            return d + c.Cal_Area();
        }
        public static bool operator <(Circle c1, Circle c2)
        {
            return c1.Cal_Perimeter() < c2.Cal_Perimeter();
        }
        public static bool operator >(Circle c1, Circle c2)
        {
            return c1.Cal_Perimeter() > c2.Cal_Perimeter();
        }

    }
    // ds n circle
    class List_Circle
    {
        int n;
        Circle[] ds;
        // nhap n circle
        public void Input_List()
        {
            Console.Write("nhap so luong duong tron ");
            int n;

            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 30)
                Console.Write("nhap lai so duong tron: ");
            Circle[] ds = new Circle[n];
            for (int i = 0; i < n; i++)
            {
                float r;
                Console.Write("nhap ban kinh duong tron thu {0}: ", i + 1);
                while (!float.TryParse(Console.ReadLine(), out r) || n <= 0)
                    Console.Write("nhap lai ban kinh duong tron: ");
                ds[i] = new Circle(r);
            }
        }
        // xuat n circle
        public void Output_List()
        {
            // in thong tin
            foreach (Circle c in ds)
                c.Info();
        }
        // tinh tong dien tich // can phai sua lai toan tu
        public double Sum_Area()
        {
            double s = 0;
            foreach (Circle c in ds)
                s = s + c;    //s = s + c.Cal_Area();
            return s;
        }
        // tim duong tron lon nhat
        public Circle Find_Max()
        {
            Circle max = new Circle();
            max = ds[0];
            for (int i = 1; i < ds.Length; i++)
            {
                if (max < ds[i])    //max.Cal_Perimeter() < ds[i].Cal_Perimeter()
                    max = ds[i];
            }
            return max;
        }
    }
}
