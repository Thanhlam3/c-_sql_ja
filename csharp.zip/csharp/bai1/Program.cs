﻿using System;

namespace bai1
{
    class Program
    {
        static void bai1_1()
        {
            string hoten;
            DateTime ngaysinh;
            bool gt;
            Console.Write("nhap ho ten ");
            hoten = Console.ReadLine();
            Console.Write("nhap ngay sinh ");
            ngaysinh = DateTime.Parse(Console.ReadLine());
            Console.Write("nhap gioi tinh ");
            gt = Boolean.Parse(Console.ReadLine());

            Console.WriteLine($"hoten: {hoten}, ngaysinh: {ngaysinh.ToShortDateString()}, gioitinh: {gt} ");
            Console.ReadKey();
        }
        static void bai1_2()
        {
            string hoten;
            DateTime ngaysinh;
            int tuoi;
            Console.Write("nhap ho ten ");
            hoten = Console.ReadLine();
            Console.Write("nhap ngay sinh ");
            ngaysinh = DateTime.Parse(Console.ReadLine());

            tuoi = DateTime.Now.Year - ngaysinh.Year;
            Console.WriteLine($"hoten: {hoten}, tuoi: {tuoi}");
            Console.ReadKey();
        }
        static void bai1_3()
        {
            byte sogio;
            float luong;
            Console.Write("nhap so gio lam ");
            while (!byte.TryParse(Console.ReadLine(), out sogio) || sogio > 24)
                Console.Write("nhap lai so gio lam ");
            Console.Write("nhap so luong trong 1h ");
            while (!float.TryParse(Console.ReadLine(), out luong) || luong < 8 || luong > 50)
                Console.Write("nhap lai so luong trong 1h ");
            float tienluong;
            if (sogio <= 8)
                tienluong = sogio * luong;
            else
                tienluong = sogio * luong + (sogio - 8) * luong * 1.5f;
            Console.WriteLine("tien luong trong ngay la: {0}", tienluong);
        }
        static void bai1_4()
        {
            int a, b;
            char c;
            float? kq = null;
            Console.Write("nhap 2 so nguyen ");
            a = int.Parse(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("nhap phep toan (+,_,*,/) ");
            c = char.Parse(Console.ReadLine());

            switch (c)
            {
                case '+': kq = a + b; break;
                case '-': kq = a - b; break;
                case '*': kq = a * b; break;
                case '/':
                    if (b != 0)
                    {
                        kq = a / b;
                        Console.WriteLine($"kq: {a} / {b} = {kq}");
                    }
                    else
                    {
                        Console.WriteLine("loi, ko the chia cho 0");
                    }
                    break;
                default:
                    Console.WriteLine("phep toan 0 hop le");
                    break;
            }
            Console.WriteLine($"{a} {c} {b} = {kq}");
        }
        static void bai1_5()
        {
            int a;
            int dem = 0;
            while (dem < 3)
            {
                Console.Write("nhap mat khau: ");
                a = int.Parse(Console.ReadLine());
                if (a == 123)
                {
                    Console.Write("dang nhap thanh cong");
                    break;
                }
                else
                {
                    Console.Write("mk ko hop le \n");
                    dem++;
                }
            }
            Console.ReadKey();

        }
        static bool ktrboi(int x, int y)
        {
            if (y == 0)
            {
                Console.Write("ko the chia cho 0 ");
                return false;
            }
            return x % y == 0;
        }
        static void swap(ref int x, ref int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }
        static int ucln(int x, int y)
        {
            while (y != 0)
            {
                int temp = y;
                y = x % y;
                x = temp;
            }
            return x;
        }
        static void bai1_6()
        {
            int a, b, kq;
            Console.Write("nhap vao 2 so nguyen a va b ");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            if (ktrboi(a, b))
                Console.WriteLine($"{a} la boi cua {b}");
            else
                Console.WriteLine($"{a} ko phai la boi cua {b}");
            swap(ref a, ref b);
            Console.WriteLine($"sau khi hoan doi la a = {a}, b = {b}");
            kq = ucln(a, b);
            Console.WriteLine($"ucln cua {a} va {b} la {kq}");
            Console.ReadKey();
        }
        static void bai1_7()
        {
            int n;
            int[] a;
            Console.Write("nhap so ptu cua mang ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 3 || n > 20) 
                Console.Write("nhap lai so ptu cua mang ");
            a = new int[n];
            for(int i = 0; i < n; i++)
            {
                Console.Write($"a[{i}] = ");
                a[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                    if (a[i] > a[j])
                        swap(ref a[i], ref a[j]);
            }
            foreach (int x in a)
                Console.Write($"{x}  ");

        }
        static void bai1_8()
        {
            int a;
            Console.Write("nhap vao 1 nam ");
            a = int.Parse(Console.ReadLine());
            if ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0))
                Console.Write("day la nam nhuan ");
            else
                Console.Write("day ko phai la nam nhuan ");
        }
        static void bai1_9()
        {
            char x;
            Console.Write("nhap 1 ki tu ");
            x = char.Parse(Console.ReadLine());
            switch (x)
            {
                case 'a': 
                case 'e': 
                case 'i': 
                case 'o': 
                case 'u':
                case 'y':
                case 'A':
                case 'E':
                case 'I':
                case 'O':
                case 'U':
                case 'Y':
                    Console.Write("day la nguyen am ");
                    break;
                case char c when char.IsDigit(c):
                    Console.Write("day la chu so ");
                    break;
                case char c when char.IsLetter(c):
                    Console.Write("day la phu am ");
                    break;
            }

        }
        static void bai1_10()
        {
            int sonam;
            long danso;
            float tiletang;
            double kq;
            Console.Write("nhap so nam ");
            sonam = int.Parse(Console.ReadLine());
            Console.Write("nhap dan so ban dau ");
            danso = long.Parse(Console.ReadLine());
            Console.Write("nhap ti le gia tang ");
            tiletang = float.Parse(Console.ReadLine());

            kq = danso * Math.Pow(1 + tiletang, sonam);
            Console.WriteLine($"dan so tang sau {sonam} nam la {kq}");
        }
        static void bai1_11()
        {
            // cau a: kq in ra la 15 .vi {1} duoc viet truoc {0} nen se in ra gia tri b truoc.
            // cau b: kq in ra la 1, 0 .vi khi su dung $ trong write thi c# se chay theo thu tu
            //        cac tham so truyen vao, a la tham so thu 0 và b là tham so thu 1.
            // cau c: kq bi loi .vi readline se tra ve 1 chuoi, nen ta can chuyen doi chuoi sang int.
            // cau d: kq bi loi .vi 1 bien da khoi tao thi can gan gia tri, trong lenh if su dung
            //        bien chk ma bien chk ch duoc gan gtri nen gay ra loi.
            // cau e: kq in ra 1 .vi a = 1 co nghia la case 1 se chay, boi vi ko co break nen se tiep
            //           se tiep tuc chay den case 2 xong den case 3 thuc hien lenh write in ra gtri a
            //           va gap break roi dung.
        }
        static void Main(string[] args)
        {
            bai1_1();
        }
    }
}
