﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baiontap
{
    class CongNhan
    {
        string hoten;
        bool GioiTinh;
        int xeploai, songaycong;
        double mucluongsan;

        public CongNhan()
        {
            hoten = " ";
            GioiTinh = true;
            xeploai = 1;
            songaycong = 10;
            mucluongsan = 2.0;
        }
        public CongNhan(string hoten, bool GioiTinh, int xeploai, int songaycong, double mucluongsan)
        {
            this.hoten = hoten;
            this.GioiTinh = GioiTinh;
            this.xeploai = xeploai;
            this.songaycong = songaycong;
            this.mucluongsan = mucluongsan;
        }

        public int Songaycong { get => songaycong; set => songaycong = value; }
        

        public void nhap()
        {
            Console.Write("\n");
            Console.Write("nhap ho ten: ");
            hoten = Console.ReadLine();
            Console.Write("nhap gioi tinh: ");
            GioiTinh = bool.Parse(Console.ReadLine());

            Console.Write("nhap xep loai: ");
            xeploai = int.Parse(Console.ReadLine());

            Console.Write("nhap so ngay cong: ");
            songaycong = int.Parse(Console.ReadLine());

            Console.Write("nhap muc luong san: ");
            mucluongsan = double.Parse(Console.ReadLine());
        }
        public double tinhluong()
        {
            if (xeploai == 1 && GioiTinh == false)
            {
                return songaycong * (1.3 * mucluongsan);
            }
            else if (xeploai == 2 && GioiTinh == false)
            {
                return songaycong * (1.15 * mucluongsan);
            }
            else
            {
                return songaycong * mucluongsan;
            }
        }
        public void Xuat()
        {
            Console.WriteLine($"ho ten: {hoten}, gioi tinh: {GioiTinh}, xep loai: {xeploai}, so ngay cong: {songaycong}, tien luong:{tinhluong()}");
        }
        public static double operator +(double n, CongNhan cn)
        {
            return n + cn.tinhluong();
        }
    }
    class bophan
    {

        string tenbp;
        int n;
        CongNhan[] ds;


        public void nhapbp()
        {
            Console.Write("nhap ten bo phan: ");
            tenbp = Console.ReadLine();

            Console.Write("nhap so luong cong nhan: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 2 || n > 20)
                Console.Write("nhap lai so luong cong nhan: ");

            ds = new CongNhan[n];
            for (int i = 0; i < n; i++)
            {
                ds[i] = new CongNhan();
                ds[i].nhap();
            }

        }
        public void xuatbp()
        {
            Console.WriteLine($"{tenbp}");
            
            // xuat ds
            foreach (CongNhan cn in ds)
                cn.Xuat();
            // tong tien
            double s = 0;
            foreach (CongNhan cn in ds)
                s = s + cn;
            Console.WriteLine("tong tien luong la: {0} ", s);
        }
        public void demnc()
        {
            int x;
            Console.WriteLine("nhap vao x: ");
            x = int.Parse(Console.ReadLine());
            int dem = 0;
            foreach (CongNhan cn in ds)
                if(cn.Songaycong < x)
                {
                    dem++;
                }
            Console.Write("so luong cong nhan co snc < x: {0}", dem);
        }
    }
}
