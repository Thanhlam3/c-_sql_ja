﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baiontap
{
    class Program
    {
            //bophan bp = new bophan();

            //Console.WriteLine("\n=== Nhap thong tin bo phan ===");
            //bp.nhapbp();

            //Console.WriteLine("\n=== Xuat thong tin bo phan ===");
            //bp.xuatbp();

            //Console.WriteLine("\n=== Dem cong nhan co so ngay cong < x ===");
            //bp.demnc();

            //Console.ReadKey();
        static void Main(string[] args)
        {
            Console.Write("nhap 1 doi tuong la NVHC: ");
            bool loai = bool.Parse(Console.ReadLine());
            if (loai)
            {
                NVHC nv = new NVHC();
                nv.Nhap();
                nv.InBL();
            }
            else
            {
                GV gv = new GV();
                gv.Nhap();
                gv.InBL();
            }
            Console.ReadKey();
        }
    }
}
