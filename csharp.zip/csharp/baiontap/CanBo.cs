﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace baiontap
{
    class CanBo
    {
        protected string maso, hoten;
        protected bool gtinh;
        public CanBo()
        {
            maso = ""; hoten = ""; gtinh = true;
        }
        public CanBo(string m, string ht, bool gt)
        {
            maso = m; hoten = ht; gtinh = gt;
        }
        public CanBo(CanBo cb)
        {
            maso = cb.maso; hoten = cb.hoten; gtinh = cb.gtinh;
        }
        public float TinhTL()
        {
            return 0;
        }
        public void Nhap() {
            Console.Write("Nhap ma so:");
            maso = Console.ReadLine();
            Console.Write("Nhap ho ten:");
            hoten = Console.ReadLine();
            Console.Write("Nhap gioi tinh:");
            gtinh = bool.Parse(Console.ReadLine());
        }
        public void InBL()
        {
            Console.WriteLine($"{maso}\t {hoten}\t{TinhTL()}");
        }
    }
    class NVHC : CanBo
    {
        byte socong;
        float luongthang;
        public NVHC() : base() {
            socong = 0; luongthang = 0;
        }
        public NVHC(string m, string ht, bool gt, byte cong, float luong) : base(m, ht, gt)
        {
            socong = cong; luongthang = luong;
        }
        public NVHC(NVHC nv) : base((CanBo)nv)
        {
            socong = nv.socong; luongthang = nv.luongthang;
        }
        public new float TinhTL()
        {
            return socong * luongthang / 26;
        }
        public new void Nhap()
        {
            base.Nhap();
            Console.Write("nhap so cong: ");
            socong = byte.Parse(Console.ReadLine());
            Console.Write("nhap luong thang: ");
            luongthang = float.Parse(Console.ReadLine());
        }
        public new void InBL()
        {
            Console.WriteLine($"{maso}\t {hoten}\t{TinhTL()}");
        }
    }
    class GV : CanBo
    {
        byte sotiet;
        float thulao;
        public GV() : base()
        {
            sotiet = 0;
            thulao = 0;
        }
        public GV(string m, string ht, bool gt, byte cong, float luong) : base(m, ht, gt)
        {
            sotiet = cong; thulao = luong;
        }
        public GV(GV nv) : base((CanBo)nv)
        {
            sotiet = nv.sotiet; thulao = nv.thulao;
        }
        public new float TinhTL() {
            return sotiet * thulao;
        }
        public new void Nhap()
        {
            base.Nhap();
            Console.Write("Nhap so tiet:");
            sotiet = byte.Parse(Console.ReadLine());
            Console.Write("Nhap thu lao 1 tiet:");
            thulao = float.Parse(Console.ReadLine());
        }
        public new void InBL()
        {
            Console.WriteLine($"{maso}\t {hoten}\t{TinhTL()}");
        }
    }
}
