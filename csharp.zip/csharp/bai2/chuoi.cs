﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class chuoi
    {
        string s;
        int x, y;
        
        public chuoi()
        {
            s = "pham thanh lam";
            x = 5;
            y = 3;
            Console.BackgroundColor = ConsoleColor.Blue; // màu nền
            Console.ForegroundColor = ConsoleColor.White; // màu chữ gán là màu trắng
        }
        public void HienThi()
        {
            //Console.Clear();
            Console.CursorLeft = x; // đưa con trỏ tới cột x
            Console.CursorTop = y; // đưa con trỏ tới dòng y
            Console.Write(s);
            Console.CursorVisible = false;
        }
        public void chuyenDong()
        {
            HienThi();
            while (true)
            {
                ConsoleKeyInfo phim = Console.ReadKey();// lấy thông tin phim
                if (phim.Key == ConsoleKey.LeftArrow)
                    x--;
                else if (phim.Key == ConsoleKey.RightArrow)
                    x++;
                else if (phim.Key == ConsoleKey.UpArrow)
                    y--;
                else if (phim.Key == ConsoleKey.DownArrow)
                    y++;
                else if (phim.Key == ConsoleKey.Escape)
                    break;
                //xu ly duong bien
                if (x == 0)
                    x = Console.WindowWidth - s.Length;
                else if (y == 0)
                    x = Console.WindowHeight - 1;
                else if (x == Console.WindowWidth)
                    x = 0;
                else if (y == Console.WindowHeight)
                    y = 0;
                HienThi();
            }
        }
    }
}
