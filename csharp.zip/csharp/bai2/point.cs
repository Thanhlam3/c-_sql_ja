﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class point
    {
        int x, y;
        public point()
        {
            x = 0;
            y = 0;
        }
        public point(int x1, int y1)
        {
            x = x1;
            y = y1;
        }
        public void HienThi()
        {
            //Console.Clear();
            Console.CursorLeft = x; // đưa con trỏ tới cột x
            Console.CursorTop = y; // đưa con trỏ tới dòng y         
            Console.CursorVisible = false;
        }
        public double tinhkc()
        {       
            return Math.Sqrt(Math.Pow(x, 2) + Math.Pow(y, 2));
        }
        public void xuat()
        {
            Console.WriteLine($"toa do 2 diem la {x} va {y}");
            Console.WriteLine($"kc giua 2 toa do la {tinhkc()}");
        }
    }
}
