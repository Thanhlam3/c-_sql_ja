﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class time
    {
        // thuoc tinh
        int hour, minute, second;
        public time()
        {
            hour = 0; minute = 0; second = 0;
        }
        public time(int h, int m, int s)
        {
            hour = h; minute = m; second = s;
        }
        // dong goi thuoc tinh
        public int Minute { get => minute; set => minute = value; }
        public int Second { get => second; set => second = value; }
        // phuong thuc truy nhap
        public int gethour() { return hour; }
        public void sethour(int h) { hour = h; }
        public void xuat()
        {
            Console.WriteLine($"{hour}:{minute}:{second}");
        }
    }
}
