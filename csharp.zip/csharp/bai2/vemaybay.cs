﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class vemaybay
    {
        string sohieu, ten;      
        DateTime ngay;
        double gia;
        bool choNgoi;
        public vemaybay()
        {
            sohieu = "VN123";
            ten = "Nha Trang – Ha Noi";
            ngay = DateTime.Now;
            gia = 500;
            choNgoi = false;
        }
        public vemaybay(string ten1, DateTime ngay1, bool choNgoi1)
        {
            sohieu = "VN123";
            ten = ten1;
            ngay = ngay1;
            gia = 500;
            choNgoi = choNgoi1;
        }
        public void nhap()
        {
            Console.WriteLine("nhap so hieu, ten, gia, cho ngoi(true/false): ");
            sohieu = Console.ReadLine();
            ten = Console.ReadLine();    
            gia = double.Parse(Console.ReadLine());
            choNgoi = bool.Parse(Console.ReadLine());
            while (true)
            {
                Console.WriteLine("nhap ngay (dd/MM/yyyy): ");
                string s = Console.ReadLine();
                if (DateTime.TryParseExact(s, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out ngay))
                    break;
                else
                    Console.WriteLine("loi. nhap lai theo dd/MM/yyyy.");
            }

        }
        public double tinhtien()
        {
            if (choNgoi == true)
                return (gia + 350 + 50);
            else
                return (gia + 350);
        }
        public void xuat()
        {
            Console.WriteLine($"ten chuyen bay {ten}, ngay bay {ngay:dd/MM/yyyy}, tien khach phai tra {tinhtien()}");
        }
    }
}
