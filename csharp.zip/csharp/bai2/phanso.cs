﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class phanso
    {
        int tuso, mauso;
        public phanso()
        {
            tuso = 0;
            mauso = 1;
        }
        public phanso(int ts, int ms)
        {
            tuso = ts;
            mauso = ms;
        }
        public phanso(phanso ps)
        {
            tuso = ps.tuso;
            mauso = ps.mauso;
        }
        public phanso cong(phanso p1, phanso p2)
        {
            phanso kq = new phanso();
            kq.tuso = p1.tuso * p2.mauso + p2.tuso * p1.mauso;
            kq.mauso = p1.mauso * p2.mauso;
            return kq;
        }
        public phanso tru(phanso p1, phanso p2)
        {
            phanso kq = new phanso();
            kq.tuso = p1.tuso * p2.mauso - p2.tuso * p1.mauso;
            kq.mauso = p1.mauso * p2.mauso;
            return kq;
        }
        public phanso nhan(phanso p1, phanso p2)
        {
            phanso kq = new phanso();
            kq.tuso = p1.tuso * p2.tuso;
            kq.mauso = p1.mauso * p2.mauso;
            return kq;
        }
        public phanso chia(phanso p1, phanso p2)
        {
            phanso kq = new phanso();
            kq.tuso = p1.tuso * p2.mauso;
            kq.mauso = p1.mauso * p2.tuso;
            return kq;
        }
        int ucln(int x, int y)
        {
            while (y != 0)
            {
                int temp = y;
                y = x % y;
                x = temp;
            }
            return x;
        }
        public phanso rutgon()
        {
            phanso kq = new phanso();
            int t = ucln(tuso, mauso);

            kq.tuso = tuso / t;
            kq.mauso = mauso / t;
            return kq;
        }
        public void xuat()
        {
            Console.WriteLine($"{tuso}/{mauso}");
        }
    }
}
