﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class hinhchunhat
    {
        float dai, rong;

        //public float Rong { get => rong; set => rong = value; }
        //public float Dai { get => dai; set => dai = value; }

        public hinhchunhat()
        {
            dai = 0;
            rong = 0;
        }
        public hinhchunhat(float d, float r)
        {
            dai = d;
            rong = r;
        } 
        public hinhchunhat (hinhchunhat hcn)
        {
            dai = hcn.dai;
            rong = hcn.rong;
        }
        public void setkichthuoc()
        {
            Console.Write("cap nhat chieu dai ");
            while (!float.TryParse(Console.ReadLine(), out dai) || dai <= 0)
                Console.Write("nhap lai chieu dai");
            Console.Write("cap nhat chieu rong ");
            while (!float.TryParse(Console.ReadLine(), out rong) || dai <= 0)
                Console.Write("nhap lai chieu rong");
        }
        public float chuvi()
        {
             return (dai + rong) * 2;
             
        }
        public float dientich()
        {
             return dai * rong;        
        }
        public void xuat()
        {
            Console.WriteLine($"chieu dai {dai}, chieu rong {rong}, chu vi {chuvi()}, dien tich {dientich()}");
        }
        
       
    }
   
}
