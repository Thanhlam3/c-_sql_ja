﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class adult
    {
        string hoten;
        double canNang;
        double chieuCao;
        public adult()
        {
            hoten = "pham thanh lam";
            canNang = 50.0;
            chieuCao = 164.0;
        }
        public adult(string hoten1, double canNang1, double chieuCao1 )
        {
            hoten = hoten1;
            canNang = canNang1;
            chieuCao = chieuCao1;
            Console.BackgroundColor = ConsoleColor.DarkBlue;// màu nền 
            Console.ForegroundColor = ConsoleColor.White;// màu chữ
        }
        public adult(adult ad)
        {
            hoten = ad.hoten;
            canNang = ad.canNang;
            chieuCao = ad.chieuCao;
        }
        public double Tinh_bmi()
        {
            double bmi = canNang / (chieuCao * chieuCao);
            if (bmi < 18.5)
            {
                Console.WriteLine("ban thuoc nhom: thieu can");
                double socandu = (chieuCao * chieuCao) * 18.5;
                double socancantang = socandu - canNang;
                Console.WriteLine($"de co suc khoe tot thi ban can tang them: {socancantang:F2} kg");
            }
            else if (bmi < 25)
                Console.WriteLine("ban thuoc nhom: binh thuong, suc khoe tot");
            else if (bmi < 30)
            {
                Console.WriteLine("ban thuoc nhom: thua can");
                double socanbidu = (chieuCao * chieuCao) * 25;
                double socancangiam = Math.Abs(socanbidu - canNang);
                Console.WriteLine($"de co suc khoe tot thi ban can giam them: {socancangiam:F2} kg");
            }         
            else
            {
                Console.WriteLine("ban thuoc nhom: beo phi");
                double socanbidu = (chieuCao * chieuCao) * 30;
                double socancangiam = Math.Abs(socanbidu - canNang);
                Console.WriteLine($"de co suc khoe tot thi ban can giam them: {socancangiam:F2} kg");
            }
            return bmi;
            
        }
        public void xuat()
        {
            
            Console.WriteLine($"ho ten:{hoten}, can nang: {canNang} kg, chieu cao: {chieuCao} m, dua theo chi so bmi " );
            double bmi = Tinh_bmi();
        }
    }
}
