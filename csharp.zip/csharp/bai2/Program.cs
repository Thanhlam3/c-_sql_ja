﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai2
{
    class Program
    {
        static void bai2_1()
        {
            time t1 = new time();
            Console.Write("nhap gio ");
            int h = int.Parse(Console.ReadLine());
            Console.Write("nhap phut ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("nhap giay ");
            int s = int.Parse(Console.ReadLine());
            time t2 = new time(h,m,s);

            t1.xuat();
            t2.xuat();
            Console.Write("cap nhat gio ");
            h = int.Parse(Console.ReadLine());
            t1.sethour(h);

            int sogiay = (t2.gethour() - t1.gethour()) * 3600 + (t2.Minute) - (t1.Minute) * 60 + (t2.Second) - (t1.Second);
            Console.WriteLine("tong so giay {0} : ", sogiay);
        }
        static void bai2_2()
        {
            // tao doi tuong dung khoi tao khong tham so
                hinhchunhat hcn1 = new hinhchunhat();

            //tao doi tuong dung khoi tao co tham so
            Console.Write("Nhap vao chieu dai, chieu rong: ");

            float d = float.Parse(Console.ReadLine());

            float r = float.Parse(Console.ReadLine());

            hinhchunhat hcn2 = new hinhchunhat(d, r);

            Console.Write("DT1: ");

            hcn1.xuat();

            Console.Write("DT2: ");

            hcn2.xuat();

            //tao doi tuong dung khoi tao sao chep

            hinhchunhat hcn3 = new hinhchunhat(hcn2);

            Console.Write("DT3: ");

            hcn3.xuat();
            //
            float tongDT = hcn1.dientich() + hcn2.dientich() + hcn3.dientich(); 
            Console.WriteLine("Tong DT 3 HCN {0}", tongDT);
        }
        static void bai2_3()
        {
            chuoi s = new chuoi();
            s.chuyenDong();
        }
        static void bai2_4()
        {
            phanso ps1 = new phanso(2, 5);

            //

            Console.Write("Nhap vao tu so va mau so ps2:");

            int t = int.Parse(Console.ReadLine());

            int m = int.Parse(Console.ReadLine());

            phanso ps2 = new phanso(t, m);

            Console.Write("\nPhan so 1: ");

            ps1.xuat();

            Console.Write("\nPhan so 2: ");

            ps2.xuat();

            //

            phanso ps = new phanso();

            ps = ps1.cong(ps1, ps2);

            // ps = ps1.Cong1(ps2);

            ps = ps.rutgon();

            

            Console.Write("\nTong 2 phan so: ");

            ps.xuat();

            ps = ps1.tru(ps1, ps2);

            Console.Write("\nHieu 2 phan so: ");

            ps.xuat();

        }
        static void bai2_5()
        {
            point p = new point();
            Console.WriteLine("nhap 2 toa do x va y: ");
            int x = int.Parse(Console.ReadLine());
            int y = int.Parse(Console.ReadLine());
            point p1 = new point(x, y);
            p1.HienThi();
            p1.tinhkc();
            p1.xuat();

        }
        static void bai2_6()
        {
            vemaybay v1 = new vemaybay();
            vemaybay v2 = new vemaybay();
            Console.WriteLine("nhap thong tin cho ve 2: ");
            v2.nhap();
            v2.xuat();
            v1.xuat();
        }
        static void bai2_7()
        {
            adult a = new adult();
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;
            Console.WriteLine("nhap ho ten, can nang(kg) va chieu cao(m) ");
            string ten = Console.ReadLine();
            double cn = double.Parse(Console.ReadLine());
            double chcao = double.Parse(Console.ReadLine());
            adult a1 = new adult(ten,cn,chcao);
            a1.xuat();

        }
        static void bai2_8()
        {
            // a. in ra "0 + 0 = 0", vi trong lop nay dang gan cac gia tri a, b = 0 va c = +.
            // b. in ra man hinh " nhap 2 so thuc va nhap phep toan" , ta nhap a = 7, b = 8, c = + . goi phuong thuc xuat nen in ra " 7 + 8 = 15 ".
            // c. truyen vao phep toan a = 3, b = 6, c = * . in ra " 3 * 6 = 18".
            // d. truyen vao phep toan a = 3, b = 6, c = * . goi phuong thuc capnhat, ta gan lai gia tri voi a = 7, b = 8, c = + . in ra la " 7 + 8 = 15 ". 
        }
        static void Main(string[] args)
        {
            bai2_3();
            Console.ReadLine();
        }
    }
}
