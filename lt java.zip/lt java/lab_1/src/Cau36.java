public class Cau36 {
    public static long fib1(long index) { // Đệ quy
        if (index <= 1) return index;
        return fib1(index - 1) + fib1(index - 2);
    }

    public static long fib2(long index) { // Vòng lặp
        if (index <= 1) return index;
        long a = 0, b = 1, c = 0;
        for (int i = 2; i <= index; i++) {
            c = a + b;
            a = b;
            b = c;
        }
        return c;
    }

    public static void main(String[] args) {
        System.out.println(fib1(10)); // 55
        System.out.println(fib2(10)); // 55
    }
}
