public class Cau27 {
    public static int parseBinary(String binaryString) {
        int result = 0;
        for (char bit : binaryString.toCharArray()) {
            result = result * 2 + (bit - '0');
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println(parseBinary("10001")); // Kết quả: 17
    }
}
