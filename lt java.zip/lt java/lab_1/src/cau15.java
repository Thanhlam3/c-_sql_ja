import java.util.Scanner;
public class cau15 {
    public static String chuyen(int n){

        if (n == 0) return "0";

        StringBuilder binary = new StringBuilder();
        while (n > 0) {
            int phandu = n % 2;
            binary.append(phandu); // Thêm phần dư vào chuỗi
            n /= 2;
        }

        return binary.reverse().toString(); // Đảo ngược chuỗi nhị phân và trả về
    }
    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);
        int x = 25;
        String kq = chuyen(x);
        System.out.print("so "+ x+" sau khi chuyen thanh nhi phan la: "+kq);
    }
}
