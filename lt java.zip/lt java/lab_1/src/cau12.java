public class cau12 {
    public static void ham(int[] a) {
        int left = 0, right = a.length - 1;
        while (left < right) {

            int temp = a[left];
            a[left] = a[right];
            a[right] = temp;

            left++;
            right--;
        }
    }
    public static void main(String args[]){
        Console c = new Console();

        c.print("nhap so ptu cua mang ");
        int n = c.readInt();

        int[] a = new int[n];
        for(int i=0;i<n;i++){
            c.print("a["+i+"] = ");
            a[i] = c.readInt();
        }
        /* cach 1
        for (int i = n-1;i>=0;i--){
            c.print(a[i]+" ");
        }*/

        ham(a);
        for (int num : a) {
        c.print(num + " ");
    }
        c.println();
    }
}
