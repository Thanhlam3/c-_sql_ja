public class Cau26 {
    // Phương thức tính Ước số chung lớn nhất (USCLN)
    public static int uscln(int m, int n) {
        while (n != 0) {
            int temp = n;
            n = m % n;
            m = temp;
        }
        return m;
    }

    // Phương thức tính Bội số chung nhỏ nhất (BSCNN)
    public static int bscnn(int m, int n) {
        return (m * n) / uscln(m, n);
    }

    public static void main(String[] args) {
        int a = 12, b = 18;
        System.out.println("USCLN của " + a + " và " + b + " là: " + uscln(a, b));
        System.out.println("BSCNN của " + a + " và " + b + " là: " + bscnn(a, b));
    }
}
