import java.util.*;
class Cau19 {
    public static int tongChuSo(int so) {
        int tong = 0;
        while (so != 0) {
            tong += so % 10;
            so /= 10;
        }
        return tong;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập một số nguyên: ");
        int so = scanner.nextInt();
        System.out.println("Tổng các chữ số của " + so + " là: " + tongChuSo(so));
        scanner.close();
    }
}
