public class cau9 {
    public static void main(String argv[]){
        Console c = new Console();
        c.print("nhap vao 1 so nguyen ");
        int a = c.readInt();
        int tich = 1;
        c.println("cac thua so cua "+a+" la ");
        for(int i = 2;i <= a;i++){
            while (a % i == 0){ // Nếu chia hết, in ra và chia tiếp
                c.print(i + " ");
                a /= i;
            }
        }
        c.println("");
    }

}
