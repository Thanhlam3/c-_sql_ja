import java.util.*;
public class cau17 {
    public static void main(String[] args) {
        char[][] dapAnSinhVien = {
                {'A', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'},
                {'D', 'B', 'A', 'B', 'C', 'A', 'E', 'E', 'A', 'D'},
                {'E', 'D', 'D', 'A', 'C', 'B', 'E', 'E', 'A', 'D'},
                {'C', 'B', 'A', 'E', 'D', 'C', 'E', 'E', 'A', 'D'},
                {'A', 'B', 'D', 'C', 'C', 'D', 'E', 'E', 'A', 'D'},
                {'B', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'},
                {'B', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'},
                {'E', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'}
        };
        char[] dapAnDung = {'D', 'B', 'D', 'C', 'C', 'D', 'A', 'E', 'A', 'D'};
        int[] diemSo = new int[dapAnSinhVien.length];

        for (int i = 0; i < dapAnSinhVien.length; i++) {
            for (int j = 0; j < dapAnSinhVien[i].length; j++) {
                if (dapAnSinhVien[i][j] == dapAnDung[j]) {
                    diemSo[i]++;
                }
            }
        }
        Integer[] chiSo = new Integer[diemSo.length];
        for (int i = 0; i < diemSo.length; i++) chiSo[i] = i;
        Arrays.sort(chiSo, Comparator.comparingInt(i -> diemSo[i]));

        for (int i : chiSo) {
            System.out.println("Sinh viên " + i + " - Số đáp án đúng: " + diemSo[i]);
        }
    }
}