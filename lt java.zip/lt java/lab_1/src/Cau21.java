import java.util.Scanner;
import java.util.Stack;

public class Cau21 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập một số nguyên dương: ");
        int n = scanner.nextInt();

        if (n <= 0) {
            System.out.println("Vui lòng nhập một số nguyên dương.");
            return;
        }

        Stack<Integer> stack = new Stack<>();

        for (int i = 2; i <= n; i++) {
            while (n % i == 0) {
                stack.push(i);
                n /= i;
            }
        }


        System.out.print("Các thừa số nhỏ nhất theo thứ tự giảm dần: ");
        while (!stack.isEmpty()) {
            System.out.print(stack.pop() + " ");
        }
    }
}
