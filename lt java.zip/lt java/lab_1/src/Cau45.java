public class Cau45 {
    public static double m(int i) {
        if (i == 1) return 1.0 / 2;
        return m(i - 1) + (double) i / (i + 1);
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.println("m(" + i + ") = " + m(i));
        }
    }
}
