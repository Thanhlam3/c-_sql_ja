public class cau8 {
    public static void main(String args[]) {
        Console c = new Console();
        int soduong = 0;
        int soam = 0;
        int sum = 0;
        int not0 = 0;
        while (true) {
            c.print("nhap vao  cac so nguyen (nhap 0 de dung) ");
            int num = c.readInt();
            if (num == 0)
                break;
            if (num > 0)
                soduong++;
            else
                soam++;
            sum += num;
            not0++;
        }
        if (not0 > 0) {
            float tbc = (float) sum / not0;
            c.println("so duong la " + soduong);
            c.println("so am la " + soam);
            c.println("tong cac so " + sum);
            c.println("gtri tb " + tbc);
        }
    }
}
