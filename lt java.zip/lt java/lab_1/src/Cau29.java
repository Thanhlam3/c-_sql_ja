public class Cau29 {
    public static int average(int[] array) {
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        return sum / array.length;
    }

    public static double average(double[] array) {
        double sum = 0;
        for (double num : array) {
            sum += num;
        }
        return sum / array.length;
    }

    public static void main(String[] args) {
        int[] intArr = {1, 2, 3, 4, 5, 6};
        double[] doubleArr = {6.0, 4.4, 1.9, 2.9, 3.4, 3.5};
        System.out.println(average(intArr)); // 3
        System.out.println(average(doubleArr)); // 3.35
    }
}
