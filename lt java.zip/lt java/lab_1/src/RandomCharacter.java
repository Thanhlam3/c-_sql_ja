import java.util.Random;

public class RandomCharacter {
    private static final Random random = new Random();

    // Phương thức trả về một ký tự ngẫu nhiên trong đoạn từ ch1 đến ch2
    public static char getRandomCharacter(char ch1, char ch2) {
        return (char) (ch1 + random.nextInt(ch2 - ch1 + 1));
    }

    // Phương thức trả về một ký tự thường ngẫu nhiên (a-z)
    public static char getRandomLowerCaseLetter() {
        return getRandomCharacter('a', 'z');
    }

    // Phương thức trả về một ký tự hoa ngẫu nhiên (A-Z)
    public static char getRandomUpperCaseLetter() {
        return getRandomCharacter('A', 'Z');
    }

    // Phương thức trả về một ký tự số ngẫu nhiên (0-9)
    public static char getRandomDigitCharacter() {
        return getRandomCharacter('0', '9');
    }

    // Phương thức trả về một ký tự Unicode ngẫu nhiên (0 - 65535)
    public static char getRandomCharacter() {
        return (char) random.nextInt(65536);
    }
}
