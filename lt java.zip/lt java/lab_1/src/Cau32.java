public class Cau32 {
    public static String convertMillis(long timeMillis) {
        long hours = (timeMillis / 3600000);
        long minutes = (timeMillis % 3600000) / 60000;
        long seconds = (timeMillis % 60000) / 1000;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public static void main(String[] args) {
        System.out.println(convertMillis(5500)); // 00:00:05
        System.out.println(convertMillis(100000)); // 00:01:40
        System.out.println(convertMillis(555550000)); // 154:19:10
    }
}
