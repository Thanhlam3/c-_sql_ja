import java.util.Arrays;

public class Cau35 {
    public static String sort(String s) {
        char[] chars = s.toCharArray();
        Arrays.sort(chars);
        return new String(chars);
    }

    public static boolean isAnagram(String s1, String s2) {
        return sort(s1).equals(sort(s2));
    }

    public static void main(String[] args) {
        System.out.println(isAnagram("silent", "listen")); // true
        System.out.println(isAnagram("garden", "ranged")); // true
        System.out.println(isAnagram("split", "lisp")); // false
    }
}
