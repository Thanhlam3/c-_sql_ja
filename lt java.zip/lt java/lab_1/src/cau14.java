public class cau14 {
    public static void pattern1(int n){
        Console c = new Console();
        for(int i = 1; i <= n; i++){
            for (int j = 1; j <= i; j++){
                c.print(j+ " ");
            }
            c.println();
        }
    }
    public static void pattern2(int n){
        Console c = new Console();
        for(int i = n; i >= 1; i--){
            for (int j = 1; j <= i; j++){
                c.print(j+ " ");
            }
            c.println();
        }
    }
    public static void pattern3(int n){
        Console c = new Console();
        for(int i = 1; i <= n; i++){
            for (int k = 0; k < n - i; k++) {
                c.print("  ");
            }
            for (int j = i; j >= 1; j--){
                c.print(j + " ");
            }
            c.println();
        }
    }
    public static void pattern4(int n) {
        Console c = new Console();
        for (int i = n; i >= 1; i--) {
            for (int k = 0; k < n - i; k++) {
                c.print("  ");
            }
            for (int j = 1; j <= i; j++) {
                c.print(j + " ");
            }
            c.println();
        }
    }
    public static void main(String args[]){
       int n = 6;
       Console c = new Console();
       //pattern1(n);
       c.println(" ");
       //pattern2(n);
       c.println(" ");
       //pattern3(n);
       c.println(" ");
       pattern4(n);
    }
}
