public class cau11 {
    public static boolean ktrasnt(int x) {
        if (x < 2)
            return false;
        for (int i = 2; i * i <= x; i++) {
            if (x % i == 0)
                return false;
        }
        return true;
    }

    public static void main(String args[]) {
        Console c = new Console();
        c.print("nhap 1 so nguyen ");
        int a = c.readInt();
        boolean kq = ktrasnt(a);
        if (kq == true)
            c.print("day la so nguyen to ");
        else
            c.print("day ko phai la snt \n");
        int dem=0;
        for (int i = 1; i <= 100; i++) {
            if (ktrasnt(i)) {
                c.print(i + " ");
                dem++;
                if(dem == 10) {
                    c.println(" ");
                    dem = 0;
                }
            }
        }
    }
}
