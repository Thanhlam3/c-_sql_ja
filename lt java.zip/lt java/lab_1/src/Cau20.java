public class Cau20 {
    public static void main(String[] args) {

        String str = "Welcome";
        char a = 'e';
        int result = count(str, a);
        System.out.println("Số lần xuất hiện của '" + a + "' trong \"" + str + "\": " + result);
    }


    public static int count(String str, char a) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == a) {
                count++;
            }
        }
        return count;
    }
}
