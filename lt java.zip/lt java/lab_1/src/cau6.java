public class cau6 {
    public static void main (String args[]){
        Console c = new Console();
        c.print("nhap vao so nguyen 1 ");
        int num1 = c.readInt();
        c.print("nhap vao so nguyen 2 ");
        int num2 = c.readInt();
        c.print("nhap vao so nguyen 3 ");
        int num3 = c.readInt();
        if (num1 > num2) {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }
        if (num1 > num3) {
            int temp = num1;
            num1 = num3;
            num3 = temp;
        }
        if (num2 > num3) {
            int temp = num2;
            num2 = num3;
            num3 = temp;
        }
        c.println("sx theo thu tu tang dan la "+num1 + num2 + num3);
    }
}
