public class cau24 {
    public static void main(String[] args) {
        final int TOTAL_CHARACTERS = 175; // Tổng số ký tự cần in
        final int CHARS_PER_LINE = 25;   // Số ký tự mỗi dòng

        // Tạo và in 175 ký tự thường ngẫu nhiên, mỗi dòng 25 ký tự
        for (int i = 1; i <= TOTAL_CHARACTERS; i++) {
            System.out.print(RandomCharacter.getRandomLowerCaseLetter() + " ");
            if (i % CHARS_PER_LINE == 0) {
                System.out.println(); // Xuống dòng sau mỗi 25 ký tự
            }
        }
    }
}
