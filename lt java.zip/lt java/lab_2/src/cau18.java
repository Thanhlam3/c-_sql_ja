public class cau18 {
    public static void main(String[] args) {
        lop_cau18 course1 = new lop_cau18("Java Programming");
        lop_cau18 course2 = new lop_cau18("Data Structures");

        course1.addStudent("Alice");
        course1.addStudent("Bob");
        course1.addStudent("Charlie");

        course2.addStudent("David");
        course2.addStudent("Eve");

        System.out.println("Course: " + course1.getName());
        System.out.println("Number of students: " + course1.getNumberOfStudents());
        System.out.println("Students: " + course1.getStudents());

        System.out.println("\nCourse: " + course2.getName());
        System.out.println("Number of students: " + course2.getNumberOfStudents());
        System.out.println("Students: " + course2.getStudents());
    }
}