import java.util.Date;
import java.util.Scanner;
public class cau16 {
    public static void main(String argv[]){
        Scanner scanner = new Scanner(System.in);
        Loan_cau16 A = new Loan_cau16();
        System.out.print("nhap so tien vay ");
        double tien = scanner.nextDouble();
        System.out.print("nhap so nam cho vay ");
        int nam = scanner.nextInt();
        System.out.print("nhap lai xuat ");
        double laixuat = scanner.nextDouble();
        System.out.print("so tien phai tra hang thang la "+A.monthlyPayment(tien, nam,laixuat)+" va so tong so tien phai tra la "+ A.totalPayment(tien, nam,laixuat));
    }
}
