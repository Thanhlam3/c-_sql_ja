public class TestClasses {
    public static void main(String[] args) {
        Person person = new Person("John Doe", "123 Main St", "123-456-7890", "john@example.com");
        Student student = new Student("Alice Brown", "456 Elm St", "987-654-3210", "alice@example.com", Student.JUNIOR);
        Employee employee = new Employee("Robert Smith", "789 Pine St", "555-123-4567", "robert@example.com", "Office 101", 50000, new MyDate(2020, 5, 15));
        Faculty faculty = new Faculty("Dr. Emily White", "321 Oak St", "444-987-6543", "emily@example.com", "Office 202", 70000, new MyDate(2015, 8, 20), "9 AM - 5 PM", "Professor");
        Staff staff = new Staff("Michael Green", "567 Maple St", "333-876-5432", "michael@example.com", "Office 303", 40000, new MyDate(2018, 3, 10), "Administrator");

        System.out.println(person);
        System.out.println(student);
        System.out.println(employee);
        System.out.println(faculty);
        System.out.println(staff);
    }
}
