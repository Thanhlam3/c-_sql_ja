import java.util.Random;

class RandomCharacter {
    private static Random rand = new Random();

    public static char getRandomCharacter(char ch1, char ch2) {
        return (char) (ch1 + rand.nextInt(ch2 - ch1 + 1));
    }

    public static char getRandomLowerCaseLetter() {
        return getRandomCharacter('a', 'z');
    }

    public static char getRandomUpperCaseLetter() {
        return getRandomCharacter('A', 'Z');
    }

    public static char getRandomDigitCharacter() {
        return getRandomCharacter('0', '9');
    }

    public static char getRandomCharacter() {
        return getRandomCharacter((char) 32, (char) 126);
    }
}
