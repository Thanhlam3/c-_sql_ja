public class cau13 {
    public static void main(String[] args){
        lop_cau13 stock = new lop_cau13("SUNW", "Sun Microsystems Inc");
        stock.setPreviousClosingPrice(100);
        stock.setCurrentPrice(90);

        System.out.println("Stock Symbol: " + stock.getSymbol());
        System.out.println("Stock Name: " + stock.getName());
        System.out.println("Previous Closing Price: " + stock.getPreviousClosingPrice());
        System.out.println("Current Price: " + stock.getCurrentPrice());
        System.out.printf("Price Change Percentage: %.2f%%\n", stock.changePercent());
    }
}
