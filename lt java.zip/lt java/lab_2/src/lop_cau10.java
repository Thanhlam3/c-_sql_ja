import java.util.Scanner;

public class lop_cau10 {
    Scanner s = new Scanner(System.in);
    int slow = 1;
    int medium = 2;
    int fast = 3;

    int speed;
    boolean on;
    double radius;
    String color;

    lop_cau10(){
        speed = slow;
        on = false;
        radius = 5;
        color = "blue";
    }
    lop_cau10(int sp, boolean o, double rd, String cl){
        speed = sp;
        on = o;
        radius = rd;
        color = cl;
    }
    public int getSpeed(){return speed;}
    public boolean getOn(){return on;}
    public double getRadius(){return radius;}
    public String getColor(){return color;}

    public void setSpeed(int speed1){speed = speed1;}
    public void setOn(boolean on1){on = on1;}
    public void setRadius(double radius1){radius = radius1;}
    public void setColor(String color1){color = color1;}

    public String toString(){
        if(on == true){
            return "toc do: "+speed+" mau sac:+ "+color+" ban kinh: "+radius;
        }
        else{
            return "fan is off.  mau sac:+ "+color+" ban kinh: "+radius;
        }

    }

}
