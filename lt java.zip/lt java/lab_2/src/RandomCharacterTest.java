public class RandomCharacterTest {
    public static void main(String[] args) {
        int count = 0;
        for (int i = 0; i < 175; i++) {
            System.out.print(RandomCharacter.getRandomLowerCaseLetter() + " ");
            count++;
            if (count % 25 == 0) {
                System.out.println();
            }
        }
    }
}
