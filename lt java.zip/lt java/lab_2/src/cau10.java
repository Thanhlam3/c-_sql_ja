import java.util.Scanner;

public class cau10 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        lop_cau10 a = new lop_cau10();

        System.out.println("Nhập tốc độ (1-SLOW, 2-MEDIUM, 3-FAST), bán kính, màu sắc và trạng thái (true-bật / false-tắt) cho fan 1:");
        int speed1 = scanner.nextInt();
        double radius1 = scanner.nextDouble();
        scanner.nextLine(); // Đọc bỏ dòng thừa sau nextDouble()
        String color1 = scanner.nextLine();
        boolean on1 = scanner.nextBoolean();

        lop_cau10 fan1 = new lop_cau10();
        fan1.setSpeed(speed1);
        fan1.setRadius(radius1);
        fan1.setColor(color1);
        fan1.setOn(on1);

        // Nhập thông tin cho quạt 2
        System.out.println("Nhập tốc độ (1-SLOW, 2-MEDIUM, 3-FAST), bán kính, màu sắc và trạng thái (true-bật / false-tắt) cho fan 2:");
        int speed2 = scanner.nextInt();
        double radius2 = scanner.nextDouble();
        scanner.nextLine(); // Đọc bỏ dòng thừa sau nextDouble()
        String color2 = scanner.nextLine();
        boolean on2 = scanner.nextBoolean();

        lop_cau10 fan2 = new lop_cau10();
        fan2.setSpeed(speed2);
        fan2.setRadius(radius2);
        fan2.setColor(color2);
        fan2.setOn(on2);

        // Hiển thị thông tin quạt
        System.out.println("\nThông tin quạt 1: " + fan1.toString());
        System.out.println("Thông tin quạt 2: " + fan2.toString());


    }
}
