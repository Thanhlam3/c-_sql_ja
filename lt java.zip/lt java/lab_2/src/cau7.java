public class cau7 {
    public static void main(String[] args){

    }
}
