import java.util.Scanner;

public class cau1_3_4 {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        // cau 1: x = 18. Vi ban dau x = 20, co 1 lenh tang x len 1 thanh 21 va co 3 lenh giam x di 1 thanh x = 18.
        // cau 3: in ra la "SuperclassSubclass". Vi ban dau class cau31 duoc tao ra va in ra Superclass, class cau 32 duoc tao ra sau do va duoc thua ke cau31. nen khi chay se in ra ket qua cua cau31 va cau 32.
        // cau 4: in ra i = 3, i = 5. Vi bien i trong ham tang la truyen tham tri nen chi co hieu luc trong phuong thuc, khi goi ra trong main thi bien i se ko thay doi.
    }
}
