import java.util.Date;

public class Loan_cau16 {
    double sotienvay;
    int sonamvay;
    double laixuat;
    Date ngaybatdau;

    Loan_cau16(){
        sotienvay = 1000;
        laixuat = 2.5;
        sonamvay = 1;
    }
    Loan_cau16(double tien, int nam, double lx){
        sotienvay = tien;
        sonamvay = nam;
        laixuat = lx;
    }
    public double getSotienvay(){ return sotienvay; }
    public int getSonamvay(){ return sonamvay; }
    public double getLaixuat(){ return laixuat; }
    public Date getNgayvay(){ return ngaybatdau; }

    public void setNgayvay(Date ngaybd){ ngaybatdau = ngaybd; }
    public void setSotienvay(double tien){sotienvay = tien;}
    public void setSonamvay(int sonamvay1){ sonamvay = sonamvay1; }
    public void setLaixuat(double laixuat1){ laixuat = laixuat1; }

    public double monthlyPayment(double sotienvay, int sonamvay,  double laixuat){
        int thang = sonamvay * 12;
        double lxthang = laixuat / 1200;
        double sotientrathang = (lxthang + lxthang / (Math.pow(1 + lxthang, thang) - 1)) * sotienvay;
        return sotientrathang;
    }
    public double totalPayment(double sotienvay, int sonamvay,  double laixuat){
        int thang = sonamvay * 12;
        double tiengoc =  sotienvay / (double)thang;
        double tienlai = (sotienvay * laixuat) / 12;
        double tienphaitra = tiengoc + tienlai;
        return tienphaitra;
    }
}
