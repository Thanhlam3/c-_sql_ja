import java.util.ArrayList;

public class lop_cau18 {

    private String name;
    private ArrayList<String> students;
    private int numberOfStudents;

    public lop_cau18(String name) {
        this.name = name;
        this.students = new ArrayList<>();
        this.numberOfStudents = 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addStudent(String student) {
        students.add(student);
        numberOfStudents++;
    }

    public ArrayList<String> getStudents() {
        return students;
    }

    public int getNumberOfStudents() {
        return numberOfStudents;
    }
}

