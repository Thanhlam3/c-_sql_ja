public class lop_cau13 {
    String symbol;
    String name;
    double previousClosingPrice, currentPrice;

    lop_cau13(){
        symbol = "123";
        name = "vinfast";
        previousClosingPrice = 10.0;
        currentPrice = 15.0;
    }
    lop_cau13 (String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }
    public String getSymbol(){return symbol;}
    public String getName(){return name;}
    public double getPreviousClosingPrice(){return previousClosingPrice;}
    public double getCurrentPrice(){return currentPrice;}

    public void setPreviousClosingPrice(double previousClosingPrice1){previousClosingPrice = previousClosingPrice1;}
    public void setCurrentPrice(double currentPrice1){currentPrice = currentPrice1;}

    public double changePercent() {
        if (previousClosingPrice == 0) {
            return 0;
        }
        return ((currentPrice - previousClosingPrice) / previousClosingPrice) * 100;
    }
}
