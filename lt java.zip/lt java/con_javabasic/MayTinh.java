import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.Math;

public class MayTinh extends JFrame implements ActionListener {
    private JTextField hienThi;   // Ô hiển thị kết quả và dữ liệu nhập vào.
    private double so1, so2, ketQua;    // Các biến lưu trữ số đầu, số cuối và kết quả.
    private String phepToan = "";    // Biến lưu loại phép toán.

    public MayTinh() {
        setTitle("Máy Tính Đơn Giản");
        setSize(350, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());  //  BorderLayout để bố trí các thành phần.

        hienThi = new JTextField();  // Tạo ô hiển thị.
        hienThi.setEditable(false); // Không cho người dùng nhập tay.
        hienThi.setFont(new Font("Arial", Font.BOLD, 28));
        add(hienThi, BorderLayout.NORTH);    // Đặt ô ở phía trên giao diện.

        JPanel panel = new JPanel();    // Tạo panel chứa các nút.
        panel.setLayout(new GridLayout(8, 4, 5, 5));  // 8 hàng, 4 cột = 32 ô (đủ 31 nút + 1 ô trống)

        String[] nutBam = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "0", ".", "=", "+",
                "AC", "+/-", "√", "^",
                "sin", "cos", "tan", "%",
                "log", "!", "3√", "abs",
                "π", "B1", "B2"
        };


        for (String text : nutBam) {
            JButton nut = new JButton(text);
            nut.setFont(new Font("Arial", Font.BOLD, 18));
            nut.addActionListener(this);    // Gán sự kiện khi nút được bấm.
            panel.add(nut);  // Thêm nút vào panel.
        }

        add(panel, BorderLayout.CENTER);    // Thêm panel vào trung tâm giao diện.
        setVisible(true);   // Hiển thị cửa sổ ra màn hình.
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String lenh = e.getActionCommand();

        try {
            if (lenh.matches("[0-9]") || lenh.equals(".")) {
                hienThi.setText(hienThi.getText() + lenh);
            } else if (lenh.equals("AC")) {
                hienThi.setText("");
                so1 = so2 = ketQua = 0;
                phepToan = "";
            } else if (lenh.equals("+/-")) {
                if (!hienThi.getText().isEmpty()) {
                    double tam = Double.parseDouble(hienThi.getText());
                    hienThi.setText(String.valueOf(-tam));
                }
            } else if (lenh.equals("√")) {
                if (!hienThi.getText().isEmpty()) {
                    double tam = Double.parseDouble(hienThi.getText());
                    hienThi.setText(String.valueOf(Math.sqrt(tam)));
                }
            } else if (lenh.equals("^")) {
                so1 = Double.parseDouble(hienThi.getText());
                phepToan = "^";
                hienThi.setText("");
            } else if (lenh.equals("%")) {
                so1 = Double.parseDouble(hienThi.getText());
                phepToan = "%";
                hienThi.setText("");
            } else if (lenh.equals("!")) {
                if (!hienThi.getText().isEmpty()) {
                    int n = Integer.parseInt(hienThi.getText());
                    if (n >= 0) {
                        long giaiThua = 1;
                        for (int i = 2; i <= n; i++) giaiThua *= i;
                        hienThi.setText(String.valueOf(giaiThua));
                    } else {
                        hienThi.setText("Lỗi");
                    }
                }
            } else if (lenh.equals("3√")) {
                if (!hienThi.getText().isEmpty()) {
                    double tam = Double.parseDouble(hienThi.getText());
                    hienThi.setText(String.valueOf(Math.cbrt(tam)));
                }
            } else if (lenh.equals("abs")) {
                if (!hienThi.getText().isEmpty()) {
                    double tam = Double.parseDouble(hienThi.getText());
                    hienThi.setText(String.valueOf(Math.abs(tam)));
                }
            } else if (lenh.equals("π")) {
                hienThi.setText(String.valueOf(Math.PI));
            } else if (lenh.equals("log")) {
                if (!hienThi.getText().isEmpty()) {
                    double tam = Double.parseDouble(hienThi.getText());
                    hienThi.setText(String.valueOf(Math.log10(tam)));
                }
            } else if (lenh.equals("B1")) {
                String aStr = JOptionPane.showInputDialog("Nhập a:");
                String bStr = JOptionPane.showInputDialog("Nhập b:");
                try {
                    double a = Double.parseDouble(aStr);
                    double b = Double.parseDouble(bStr);
                    if (a == 0) {
                        hienThi.setText(b == 0 ? "Vô số nghiệm" : "Vô nghiệm");
                    } else {
                        hienThi.setText("x = " + (-b / a));
                    }
                } catch (NumberFormatException ex) {
                    hienThi.setText("Lỗi");
                }
            } else if (lenh.equals("B2")) {
                String aStr = JOptionPane.showInputDialog("Nhập a:");
                String bStr = JOptionPane.showInputDialog("Nhập b:");
                String cStr = JOptionPane.showInputDialog("Nhập c:");
                try {
                    double a = Double.parseDouble(aStr);
                    double b = Double.parseDouble(bStr);
                    double c = Double.parseDouble(cStr);
                    double delta = b * b - 4 * a * c;
                    if (a == 0) {
                        hienThi.setText("a = 0 → PT bậc 1");
                    } else if (delta < 0) {
                        hienThi.setText("Vô nghiệm");
                    } else if (delta == 0) {
                        hienThi.setText("x = " + (-b / (2 * a)));
                    } else {
                        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
                        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
                        hienThi.setText("x1=" + x1 + "; x2=" + x2);
                    }
                } catch (NumberFormatException ex) {
                    hienThi.setText("Lỗi");
                }
            } else if (lenh.equals("=")) {
                so2 = Double.parseDouble(hienThi.getText());
                switch (phepToan) {
                    case "+": ketQua = so1 + so2; break;
                    case "-": ketQua = so1 - so2; break;
                    case "*": ketQua = so1 * so2; break;
                    case "/": ketQua = so2 != 0 ? so1 / so2 : Double.NaN; break;
                    case "^": ketQua = Math.pow(so1, so2); break;
                    case "%": ketQua = so1 % so2; break;
                }
                hienThi.setText(String.valueOf(ketQua));
                phepToan = "";
            } else {
                so1 = Double.parseDouble(hienThi.getText());
                phepToan = lenh;
                hienThi.setText("");
            }
        } catch (NumberFormatException ex) {
            hienThi.setText("Lỗi");
        }
    }


    public static void main(String[] args) {
        new MayTinh();
    }
}
