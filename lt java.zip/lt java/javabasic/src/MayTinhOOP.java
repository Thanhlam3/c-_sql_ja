import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Lớp trừu tượng cho một phép toán
abstract class PhepToan {
    public abstract double thucHien(double[] thamSo);
}

// Các phép toán 2 số
class Cong extends PhepToan {
    public double thucHien(double[] thamSo) {
        return thamSo[0] + thamSo[1];
    }
}

class Tru extends PhepToan {
    public double thucHien(double[] thamSo) {
        return thamSo[0] - thamSo[1];
    }
}

class Nhan extends PhepToan {
    public double thucHien(double[] thamSo) {
        return thamSo[0] * thamSo[1];
    }
}

class Chia extends PhepToan {
    public double thucHien(double[] thamSo) {
        if (thamSo[1] == 0) {
            System.err.println("Lỗi: Chia cho 0!");
            return Double.NaN;
        }
        return thamSo[0] / thamSo[1];
    }
}

class LuyThua extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.pow(thamSo[0], thamSo[1]);
    }
}

class ChiaLayDu extends PhepToan {
    public double thucHien(double[] thamSo) {
        return thamSo[0] % thamSo[1];
    }
}

// Các phép toán một toán hạng
class CanBacHai extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.sqrt(thamSo[0]);
    }
}

class CanBacBa extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.cbrt(thamSo[0]);
    }
}

class TriTuyetDoi extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.abs(thamSo[0]);
    }
}

class LogCoSo10 extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.log10(thamSo[0]);
    }
}

class Sin extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.sin(Math.toRadians(thamSo[0]));
    }
}

class Cos extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.cos(Math.toRadians(thamSo[0]));
    }
}

class Tan extends PhepToan {
    public double thucHien(double[] thamSo) {
        return Math.tan(Math.toRadians(thamSo[0]));
    }
}

class GiaiThua extends PhepToan {
    public double thucHien(double[] thamSo) {
        int n = (int) thamSo[0];
        if (n < 0) throw new ArithmeticException("Lỗi: Giai thừa không xác định với số âm");
        long ketQua = 1;
        for (int i = 2; i <= n; i++) {
            ketQua *= i;
        }
        return ketQua;
    }
}

public class MayTinhOOP extends JFrame implements ActionListener {
    private JTextField oHienThi;
    private double soThuNhat, soThuHai;
    private double ans = 0;  // Biến lưu kết quả cuối cùng
    private String tenPhepToan = "";

    public MayTinhOOP() {
        setTitle("Máy Tính OOP");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        oHienThi = new JTextField();
        oHienThi.setEditable(false);
        oHienThi.setFont(new Font("Arial", Font.BOLD, 28));
        add(oHienThi, BorderLayout.NORTH);

        JPanel bangNut = new JPanel(new GridLayout(9, 4, 5, 5));
        String[] danhSachNut = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "0", ".", "=", "+",
                "AC", "+/-", "√", "^",
                "sin", "cos", "tan", "%",
                "log", "!", "3√", "abs",
                "π", "x²", "x³", "Ans",
                "nCr", "nPr", "B1", "B2"
        };

        for (String tenNut : danhSachNut) {
            JButton nut = new JButton(tenNut);
            nut.setFont(new Font("Arial", Font.BOLD, 18));
            nut.addActionListener(this); // nút gán sự kiện
            bangNut.add(nut);
        }

        add(bangNut, BorderLayout.CENTER);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent suKien) {
        String lenh = suKien.getActionCommand(); // lấy nội dung được nhấn
        try {
            if (lenh.matches("[0-9]") || lenh.equals(".")) {
                oHienThi.setText(oHienThi.getText() + lenh);
            } else if (lenh.equals("AC")) {
                oHienThi.setText("");
                soThuNhat = soThuHai = 0;
                tenPhepToan = "";
            } else if (lenh.equals("+/-")) {
                if (!oHienThi.getText().isEmpty()) {
                    double giaTri = Double.parseDouble(oHienThi.getText());
                    oHienThi.setText(String.valueOf(-giaTri));
                }
            } else if (lenh.equals("π")) {
                oHienThi.setText(String.valueOf(Math.PI));
            } else if (lenh.equals("Ans")) {
                oHienThi.setText(String.valueOf(ans));
            } else if (lenh.equals("x²")) {
                double x = Double.parseDouble(oHienThi.getText());
                double ketQua = x * x;
                ans = ketQua;
                oHienThi.setText(String.valueOf(ketQua));
            } else if (lenh.equals("x³")) {
                double x = Double.parseDouble(oHienThi.getText());
                double ketQua = x * x * x;
                ans = ketQua;
                oHienThi.setText(String.valueOf(ketQua));
            } else if (lenh.equals("nCr") || lenh.equals("nPr")) {
                int n = Integer.parseInt(JOptionPane.showInputDialog("Nhập n:"));
                int r = Integer.parseInt(JOptionPane.showInputDialog("Nhập r:"));
                if (n < 0 || r < 0 || r > n) {
                    oHienThi.setText("Lỗi");
                    return;
                }
                long ketQua = 1;
                for (int i = 1; i <= r; i++) {
                    ketQua *= (n - i + 1);
                    if (lenh.equals("nCr")) ketQua /= i;
                }
                ans = ketQua;
                oHienThi.setText(String.valueOf(ketQua));
            } else if (lenh.equals("B1")) {
                String aStr = JOptionPane.showInputDialog("Nhập a:");
                String bStr = JOptionPane.showInputDialog("Nhập b:");

                double a = Double.parseDouble(aStr);
                double b = Double.parseDouble(bStr);

                if (a == 0) {
                    if (b == 0) {
                        oHienThi.setText("Vô số nghiệm");
                    } else {
                        oHienThi.setText("Vô nghiệm");
                    }
                } else {
                    double x = -b / a;
                    oHienThi.setText("x = " + x);
                }
            } else if (lenh.equals("B2")) {
                String aStr = JOptionPane.showInputDialog("Nhập a:");
                String bStr = JOptionPane.showInputDialog("Nhập b:");
                String cStr = JOptionPane.showInputDialog("Nhập c:");

                double a = Double.parseDouble(aStr);
                double b = Double.parseDouble(bStr);
                double c = Double.parseDouble(cStr);

                if (a == 0) {
                    // Nếu a = 0 thì phương trình trở thành bậc nhất: bx + c = 0
                    if (b == 0) {
                        if (c == 0) {
                            oHienThi.setText("Vô số nghiệm");
                        } else {
                            oHienThi.setText("Vô nghiệm");
                        }
                    } else {
                        double x = -c / b;
                        oHienThi.setText("Phương trình bậc nhất: x = " + x);
                    }
                } else {
                    double delta = b * b - 4 * a * c;

                    if (delta < 0) {
                        oHienThi.setText("Vô nghiệm");
                    } else if (delta == 0) {
                        double x = -b / (2 * a);
                        oHienThi.setText("x = " + x);
                    } else {
                        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
                        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
                        oHienThi.setText("x1 = " + x1 + "; x2 = " + x2);
                    }
                }
            } else if (lenh.equals("+") || lenh.equals("-") || lenh.equals("*") || lenh.equals("/") ||
                    lenh.equals("^") || lenh.equals("%")) {
                soThuNhat = Double.parseDouble(oHienThi.getText());
                tenPhepToan = lenh;
                oHienThi.setText("");
            } else if (lenh.equals("=")) {
                soThuHai = Double.parseDouble(oHienThi.getText());
                PhepToan phepToan = null;

                if (tenPhepToan.equals("+")) phepToan = new Cong();
                else if (tenPhepToan.equals("-")) phepToan = new Tru();
                else if (tenPhepToan.equals("*")) phepToan = new Nhan();
                else if (tenPhepToan.equals("/")) phepToan = new Chia();
                else if (tenPhepToan.equals("^")) phepToan = new LuyThua();
                else if (tenPhepToan.equals("%")) phepToan = new ChiaLayDu();

                if (phepToan != null) {
                    double ketQua = phepToan.thucHien(new double[]{soThuNhat, soThuHai});
                    ans = ketQua;
                    oHienThi.setText(String.valueOf(ketQua));
                }else {
                    oHienThi.setText("Lỗi");
                }

                tenPhepToan = "";
            }else {
                double giaTri = Double.parseDouble(oHienThi.getText());
                PhepToan phepToan = null;

                if (lenh.equals("√")) phepToan = new CanBacHai();
                else if (lenh.equals("3√")) phepToan = new CanBacBa();
                else if (lenh.equals("abs")) phepToan = new TriTuyetDoi();
                else if (lenh.equals("log")) phepToan = new LogCoSo10();
                else if (lenh.equals("sin")) phepToan = new Sin();
                else if (lenh.equals("cos")) phepToan = new Cos();
                else if (lenh.equals("tan")) phepToan = new Tan();
                else if (lenh.equals("!")) phepToan = new GiaiThua();

                if (phepToan != null) {
                    double ketQua = phepToan.thucHien(new double[]{giaTri});
                    ans = ketQua;
                    oHienThi.setText(String.valueOf(ketQua));
                } else {
                    oHienThi.setText("Lỗi");
                }
            }
        } catch (Exception ex) {
            oHienThi.setText("Lỗi");
        }
    }

    public static void main(String[] args) {
        new MayTinhOOP();
    }
}
